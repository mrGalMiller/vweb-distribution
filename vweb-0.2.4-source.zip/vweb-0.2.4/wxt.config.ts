import { copyFile, mkdir } from "node:fs/promises";
import { join } from "node:path";
import { defineConfig } from "wxt";

function getPermissions(): string[] {
  return ["tabs", "tabGroups", "storage", "contextMenus", "scripting", "search"];
}

function getNewtabMatches(browser: string): string[] {
  if (browser === "firefox") {
    return ["http://localhost/*"];
  }

  return ["http://localhost:*/*"];
}

export default defineConfig({
  modules: ["@wxt-dev/module-react"],
  zip: { name: "vweb" },
  manifest: ({ browser, command }) => ({
    name: "__MSG_extensionName__",
    description: "__MSG_extensionDescription__",
    version: "0.2.4",
    default_locale: "en",
    permissions: getPermissions(),
    content_security_policy: {
      extension_pages: "script-src 'self'; object-src 'self'; img-src 'self' data: blob:",
    },
    optional_host_permissions: ["<all_urls>"],
    host_permissions: [],
    web_accessible_resources: [
      ...(command === "serve" ? [{ resources: ["newtab.html"], matches: getNewtabMatches(browser) }] : []),
      // The global search overlay is embedded as an iframe by the content
      // script on whatever site the user has granted optional host access
      // to, so it must be loadable there — the content script itself is
      // only ever registered on granted origins (see background.ts).
      { resources: ["search-overlay.html"], matches: ["<all_urls>"] },
    ],
    commands: {
      "open-search": {
        suggested_key: {
          default: "Ctrl+Shift+K",
          mac: "Command+Shift+K",
        },
        description: "__MSG_commandOpenSearch__",
      },
    },
    ...(browser === "firefox"
      ? {
          browser_specific_settings: {
            gecko: {
              id: "support@cs.tabslate.com",
              strict_min_version: "142.0",
              data_collection_permissions: {
                required: ["none"],
              },
            },
          },
        }
      : {}),
  }),
  vite: () => ({
    build: {
      sourcemap: process.env.NODE_ENV !== "production",
      // Extension pages load from local disk with no network latency to
      // hide, so the modulepreload optimization has nothing to offer. Worse,
      // Chrome's extension-page world isolation means the preloaded request
      // never matches the actual dynamic import, so every emitted
      // <link rel="modulepreload"> just produces a console warning
      // ("cross-world extension resource mismatch") for no benefit.
      modulePreload: false,
    },
  }),
  hooks: {
    "build:manifestGenerated": (_wxt, manifest) => {
      // WXT generates this override from the newtab entrypoint. Keep the
      // dashboard reachable from the extension popup without replacing the browser page.
      delete manifest.chrome_url_overrides?.newtab;
      if (Object.keys(manifest.chrome_url_overrides ?? {}).length === 0) {
        delete manifest.chrome_url_overrides;
      }

      // Remove auto-generated host_permissions that conflict with optional_host_permissions
      delete manifest.host_permissions;

      if (manifest.content_scripts?.length === 0) {
        delete manifest.content_scripts;
      }
    },
    "vite:build:extendConfig": ([entrypoint], config) => {
      if (entrypoint) {
        config.build = {
          ...config.build,
          license: { fileName: `licenses/${entrypoint.name}.txt` },
        };
      }
    },
    "zip:extension:start": async ({ config }) => {
      await mkdir(join(config.outDir, "licenses"), { recursive: true });
      await Promise.all([
        copyFile(join(config.root, "LICENSE"), join(config.outDir, "LICENSE")),
        copyFile(join(config.root, "NOTICE"), join(config.outDir, "NOTICE")),
        copyFile(
          join(config.root, "node_modules", "@fontsource", "inter", "LICENSE"),
          join(config.outDir, "licenses", "Inter-OFL.txt"),
        ),
      ]);
    },
  },
});
