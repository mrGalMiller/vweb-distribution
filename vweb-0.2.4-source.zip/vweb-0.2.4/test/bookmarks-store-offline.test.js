import { beforeEach, describe, expect, mock, test } from "bun:test";

const putCalls = [];
const deleteCalls = [];
const bulkWriteCalls = [];
const decrementCalls = [];
const trashUsageCalls = [];
const trashedStore = new Map();

mock.module("@/lib/idb", () => ({
  idbGet: async () => undefined,
  idbGetAll: async () => [],
  idbGetByIndex: async () => [],
  idbGetMany: async (_store, keys) => keys.map((key) => trashedStore.get(key)),
  idbPut: async (store, value) => {
    putCalls.push({ store, value });
    if (store === "trashed-bookmarks") {
      trashedStore.set(value.id, value);
    }
  },
  idbDelete: async (store, key) => {
    deleteCalls.push({ store, key });
    if (store === "trashed-bookmarks") {
      trashedStore.delete(key);
    }
  },
  idbBulkWrite: async (ops) => {
    bulkWriteCalls.push(ops);
    for (const op of ops) {
      if (op.store !== "trashed-bookmarks") {
        continue;
      }
      if (op.type === "put") {
        trashedStore.set(op.value.id, op.value);
      }
      if (op.type === "delete") {
        trashedStore.delete(op.key);
      }
    }
  },
}));

mock.module("@/store/plan-store", () => ({
  usePlanStore: {
    getState: () => ({
      decrementUsage: (resource, count) => {
        decrementCalls.push({ resource, count });
      },
      incrementUsage: () => {},
      moveUsageToTrash: (resource, count) => {
        trashUsageCalls.push(["moveToTrash", resource, count]);
      },
      restoreUsageFromTrash: (resource, count) => {
        trashUsageCalls.push(["restoreFromTrash", resource, count]);
      },
      ensureFresh: async () => {},
      limits: null,
      showQuotaAlert: () => {},
      fetchPlan: async () => {},
      usage: { bookmarks: 0 },
    }),
  },
  guardQuota: (_resource, _currentCount, fallback, fn) => {
    const value = fn();
    return value ?? fallback;
  },
}));

mock.module("@/lib/id", () => ({
  generateId: () => "generated-id",
}));

const bookmarkUtils = await import("../lib/bookmark-utils.ts");
mock.module("@/lib/bookmark-utils", () => ({
  ...bookmarkUtils,
  normalizeFavicon: (favicon) => favicon,
}));

const { useBookmarksStore } = await import(`../store/bookmarks-store.ts?test=${Date.now()}-${Math.random()}`);

function createBookmark(id, overrides = {}) {
  return {
    id,
    title: `Bookmark ${id}`,
    url: `https://example.com/${id}`,
    description: "",
    favicon: "",
    collectionId: "collection-1",
    tags: [],
    createdAt: "2026-05-28T00:00:00.000Z",
    isFavorite: false,
    seq: 5,
    deletedAt: 1,
    ...overrides,
  };
}

describe("bookmarks store offline permanent delete", () => {
  beforeEach(() => {
    putCalls.length = 0;
    deleteCalls.length = 0;
    bulkWriteCalls.length = 0;
    decrementCalls.length = 0;
    trashUsageCalls.length = 0;
    trashedStore.clear();
    useBookmarksStore.setState({
      bookmarks: new Map(),
      archivedBookmarks: [],
      trashedBookmarks: [],
      _archivedLoaded: true,
      _trashedLoaded: true,
    });
  });

  test("permanent deletion releases local quota and preserves legacy tombstones", async () => {
    const bookmark = createBookmark("bookmark-local");
    const terminal = createBookmark("terminal", { isTrashed: 2 });
    trashedStore.set(bookmark.id, bookmark);
    trashedStore.set(terminal.id, terminal);
    useBookmarksStore.setState({ trashedBookmarks: [bookmark], _trashedLoaded: true });

    useBookmarksStore.getState().permanentlyDeleteBatch([bookmark.id, bookmark.id, terminal.id, "missing"]);
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(bulkWriteCalls).toEqual([[{ type: "delete", store: "trashed-bookmarks", key: bookmark.id }]]);
    expect(trashedStore.get(terminal.id)).toEqual(terminal);
    expect(trashedStore.has(bookmark.id)).toBe(false);
    expect(useBookmarksStore.getState().trashedBookmarks).toEqual([]);
    expect(decrementCalls).toEqual([{ resource: "bookmark", count: 1 }]);
  });

  test("trashCollectionBookmarks returns a Promise so callers can await it", async () => {
    const bookmark = createBookmark("bookmark-active");
    useBookmarksStore.setState({
      bookmarks: new Map([[bookmark.id, bookmark]]),
      archivedBookmarks: [],
      trashedBookmarks: [],
      _archivedLoaded: true,
      _trashedLoaded: true,
    });

    const action = Reflect.get(useBookmarksStore.getState(), "trashCollectionBookmarks");
    const result = Reflect.apply(action, useBookmarksStore.getState(), ["collection-1"]);

    expect(result).toBeInstanceOf(Promise);
    await result;
    expect(bulkWriteCalls).toHaveLength(1);
  });

  test("trashBookmark moves quota to trash and restoreFromTrash moves it back", async () => {
    const bookmark = createBookmark("bookmark-single");
    useBookmarksStore.setState({
      bookmarks: new Map([[bookmark.id, bookmark]]),
      archivedBookmarks: [],
      trashedBookmarks: [],
      countsByCollection: {},
      _archivedLoaded: true,
      _trashedLoaded: true,
    });

    useBookmarksStore.getState().trashBookmark(bookmark.id);
    expect(trashUsageCalls).toEqual([["moveToTrash", "bookmark", undefined]]);

    trashUsageCalls.length = 0;
    useBookmarksStore.getState().restoreFromTrash(bookmark.id);
    expect(trashUsageCalls).toEqual([["restoreFromTrash", "bookmark", undefined]]);
  });
});
