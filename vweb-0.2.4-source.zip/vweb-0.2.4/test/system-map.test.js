import { describe, expect, test } from "bun:test";
import { existsSync } from "node:fs";
import en from "@/public/_locales/en/messages.json";
import he from "@/public/_locales/he/messages.json";
import {
  createSystemMapExport,
  DASHBOARD_ROUTES,
  getDashboardPage,
  savedGroupPath,
} from "@/lib/system-map";

describe("system map contract", () => {
  test("maps every dashboard route with one stable template for saved groups", () => {
    const catalog = createSystemMapExport("en", (key) => key);
    const pages = catalog.surfaces.filter((surface) => "route" in surface);
    expect(pages.map((page) => page.route)).toEqual(Object.values(DASHBOARD_ROUTES));
    expect(pages.every((page) => page.navigationVisibleByDefault)).toBe(true);
    expect(getDashboardPage(savedGroupPath("test/group")).id).toBe("saved-group");
    expect(savedGroupPath("test/group")).toBe("/groups/test%2Fgroup");
  });

  test("keeps the quota and attribution references in the catalog", () => {
    const catalog = createSystemMapExport("en", (key) => key);
    expect(catalog.actions.map(({ id }) => id)).toContain("view-quotas");
    expect(catalog.actions.map(({ id }) => id)).toContain("upstream-source");
    expect(catalog.integrations.map(({ id }) => id)).toEqual([
      "quotas", "vendor-links",
    ]);
  });

  test("exports translated documentation, existing evidence and portable references", () => {
    for (const [locale, entries] of [["en", en], ["he", he]]) {
      const catalog = createSystemMapExport(locale, (key) => {
        expect(entries[key], `Missing ${locale} translation for ${key}`).toBeDefined();
        return entries[key].message;
      });

      expect(catalog.schemaVersion).toBe(1);
      expect(catalog.product).toEqual({ id: "vweb", name: "vWeb" });
      expect(new Set(catalog.surfaces.map((item) => item.id)).size).toBe(catalog.surfaces.length);
      for (const page of catalog.surfaces) {
        expect(page.actions.every((id) => catalog.actions.some((action) => action.id === id))).toBe(true);
        expect(page.settings.every((id) => catalog.settings.some((setting) => setting.id === id))).toBe(true);
        expect(page.dependencies.every((id) => catalog.integrations.some((integration) => integration.id === id))).toBe(true);
        expect(page.sources.every((path) => existsSync(path))).toBe(true);
        if ("toolbarActions" in page) {
          expect(page.toolbarActions?.every(({ id, visibleByDefault }) =>
            visibleByDefault && catalog.actions.some((action) => action.id === id),
          )).toBe(true);
        }
      }

      for (const integration of catalog.integrations) {
        expect(integration.sources.every((path) => existsSync(path))).toBe(true);
      }
      expect(catalog.relationships.every(({ status }) => status === "proposed")).toBe(true);
    }
  });
});
