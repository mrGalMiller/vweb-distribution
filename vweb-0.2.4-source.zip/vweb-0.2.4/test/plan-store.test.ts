// @ts-expect-error Bun provides this test module at runtime.
import { expect, mock, test } from "bun:test";

const stores: Record<string, object[]> = {
  workspaces: [{ id: "workspace" }, { id: "trashed-workspace", deletedAt: 1 }],
  collections: [{ id: "collection", workspaceId: "workspace" }],
  bookmarks: [{ id: "active", collectionId: "collection" }],
  "archived-bookmarks": [{ id: "archived", collectionId: "collection" }],
  "trashed-bookmarks": [
    { id: "trashed", collectionId: "collection", deletedAt: 1 },
    { id: "terminal", collectionId: "collection", isTrashed: 2 },
  ],
  groups: [{ id: "group", workspaceId: "trashed-workspace" }],
  tags: [{ id: "tag" }],
};

mock.module("@/lib/idb", () => ({
  async idbTransaction(
    names: string[],
    mode: string,
    read: (tx: Pick<IDBTransaction, "objectStore">) => object,
  ) {
    expect(mode).toBe("readonly");
    const requests: Array<{ result: object[]; onsuccess?: () => void }> = [];
    const data = read({
      objectStore(name: string) {
        expect(names).toContain(name);
        return {
          getAll() {
            const request = { result: stores[name] };
            requests.push(request);
            return request;
          },
        } as IDBObjectStore;
      },
    });
    for (const request of requests) {
      request.onsuccess?.();
    }
    return data;
  },
}));

const { usePlanStore } = await import("../store/plan-store");

test("calculates usage from local data without counting legacy terminal bookmarks", async () => {
  await usePlanStore.getState().refreshUsage();
  expect(usePlanStore.getState().usage).toEqual({
    workspaces: 2, collections: 1, bookmarks: 3, tags: 1, saved_groups: 1,
  });
  expect(usePlanStore.getState().trashUsage).toEqual({
    workspaces: 1, collections: 0, bookmarks: 1, tags: 0, saved_groups: 1,
  });
  expect(usePlanStore.getState().inUseUsage?.bookmarks).toBe(2);
  expect(usePlanStore.getState().checkQuota("bookmark", Number.MAX_SAFE_INTEGER)).toBe(true);
});
