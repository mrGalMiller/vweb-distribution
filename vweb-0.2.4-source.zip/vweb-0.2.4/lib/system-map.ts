export const PRODUCT_NAME = "vWeb";
export const SYSTEM_MAP_FILENAME = "vweb-system-map.json";

export const DASHBOARD_ROUTES = {
  bookmarks: "/",
  favorites: "/favorites",
  archive: "/archive",
  trash: "/trash",
  tabs: "/tabs",
  "saved-group": "/groups/:groupId",
} as const;

export type DashboardPageId = keyof typeof DASHBOARD_ROUTES;

export const SYSTEM_ACTIONS = {
  "bookmark-view": "systemMap_view",
  "bookmark-sort": "header_sortBy",
  "bookmark-filter": "header_filter",
  "add-bookmark": "header_addBookmark",
  "tabs-drawer": "systemMap_drawer",
  theme: "theme_select",
  language: "systemMap_languageDirection",
  "upstream-source": "systemMap_sourceLink",
  "manage-bookmarks": "systemMap_manageBookmarks",
  "manage-collections": "systemMap_manageCollections",
  "manage-tags": "systemMap_manageTags",
  "change-favorite": "systemMap_changeFavorite",
  "restore-archived": "systemMap_restoreArchived",
  "move-to-trash": "systemMap_moveToTrash",
  "restore-deleted": "systemMap_restoreDeleted",
  "delete-permanently": "systemMap_deletePermanently",
  "manage-live-tabs": "systemMap_manageLiveTabs",
  "manage-live-groups": "systemMap_manageLiveGroups",
  "refresh-tabs": "systemMap_refreshTabs",
  "save-window": "tabsPanel_saveWindow",
  "manage-saved-group": "systemMap_manageSavedGroup",
  "open-saved-group": "systemMap_openSavedGroup",
  "save-group-bookmarks": "systemMap_saveGroupBookmarks",
  "manage-workspaces": "systemMap_manageWorkspaces",
  "restore-workspace": "systemMap_restoreWorkspace",
  "backup-data": "localBackup_export",
  "restore-data": "localBackup_restore",
  "view-quotas": "settings_tabQuotas",
  "export-map": "systemMap_export",
  "import-bookmarks": "settings_generalImportBtn",
  "save-current-tab": "systemMap_saveCurrentTab",
  "open-dashboard": "systemMap_openDashboard",
  "search-and-open": "systemMap_searchAndOpen",
} as const;

export type SystemActionId = keyof typeof SYSTEM_ACTIONS;
const BOOKMARK_ACTIONS = ["bookmark-view", "bookmark-sort", "bookmark-filter", "add-bookmark"] as const;
export const TOOLBAR_ACTIONS = [
  ...BOOKMARK_ACTIONS, "tabs-drawer", "theme", "language", "upstream-source",
] as const;
export type ToolbarActionId = typeof TOOLBAR_ACTIONS[number];

export const SYSTEM_SETTINGS = {
  "bookmark-view": { label: SYSTEM_ACTIONS["bookmark-view"], default: "grid", scope: "dashboard-session" },
  "bookmark-sort": { label: SYSTEM_ACTIONS["bookmark-sort"], default: "date-newest", scope: "dashboard-session" },
  "bookmark-filter": { label: SYSTEM_ACTIONS["bookmark-filter"], default: "all", scope: "dashboard-session" },
  theme: { label: SYSTEM_ACTIONS.theme, default: "system", scope: "browser-profile" },
  language: { label: "systemMap_language", default: "auto", scope: "browser-profile" },
  direction: { label: "languageSelector_direction", default: "auto", scope: "browser-profile" },
  "search-overlay": { label: "settings_generalOverlayTitle", default: false, scope: "browser-permission" },
  "search-engines": { label: "systemMap_searchEngines", default: "browser-default", scope: "browser-settings" },
  "compact-group-titles": { label: "systemMap_compactGroups", default: true, scope: "browser-profile" },
  "navigation-visibility": { label: "systemMap_showNav", default: true, scope: "browser-profile" },
  "toolbar-visibility": { label: "systemMap_showToolbar", default: true, scope: "browser-profile" },
} as const;

type SystemSettingId = keyof typeof SYSTEM_SETTINGS;
export type SettingsTab = "general" | "quotas" | "system-map";

interface SurfaceDetails {
  label: string;
  headerLabel?: string;
  description: string;
  location: string;
  storage: readonly string[];
  actions: readonly SystemActionId[];
  settings: readonly SystemSettingId[];
  sources: readonly string[];
  dependencies?: readonly IntegrationId[];
}

interface DashboardPage extends SurfaceDetails {
  id: DashboardPageId;
  route: string;
  toolbar: readonly ToolbarActionId[];
}

interface AuxiliarySurface extends SurfaceDetails {
  id: "workspaces" | "settings" | "import" | "popup" | "search" | "search-overlay";
  settingsTab?: SettingsTab;
}

export type SystemSurface = DashboardPage | AuxiliarySurface;
const sharedSettings = ["theme", "language", "direction", "navigation-visibility", "toolbar-visibility"] as const;
const bookmarkSettings = ["bookmark-view", "bookmark-sort", "bookmark-filter", ...sharedSettings] as const;
const indexedDb = "IndexedDB · tabslate-db";
const workspaceStore = "store/workspace-store.ts";
const bookmarkStore = "store/bookmarks-store.ts";
const settingsDialog = "components/dashboard/settings-dialog.tsx";

export const DASHBOARD_PAGES: readonly DashboardPage[] = [
  {
    id: "bookmarks", label: "header_titleBookmarks", route: DASHBOARD_ROUTES.bookmarks,
    description: "systemMap_bookmarksDesc", location: "systemMap_bookmarksNav", storage: [indexedDb],
    toolbar: TOOLBAR_ACTIONS, actions: ["manage-bookmarks", "manage-collections", "manage-tags", "change-favorite"],
    settings: bookmarkSettings,
    sources: ["components/dashboard/content.tsx", bookmarkStore, workspaceStore],
    dependencies: ["quotas"],
  },
  {
    id: "favorites", label: "sidebar_navFavorites", route: DASHBOARD_ROUTES.favorites,
    description: "systemMap_favoritesDesc", location: "systemMap_sidebarLocation", storage: [indexedDb],
    toolbar: TOOLBAR_ACTIONS, actions: ["change-favorite", "manage-bookmarks"], settings: bookmarkSettings,
    sources: ["components/dashboard/favorites-content.tsx", bookmarkStore],
  },
  {
    id: "archive", label: "sidebar_navArchive", route: DASHBOARD_ROUTES.archive,
    description: "systemMap_archiveDesc", location: "systemMap_sidebarLocation", storage: [indexedDb],
    toolbar: TOOLBAR_ACTIONS, actions: ["restore-archived", "move-to-trash"], settings: bookmarkSettings,
    sources: ["components/dashboard/archive-content.tsx", bookmarkStore],
  },
  {
    id: "trash", label: "sidebar_navTrash", route: DASHBOARD_ROUTES.trash,
    description: "systemMap_trashDesc", location: "systemMap_sidebarLocation", storage: [indexedDb],
    toolbar: TOOLBAR_ACTIONS, actions: ["restore-deleted", "delete-permanently"], settings: bookmarkSettings,
    sources: ["components/dashboard/trash-content.tsx", "store/groups-store.ts", bookmarkStore],
    dependencies: ["quotas"],
  },
  {
    id: "tabs", label: "tabsPanel_openTabs", route: DASHBOARD_ROUTES.tabs,
    description: "systemMap_tabsDesc", location: "systemMap_tabsNav", storage: ["chrome.tabs", "chrome.tabGroups", indexedDb],
    toolbar: TOOLBAR_ACTIONS, actions: ["refresh-tabs", "save-window", "manage-live-tabs", "manage-live-groups"],
    settings: [...bookmarkSettings, "compact-group-titles"],
    sources: ["components/dashboard/tabs-panel/index.tsx", "components/dashboard/tabs-rail.tsx", "store/tabs-store.ts"],
    dependencies: ["quotas"],
  },
  {
    id: "saved-group", label: "systemMap_savedGroups", headerLabel: "tabsPanel_groups", route: DASHBOARD_ROUTES["saved-group"],
    description: "systemMap_groupsDesc", location: "systemMap_sidebarLocation", storage: [indexedDb, "chrome.tabGroups"],
    toolbar: TOOLBAR_ACTIONS, actions: ["manage-saved-group", "open-saved-group", "save-group-bookmarks"],
    settings: bookmarkSettings,
    sources: ["components/dashboard/group-detail/index.tsx", "store/groups-store.ts"], dependencies: ["quotas"],
  },
];

export const SYSTEM_SURFACES: readonly SystemSurface[] = [
  ...DASHBOARD_PAGES,
  {
    id: "workspaces", label: "workspaceManager_open", description: "systemMap_workspacesDesc",
    location: "systemMap_workspaceLocation", storage: [indexedDb], actions: ["manage-workspaces", "restore-workspace"],
    settings: [], sources: ["components/dashboard/workspace-manager/index.tsx", workspaceStore], dependencies: ["quotas"],
  },
  {
    id: "settings", label: "settings_title", description: "systemMap_settingsDesc", location: "systemMap_workspaceLocation",
    storage: ["localStorage", "chrome.storage.local", "chrome.permissions"], settingsTab: "general",
    actions: ["backup-data", "restore-data", "view-quotas", "export-map"],
    settings: ["search-overlay", ...sharedSettings], sources: [settingsDialog, "store/system-map-store.ts", "lib/local-backup.ts"],
    dependencies: ["quotas"],
  },
  {
    id: "import", label: "settings_generalImportTitle", description: "systemMap_importDesc",
    location: "systemMap_generalLocation", storage: [indexedDb], actions: ["import-bookmarks"],
    settings: [], sources: ["components/dashboard/import-dialog.tsx", bookmarkStore], dependencies: ["quotas"],
  },
  {
    id: "popup", label: "systemMap_popup", description: "systemMap_popupDesc",
    location: "systemMap_popupLocation", storage: ["chrome.tabs", indexedDb], actions: ["save-current-tab", "open-dashboard"],
    settings: ["theme"], sources: ["entrypoints/popup/App.tsx", "entrypoints/background.ts"], dependencies: ["quotas"],
  },
  {
    id: "search", label: "systemMap_search", description: "systemMap_searchDesc",
    location: "search.html", storage: [indexedDb, "chrome.tabs"], actions: ["search-and-open"],
    settings: ["search-engines"], sources: ["entrypoints/search/App.tsx", "components/search/search-panel.tsx", "lib/browser/search.ts"],
  },
  {
    id: "search-overlay", label: "settings_generalOverlayTitle", description: "systemMap_overlayDesc",
    location: "systemMap_generalLocation", storage: ["chrome.permissions", "chrome.storage.local", indexedDb],
    actions: ["search-and-open"], settings: ["search-overlay", "search-engines"],
    sources: ["entrypoints/content.ts", "entrypoints/search-overlay/main.tsx", "entrypoints/background.ts"],
  },
];

const INTEGRATIONS = {
  quotas: { requirement: "local", sources: ["store/plan-store.ts", "lib/quota-usage.ts"], endpoints: [] },
  "vendor-links": { requirement: "on-click", sources: ["components/dashboard/header.tsx", "LICENSE"], endpoints: ["github.com/TabSlate-dev/TabSlate"] },
} as const;

export type IntegrationId = keyof typeof INTEGRATIONS;

export const SYSTEM_INTEGRATIONS = (Object.keys(INTEGRATIONS) as IntegrationId[]).map((id) => ({
  id,
  ...INTEGRATIONS[id],
  label: `systemMap_integration_${id.replaceAll("-", "_")}`,
  description: `systemMap_effect_${id.replaceAll("-", "_")}`,
}));

export const FAMILY_RELATIONSHIPS = [
  { id: "command-center", status: "proposed", label: "Command Center", description: "systemMap_familyCommandCenter" },
  { id: "vmark", status: "proposed", label: "vMark", description: "systemMap_familyVMark" },
  { id: "vbrain", status: "proposed", label: "vBrain", description: "systemMap_familyVBrain" },
] as const;

export function getDashboardPage(pathname: string): DashboardPage {
  return DASHBOARD_PAGES.find((page) =>
    page.route === pathname || (page.id === "saved-group" && pathname.startsWith("/groups/")),
  ) ?? DASHBOARD_PAGES[0];
}

export function savedGroupPath(groupId: string): string {
  return DASHBOARD_ROUTES["saved-group"].replace(":groupId", encodeURIComponent(groupId));
}

export function createSystemMapExport(locale: string, translate: (key: string) => string) {
  return {
    schemaVersion: 1,
    product: { id: "vweb", name: PRODUCT_NAME },
    locale,
    surfaces: SYSTEM_SURFACES.map((surface) => {
      const details = {
        id: surface.id,
        label: translate(surface.label),
        description: translate(surface.description),
        location: surface.location.endsWith(".html") ? surface.location : translate(surface.location),
        storage: surface.storage,
        actions: surface.actions,
        settings: surface.settings,
        sources: surface.sources,
        dependencies: surface.dependencies ?? [],
      };
      if (!("route" in surface)) {
        return details;
      }
      return {
        ...details,
        route: surface.route,
        navigationVisibleByDefault: true,
        toolbarActions: surface.toolbar.map((id) => ({ id, visibleByDefault: true })),
      };
    }),
    actions: Object.entries(SYSTEM_ACTIONS).map(([id, label]) => ({ id, label: translate(label) })),
    settings: Object.entries(SYSTEM_SETTINGS).map(([id, setting]) => ({ ...setting, id, label: translate(setting.label) })),
    integrations: SYSTEM_INTEGRATIONS.map((integration) => ({
      ...integration,
      label: translate(integration.label),
      description: translate(integration.description),
    })),
    relationships: FAMILY_RELATIONSHIPS.map((relationship) => ({
      ...relationship,
      description: translate(relationship.description),
    })),
  };
}
