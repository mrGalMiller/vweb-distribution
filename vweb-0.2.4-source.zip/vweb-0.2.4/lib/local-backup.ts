import { idbTransaction } from "@/lib/idb";

const VERSION = 1;
const DATA_STORES = [
  "workspaces", "collections", "tags", "bookmarks", "archived-bookmarks",
  "trashed-bookmarks", "groups", "group-tabs",
] as const;
type DataStore = (typeof DATA_STORES)[number];
type BackupRecord = Record<string, unknown> & { id: string };
type BackupStores = Record<DataStore, BackupRecord[]>;

interface LocalBackup {
  format: "vweb-local-backup";
  version: typeof VERSION;
  createdAt: string;
  activeWorkspaceId: string | null;
  stores: BackupStores;
}

const bookmarkStrings = ["title", "url", "description", "favicon", "collectionId", "createdAt"];
const stringFields: Record<DataStore, string[]> = {
  workspaces: ["name", "color"],
  collections: ["workspaceId", "name", "icon"],
  tags: ["name", "color"],
  bookmarks: bookmarkStrings,
  "archived-bookmarks": bookmarkStrings,
  "trashed-bookmarks": bookmarkStrings,
  groups: ["name", "color", "createdAt", "workspaceId"],
  "group-tabs": ["groupId", "title", "url", "favicon"],
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function isBackupRecord(store: DataStore, value: unknown): value is BackupRecord {
  if (!isRecord(value) || typeof value.id !== "string" || value.id.length === 0 ||
      !stringFields[store].every((field) => typeof value[field] === "string")) {
    return false;
  }
  if (store !== "group-tabs" && !isFiniteNumber(value.seq)) {
    return false;
  }
  if (value.deletedAt !== undefined && !isFiniteNumber(value.deletedAt)) {
    return false;
  }
  switch (store) {
    case "workspaces":
      return isFiniteNumber(value.position) &&
        (value.deletionModel === undefined || value.deletionModel === 0 || value.deletionModel === 1);
    case "collections":
      return isFiniteNumber(value.position) &&
        (value.isDefault === undefined || typeof value.isDefault === "boolean") &&
        (value.archivedAt === undefined || isFiniteNumber(value.archivedAt));
    case "bookmarks":
    case "archived-bookmarks":
    case "trashed-bookmarks":
      return typeof value.isFavorite === "boolean" && Array.isArray(value.tags) &&
        value.tags.every((tag) => typeof tag === "string");
    case "groups":
      return typeof value.isCompact === "boolean";
    case "group-tabs":
      return isFiniteNumber(value.position);
    case "tags":
      return true;
  }
}

function emptyStores(): BackupStores {
  return {
    workspaces: [], collections: [], tags: [], bookmarks: [],
    "archived-bookmarks": [], "trashed-bookmarks": [], groups: [], "group-tabs": [],
  };
}

export function parseLocalBackup(text: string): LocalBackup {
  const value: unknown = JSON.parse(text);
  if (!isRecord(value) || value.format !== "vweb-local-backup" || value.version !== VERSION ||
      typeof value.createdAt !== "string" || !isRecord(value.stores) ||
      (value.activeWorkspaceId !== null && typeof value.activeWorkspaceId !== "string")) {
    throw new Error("Invalid vWeb backup format");
  }

  const stores = emptyStores();
  for (const store of DATA_STORES) {
    const records: unknown = value.stores[store];
    if (!Array.isArray(records) || !records.every((record) => isBackupRecord(store, record)) ||
        new Set(records.map(({ id }) => id)).size !== records.length) {
      throw new Error("Invalid vWeb backup records");
    }
    stores[store] = records;
  }

  return {
    format: "vweb-local-backup", version: VERSION, createdAt: value.createdAt,
    activeWorkspaceId: value.activeWorkspaceId, stores,
  };
}

export function readLocalBackup(): Promise<LocalBackup> {
  return idbTransaction([...DATA_STORES, "kv"], "readonly", (transaction) => {
    const backup: LocalBackup = {
      format: "vweb-local-backup", version: VERSION, createdAt: new Date().toISOString(),
      activeWorkspaceId: null, stores: emptyStores(),
    };
    for (const store of DATA_STORES) {
      const request = transaction.objectStore(store).getAll();
      request.onsuccess = () => { backup.stores[store] = request.result; };
    }
    const active = transaction.objectStore("kv").get("activeWorkspaceId");
    active.onsuccess = () => {
      backup.activeWorkspaceId = typeof active.result?.value === "string" ? active.result.value : null;
    };
    return backup;
  });
}

export function restoreLocalBackup(backup: LocalBackup): Promise<void> {
  return idbTransaction([...DATA_STORES, "kv"], "readwrite", (transaction) => {
    for (const store of DATA_STORES) {
      const target = transaction.objectStore(store);
      for (const record of backup.stores[store]) {
        // A duplicate key aborts the entire transaction and preserves the existing profile.
        target.add(record);
      }
    }
    if (backup.stores.workspaces.some((workspace) =>
      workspace.id === backup.activeWorkspaceId && !workspace.deletedAt,
    )) {
      transaction.objectStore("kv").put({ key: "activeWorkspaceId", value: backup.activeWorkspaceId });
    }
  });
}
