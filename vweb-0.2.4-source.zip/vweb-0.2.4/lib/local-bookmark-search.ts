import { idbTransaction } from "@/lib/idb";
import type { Bookmark, Collection, Workspace } from "@/lib/types";
import { getCollectionsUnderActiveWorkspace } from "@/lib/workspace-visibility";

export interface SearchBookmark {
  id: string;
  title: string;
  url: string;
  description: string;
  collectionId: string;
  isArchived: boolean;
}

export async function searchLocalBookmarks(query: string, collectionId?: string): Promise<SearchBookmark[]> {
  const terms = query.trim().toLocaleLowerCase().split(/\s+/);
  if (query.trim().length < 2) {
    return [];
  }

  const snapshot = await idbTransaction(
    ["workspaces", "collections", "bookmarks", "archived-bookmarks", "kv"],
    "readonly",
    (tx) => {
      const data = {
        workspaces: [] as Workspace[], collections: [] as Collection[],
        bookmarks: [] as Bookmark[], archived: [] as Bookmark[], activeId: "",
      };
      const workspaces = tx.objectStore("workspaces").getAll();
      const collections = tx.objectStore("collections").getAll();
      const bookmarks = tx.objectStore("bookmarks").getAll();
      const archived = tx.objectStore("archived-bookmarks").getAll();
      const active = tx.objectStore("kv").get("activeWorkspaceId");
      workspaces.onsuccess = () => { data.workspaces = workspaces.result; };
      collections.onsuccess = () => { data.collections = collections.result; };
      bookmarks.onsuccess = () => { data.bookmarks = bookmarks.result; };
      archived.onsuccess = () => { data.archived = archived.result; };
      active.onsuccess = () => { data.activeId = active.result?.value ?? ""; };
      return data;
    },
  );
  const visibleCollections = getCollectionsUnderActiveWorkspace(
    snapshot.activeId, snapshot.workspaces, snapshot.collections,
  );
  const collectionIds = new Set(visibleCollections.map((collection) => collection.id));
  const archivedIds = new Set(visibleCollections.filter((collection) => collection.archivedAt).map((collection) => collection.id));
  const archivedBookmarkIds = new Set(snapshot.archived.map((bookmark) => bookmark.id));
  const matches = new Map<string, SearchBookmark>();
  for (const bookmark of [...snapshot.bookmarks, ...snapshot.archived]) {
    if (bookmark.collectionId && !collectionIds.has(bookmark.collectionId)) {
      continue;
    }
    if (collectionId !== undefined && bookmark.collectionId !== collectionId) {
      continue;
    }
    const text = [bookmark.title, bookmark.url, bookmark.description].join(" ").toLocaleLowerCase();
    if (terms.every((term) => text.includes(term))) {
      matches.set(bookmark.id, {
        id: bookmark.id, title: bookmark.title, url: bookmark.url,
        description: bookmark.description ?? "", collectionId: bookmark.collectionId,
        isArchived: archivedBookmarkIds.has(bookmark.id) || archivedIds.has(bookmark.collectionId),
      });
    }
  }
  return [...matches.values()].slice(0, 50);
}
