// These shapes allow safe cleanup of records written by earlier versions.
export type WorkspaceLifecycleAction = "delete" | "restore" | "purge";

export interface SyncWorkspaceMutation extends SyncEntity {
  lifecycle_action?: WorkspaceLifecycleAction;
}

export interface SyncEntity {
  id: string;
  [key: string]: string | number | boolean | null | undefined | string[] | SyncEntity[];
}

export type SyncEntityType =
  | "workspace"
  | "collection"
  | "bookmark"
  | "saved_group"
  | "tag";

export interface SyncRejected {
  id: string;
  reason: string;
  type?: string;
  parent_id?: string;
  parent_type?: string;
}

export interface SyncPushEntities {
  workspaces: SyncWorkspaceMutation[];
  collections: SyncEntity[];
  bookmarks: SyncEntity[];
  tags: SyncEntity[];
  groups: SyncEntity[];
}

export function isSyncEntityType(value: string | undefined): value is SyncEntityType {
  return value === "workspace" ||
    value === "collection" ||
    value === "bookmark" ||
    value === "saved_group" ||
    value === "tag";
}

export interface SyncPushPayload {
  entities: SyncPushEntities;
}
