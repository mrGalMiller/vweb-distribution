export interface PlanLimits {
  max_workspaces: number;
  max_bookmarks: number;
  max_collections: number;
  max_tags: number;
  max_saved_groups: number;
  trash_grace_days: number;
}

export interface PlanUsage {
  workspaces: number;
  bookmarks: number;
  collections: number;
  tags: number;
  saved_groups: number;
}
