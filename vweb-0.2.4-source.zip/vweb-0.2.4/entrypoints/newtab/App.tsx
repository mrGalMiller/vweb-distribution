import { useEffect, useRef, useState } from "react";
import { HashRouter, Outlet, Route, Routes, useLocation } from "react-router-dom";
import { ThemeProvider } from "@/components/theme-provider";
import { TabsDndProvider, useTabsDndContext } from "@/components/dashboard/tabs-dnd-provider";
import { WorkspaceRail } from "@/components/dashboard/workspace-rail";
import { BookmarksSidebar } from "@/components/dashboard/sidebar";
import { BookmarksHeader } from "@/components/dashboard/header";
import { BookmarksContent } from "@/components/dashboard/content";
import { FavoritesContent } from "@/components/dashboard/favorites-content";
import { ArchiveContent } from "@/components/dashboard/archive-content";
import { TrashContent } from "@/components/dashboard/trash-content";
import { TabsPanel } from "@/components/dashboard/tabs-panel";
import { GroupDetail } from "@/components/dashboard/group-detail";
import { recoverLegacyGuestWorkspaceOrphansSafely } from "@/lib/guest-workspace-orphan-recovery";
import { DASHBOARD_ROUTES, getDashboardPage } from "@/lib/system-map";
import { subscribeToSystemMapStorage } from "@/store/system-map-store";
import { TabsRail } from "@/components/dashboard/tabs-rail";
import { SidebarProvider } from "@/components/ui/sidebar";
import { useBookmarksStore } from "@/store/bookmarks-store";
import { useWorkspaceStore } from "@/store/workspace-store";
import { useGroupsStore } from "@/store/groups-store";
import { useTabsStore } from "@/store/tabs-store";
import { useSettingsStore } from "@/store/settings-store";
import { usePlanStore } from "@/store/plan-store";
import { QuotaAlert } from "@/components/ui/quota-alert";
import { useTranslation } from "@/hooks/use-translation";
import type { ExtensionMessage } from "@/lib/messages";
import { Loader2 } from "lucide-react";

function Layout() {
  const { pathname } = useLocation();
  const page = getDashboardPage(pathname);
  const { t } = useTranslation();
  const { activeData } = useTabsDndContext();
  const [tabsDrawerOpen, setTabsDrawerOpen] = useState(false);
  const tabsDrawerTrigger = useRef<HTMLButtonElement>(null);
  const settingsButtonRef = useRef<HTMLButtonElement>(null);
  const tabsDrawerPanel = useRef<HTMLElement>(null);

  useEffect(() => {
    if (tabsDrawerOpen) {
      tabsDrawerPanel.current?.focus();
    }
  }, [tabsDrawerOpen]);

  const handleCloseTabsDrawer = () => {
    setTabsDrawerOpen(false);
    (tabsDrawerTrigger.current ?? settingsButtonRef.current)?.focus();
  };

  const handleOpenTabsDrawer = () => {
    if (tabsDrawerOpen) {
      tabsDrawerPanel.current?.focus();
    } else {
      setTabsDrawerOpen(true);
    }
  };

  return (
    <div className="flex h-svh overflow-hidden bg-sidebar">
      <WorkspaceRail
        settingsButtonRef={settingsButtonRef}
        onOpenTabsDrawer={handleOpenTabsDrawer}
      />

      {/* Wrapper constrains SidebarProvider's w-full to remaining width */}
      <div className="flex flex-1 min-w-0 overflow-hidden">
        {/*
          --sidebar-offset places the fixed panel past the workspace rail.
          SidebarProvider uses its default min-h-svh so height resolves correctly;
          the outer overflow-hidden clips any overflow.
        */}
        <SidebarProvider
          style={{ "--sidebar-offset": "3.25rem" } as React.CSSProperties}
        >
          <BookmarksSidebar />

          {/* Content area: use h-svh directly so height is always definite */}
          <div className="relative flex flex-1 h-svh overflow-hidden lg:p-2 lg:gap-2 min-w-0">
            {/* Center content card */}
            <div className="flex-1 flex flex-col lg:border lg:rounded-lg bg-background overflow-hidden min-w-0">
              <BookmarksHeader
                pageId={page.id}
                tabsDrawerOpen={tabsDrawerOpen}
                tabsDrawerTrigger={tabsDrawerTrigger}
                onToggleTabsDrawer={() => setTabsDrawerOpen((open) => !open)}
              />
              <Outlet />
            </div>

            <aside
              id="open-tabs-drawer"
              ref={tabsDrawerPanel}
              tabIndex={-1}
              aria-label={t("tabsPanel_openTabs")}
              hidden={!tabsDrawerOpen}
              className={tabsDrawerOpen
                ? "absolute inset-y-0 end-0 z-30 mt-14 flex w-72 max-w-full shrink-0 overflow-hidden border-s bg-background shadow-lg lg:static lg:z-auto lg:mt-0 lg:w-64 lg:rounded-lg lg:border lg:shadow-none"
                : "hidden"}
              onKeyDown={(event) => {
                if (event.key === "Escape" && !event.defaultPrevented && !activeData) {
                  event.stopPropagation();
                  handleCloseTabsDrawer();
                }
              }}
            >
              {tabsDrawerOpen && <TabsRail onClose={handleCloseTabsDrawer} />}
            </aside>
          </div>
        </SidebarProvider>
      </div>
    </div>
  );
}

function StoreGate({ children }: { children: React.ReactNode }) {
  const { t } = useTranslation();
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let current = true;
    async function loadLocalData() {
      await recoverLegacyGuestWorkspaceOrphansSafely();
      await Promise.all([
        useBookmarksStore.getState().hydrate(),
        useWorkspaceStore.getState().hydrate(),
        useGroupsStore.getState().hydrate(),
        useSettingsStore.getState().hydrate(),
      ]);
      await useWorkspaceStore.getState().initializeGuestWorkspace();
      void usePlanStore.getState().refreshUsage();
    }
    void loadLocalData().then(() => {
      if (current) {
        setReady(true);
      }
    }).catch((error) => {
      console.error("vWeb local storage could not be opened", error);
      if (current) { setFailed(true); }
    });
    return () => { current = false; };
  }, []);

  if (failed) {
    return (
      <p role="alert" className="p-6 text-destructive">{t("workspaceManager_loadingFailed")}</p>
    );
  }
  if (!ready) {
    return (
      <div className="flex items-center justify-center h-svh bg-background">
        <Loader2 className="size-6 animate-spin text-muted-foreground" />
      </div>
    );
  }
  return <>{children}</>;
}

/**
 * The dashboard is web-accessible to localhost for development.
 * Render the dashboard only in top-level browser tabs.
 */
function isFramed(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    // Cross-origin access to window.top throws in some embedding contexts —
    // treat that as framed too, since we can't prove otherwise.
    return true;
  }
}

export default function App() {
  useEffect(() => {
    if (isFramed()) {
      try {
        window.top!.location.href = window.self.location.href;
      } catch {
        // Embedder's sandbox blocks top navigation — fall through to the
        // blocked render below instead of leaving the framed dashboard live.
      }
    }
  }, []);

  if (isFramed()) {
    return null;
  }

  return <AppRoutes />;
}

function AppRoutes() {
  useEffect(subscribeToSystemMapStorage, []);

  useEffect(() => {
    const listener = (message: ExtensionMessage) => {
      if (message.type === "ADD_BOOKMARK") {
        useBookmarksStore.getState().addBookmark(message.data);
      }
      if (message.type === "BOOKMARKS_CHANGED") {
        void useBookmarksStore.getState().reloadActive();
      }
      if (message.type === "WORKSPACE_CHANGED") {
        useWorkspaceStore.getState().hydrate();
      }
      if (message.type === "TABS_CHANGED") {
        useTabsStore.getState().loadTabs(true);
      }
      if (message.type === "OPEN_SEARCH") {
        window.dispatchEvent(new CustomEvent("tabslate-focus-search"));
      }
      if (message.type === "BOOKMARKS_CHANGED") {
        void usePlanStore.getState().refreshUsage();
      }
      if (message.type === "LOCAL_BACKUP_RESTORED") {
        location.reload();
      }
    };
    chrome.runtime.onMessage.addListener(listener);
    return () => chrome.runtime.onMessage.removeListener(listener);
  }, []);

  return (
    <ThemeProvider>
      <StoreGate>
        <QuotaAlert />
        <HashRouter>
          <TabsDndProvider>
            <Routes>
              <Route path="/" element={<Layout />}>
                <Route index element={<BookmarksContent />} />
                <Route path={DASHBOARD_ROUTES.favorites} element={<FavoritesContent />} />
                <Route path={DASHBOARD_ROUTES.archive} element={<ArchiveContent />} />
                <Route path={DASHBOARD_ROUTES.trash} element={<TrashContent />} />
                <Route path={DASHBOARD_ROUTES.tabs} element={<TabsPanel />} />
                <Route path={DASHBOARD_ROUTES["saved-group"]} element={<GroupDetail />} />
              </Route>
            </Routes>
          </TabsDndProvider>
        </HashRouter>
      </StoreGate>
    </ThemeProvider>
  );
}
