import React from "react";
import ReactDOM from "react-dom/client";
import { InterfaceDirection } from "@/components/interface-direction";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "@fontsource/inter/700.css";
import "@/assets/globals.css";
import App from "./App.tsx";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <InterfaceDirection>
      <App />
    </InterfaceDirection>
  </React.StrictMode>
);
