import React from "react";
import ReactDOM from "react-dom/client";
import { InterfaceDirection } from "@/components/interface-direction";
import App from "./App.tsx";
import "@/assets/globals.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <InterfaceDirection>
      <App />
    </InterfaceDirection>
  </React.StrictMode>
);
