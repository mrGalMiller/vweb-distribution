import { generateId } from "@/lib/id";
import { idbPut } from "@/lib/idb";
import { getAllTabs, focusTab } from "@/lib/chrome/tabs";
import { supportsDynamicContentScripts } from "@/lib/browser/capabilities";
import { runWebSearch } from "@/lib/browser/search";
import { searchLocalBookmarks } from "@/lib/local-bookmark-search";
import type { ExtensionMessage } from "@/lib/messages";
import { SearchOverlaySessionStore } from "@/lib/search-overlay-session";

export default defineBackground(() => {
  const searchOverlaySessions = new SearchOverlaySessionStore();

  // Retire credentials and cached service metadata without touching browsing data.
  function removeLegacyServiceState() {
    void Promise.all([
      chrome.storage.local.remove(["tabslate-auth", "tabslate-plan", "tabslate-analytics-id"]),
      chrome.storage.session?.remove("tabslate-auth-token"),
    ]).catch((error) => console.error("Could not remove legacy service state", error));
  }

  chrome.runtime.onInstalled.addListener(removeLegacyServiceState);
  chrome.runtime.onStartup.addListener(removeLegacyServiceState);

  // -------------------------------------------------------------------------
  // Dynamic Content Script Registration for Search Overlay
  // -------------------------------------------------------------------------
  async function syncContentScriptRegistration() {
    if (!supportsDynamicContentScripts() || !chrome.scripting) {
      return;
    }

    const scripting = chrome.scripting;

    try {
      const hasPermission = await chrome.permissions.contains({ origins: ["<all_urls>"] });
      const scripts = await scripting.getRegisteredContentScripts();
      const isRegistered = scripts.some(s => s.id === "search-overlay");

      if (hasPermission && !isRegistered) {
        await scripting.registerContentScripts([{
          id: "search-overlay",
          matches: ["<all_urls>"],
          js: ["content-scripts/content.js"],
          runAt: "document_idle",
        }]);
      } else if (!hasPermission && isRegistered) {
        await scripting.unregisterContentScripts({ ids: ["search-overlay"] });
      }
    } catch (err) {
      console.error("[vWeb] Failed to sync content script registration:", err);
    }
  }

  chrome.runtime.onInstalled.addListener(syncContentScriptRegistration);
  chrome.runtime.onStartup.addListener(syncContentScriptRegistration);
  chrome.permissions.onAdded.addListener(syncContentScriptRegistration);
  chrome.permissions.onRemoved.addListener(syncContentScriptRegistration);

  // -------------------------------------------------------------------------
  // Context menus — registered once on install / update
  // -------------------------------------------------------------------------
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({
        id: "save-to-tabslate",
        title: chrome.i18n.getMessage("contextMenu_saveToVWeb") || "Save to vWeb",
        contexts: ["page", "selection", "link"],
      });
    });
  });

  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId !== "save-to-tabslate" || !tab?.id) { return; }

    // Try to get richer info from the content script
    let pageInfo: { title: string; url: string; selectedText: string; favicon: string; ogTitle?: string; metaDescription?: string } | null = null;
    try {
      pageInfo = await chrome.tabs.sendMessage(tab.id, { type: "GET_PAGE_INFO" });
    } catch {
      // content script not injected (e.g. pdf, chrome:// page) — fall back to tab info
    }

    const bookmarkData = {
      title: pageInfo?.ogTitle || pageInfo?.title || tab.title || "Untitled",
      url: info.linkUrl ?? pageInfo?.url ?? tab.url ?? "",
      favicon: pageInfo?.favicon ?? tab.favIconUrl ?? "",
      description: pageInfo?.selectedText || pageInfo?.metaDescription || "",
      collectionId: "",
      tags: [] as string[],
      seq: 0,
    };

    // Primary path: send to the dashboard so the saved item appears immediately
    const [newtabTab] = await chrome.tabs.query({ url: chrome.runtime.getURL("newtab.html") });
    if (newtabTab?.id) {
      try {
        await chrome.tabs.sendMessage(newtabTab.id, { type: "ADD_BOOKMARK", data: bookmarkData });
        return;
      } catch { /* newtab not ready, fall through to storage */ }
    }

    // Fallback: write directly to IDB (hydrate() will pick it up on next newtab open)
    const fullBookmark = {
      id: generateId(),
      createdAt: new Date().toISOString(),
      isFavorite: false,
      ...bookmarkData,
    };
    try {
      await idbPut("bookmarks", fullBookmark);
    } catch (err) {
      console.error("[vWeb] IDB write failed in bookmark fallback:", err);
      return;
    }
    chrome.runtime.sendMessage({ type: "BOOKMARKS_CHANGED" } as ExtensionMessage).catch(() => {});
  });

  // -------------------------------------------------------------------------
  // Tab events — broadcast signal so newtab page can react
  // -------------------------------------------------------------------------
  let _broadcastTabChangeTimer: ReturnType<typeof setTimeout> | null = null;
  function broadcastTabChange() {
    if (_broadcastTabChangeTimer) {
      clearTimeout(_broadcastTabChangeTimer);
    }
    _broadcastTabChangeTimer = setTimeout(() => {
      _broadcastTabChangeTimer = null;
      chrome.runtime.sendMessage({ type: "TABS_CHANGED" } as ExtensionMessage).catch(() => {});
    }, 100);
  }

  chrome.tabs.onCreated.addListener(broadcastTabChange);
  chrome.tabs.onRemoved.addListener(broadcastTabChange);
  chrome.tabs.onUpdated.addListener((_, info) => {
    if (info.status === "complete" || info.title !== undefined || info.groupId !== undefined) {
      broadcastTabChange();
    }
  });
  chrome.tabs.onActivated.addListener(broadcastTabChange);
  chrome.tabs.onMoved.addListener(broadcastTabChange);

  chrome.tabGroups.onCreated.addListener(broadcastTabChange);
  chrome.tabGroups.onRemoved.addListener(broadcastTabChange);
  chrome.tabGroups.onUpdated.addListener(broadcastTabChange);
  chrome.tabGroups.onMoved.addListener(broadcastTabChange);

  // -------------------------------------------------------------------------
  // Global search shortcut — send OPEN_SEARCH to active tab, fallback to popup
  // -------------------------------------------------------------------------
  chrome.commands.onCommand.addListener(async (command) => {
    if (command !== "open-search") { return; }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) { return; }

    // Silently ignore if content script is not injectable (chrome://, pdf, etc.)
    chrome.tabs.sendMessage(tab.id, { type: "OPEN_SEARCH" } as ExtensionMessage).catch(() => {});
  });

  // -------------------------------------------------------------------------
  // Message routing for content script — proxy tab APIs
  // -------------------------------------------------------------------------
  function getSenderTabID(sender: chrome.runtime.MessageSender): number | null {
    return typeof sender.tab?.id === "number" ? sender.tab.id : null;
  }

  function isSearchOverlaySender(sender: chrome.runtime.MessageSender): boolean {
    return sender.url?.startsWith(chrome.runtime.getURL("search-overlay.html")) === true;
  }

  function isContentScriptSender(sender: chrome.runtime.MessageSender): boolean {
    return getSenderTabID(sender) !== null && !sender.url?.startsWith(chrome.runtime.getURL(""));
  }

  chrome.runtime.onMessage.addListener((message: ExtensionMessage, sender, sendResponse) => {
    const senderTabID = getSenderTabID(sender);
    if (message.type === "REGISTER_SEARCH_OVERLAY_SESSION") {
      const registered = senderTabID !== null && isContentScriptSender(sender)
        ? searchOverlaySessions.register(message.session, senderTabID)
        : false;
      sendResponse({ ok: registered });
      return false;
    }
    if (message.type === "VALIDATE_SEARCH_OVERLAY_SESSION") {
      const valid = senderTabID !== null && isSearchOverlaySender(sender)
        ? searchOverlaySessions.validate(message.session, senderTabID)
        : false;
      sendResponse({ ok: valid });
      return false;
    }
    if (message.type === "REVOKE_SEARCH_OVERLAY_SESSION") {
      const revoked = senderTabID !== null && isContentScriptSender(sender)
        ? searchOverlaySessions.revoke(message.session, senderTabID)
        : false;
      sendResponse({ ok: revoked });
      return false;
    }

    if (!("session" in message)) {
      return false;
    }

    const authorized = senderTabID !== null && isSearchOverlaySender(sender) &&
      searchOverlaySessions.validate(message.session, senderTabID);
    if (!authorized) {
      sendResponse({ ok: false });
      return false;
    }

    if (message.type === "GET_OPEN_TABS") {
      getAllTabs().then(sendResponse);
      return true;
    }
    if (message.type === "FOCUS_TAB") {
      focusTab(message.tabId, message.windowId).then(() => sendResponse({ ok: true }));
      return true;
    }
    if (message.type === "OPEN_TAB") {
      chrome.tabs.create({ url: message.url }).then(() => sendResponse({ ok: true }));
      return true;
    }
    if (message.type === "SEARCH_BOOKMARKS") {
      void searchLocalBookmarks(message.query)
        .then((bookmarks) => sendResponse({ ok: true, bookmarks }))
        .catch(() => sendResponse({ ok: false, bookmarks: [] }));
      return true; // keep channel open for async response
    }
    if (message.type === "WEB_SEARCH") {
      runWebSearch({ text: message.query, disposition: "NEW_TAB" })
        .then(() => sendResponse({ ok: true }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
  });
});
