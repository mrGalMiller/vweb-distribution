import { create } from "zustand";
import type { PlanLimits, PlanUsage } from "@/lib/quota-types";
import { idbTransaction } from "@/lib/idb";
import {
  calculateGuestQuotaUsage,
  createQuotaBreakdown,
  createZeroPlanUsage,
  type QuotaUsageBreakdown,
} from "@/lib/quota-usage";

export type QuotaResource = "bookmark" | "collection" | "tag" | "workspace" | "saved_group";

interface QuotaAlert {
  resource: QuotaResource;
  limit: number;
}

interface PlanState {
  limits: PlanLimits;
  usage: PlanUsage | null;
  trashUsage: PlanUsage | null;
  inUseUsage: PlanUsage | null;
  isFetching: boolean;
  quotaAlert: QuotaAlert | null;
  refreshUsage: () => Promise<void>;
  checkQuota: (resource: QuotaResource, currentCount?: number) => boolean;
  incrementUsage: (resource: QuotaResource, by?: number) => void;
  decrementUsage: (resource: QuotaResource, by?: number) => void;
  moveUsageToTrash: (resource: QuotaResource, by?: number) => void;
  restoreUsageFromTrash: (resource: QuotaResource, by?: number) => void;
  setGuestUsage: (breakdown: QuotaUsageBreakdown) => void;
  showQuotaAlert: (resource: QuotaResource) => void;
}

const LIMIT_KEY: Record<QuotaResource, keyof PlanLimits> = {
  bookmark:    "max_bookmarks",
  collection:  "max_collections",
  tag:         "max_tags",
  workspace:   "max_workspaces",
  saved_group: "max_saved_groups",
};

const USAGE_KEY: Record<QuotaResource, keyof PlanUsage> = {
  bookmark:    "bookmarks",
  collection:  "collections",
  tag:         "tags",
  workspace:   "workspaces",
  saved_group: "saved_groups",
};

// Preserve the extension's existing standalone quota policy.
export const LOCAL_LIMITS: PlanLimits = {
  max_workspaces: -1,
  max_bookmarks: -1,
  max_collections: -1,
  max_tags: -1,
  max_saved_groups: -1,
  trash_grace_days: -1,
};

const QUOTA_STORES = {
  workspaces: "workspaces",
  collections: "collections",
  bookmarks: "bookmarks",
  archivedBookmarks: "archived-bookmarks",
  trashedBookmarks: "trashed-bookmarks",
  groups: "groups",
  tags: "tags",
} as const;

let alertTimer: ReturnType<typeof setTimeout> | null = null;
let refreshGeneration = 0;

export const usePlanStore = create<PlanState>()((set, get) => ({
  limits: LOCAL_LIMITS,
  usage: null,
  trashUsage: null,
  inUseUsage: null,
  isFetching: false,
  quotaAlert: null,

  refreshUsage: async () => {
    const generation = ++refreshGeneration;
    set({ isFetching: true });
    try {
      const input = await idbTransaction(Object.values(QUOTA_STORES), "readonly", (tx) => {
        const counts: Parameters<typeof calculateGuestQuotaUsage>[0] = {
          workspaces: [], collections: [], bookmarks: [], archivedBookmarks: [],
          trashedBookmarks: [], groups: [], tags: [],
        };
        for (const key of Object.keys(QUOTA_STORES) as Array<keyof typeof QUOTA_STORES>) {
          const request = tx.objectStore(QUOTA_STORES[key]).getAll();
          request.onsuccess = () => { counts[key] = request.result; };
        }
        return counts;
      });
      if (generation === refreshGeneration) {
        get().setGuestUsage(calculateGuestQuotaUsage(input));
      }
    } catch (error) {
      console.error("Could not read local quotas", error);
    } finally {
      if (generation === refreshGeneration) {
        set({ isFetching: false });
      }
    }
  },

  checkQuota: (resource, currentCount) => {
    const { limits, usage } = get();
    const limit = limits[LIMIT_KEY[resource]];
    return limit === -1 || (currentCount ?? usage?.[USAGE_KEY[resource]] ?? 0) < limit;
  },

  incrementUsage: (resource, by = 1) => {
    set((s) => {
      if (!s.usage) { return {}; }
      const key = USAGE_KEY[resource];
      const total = { ...s.usage, [key]: s.usage[key] + by };
      const breakdown = createQuotaBreakdown(
        total,
        s.trashUsage ?? createZeroPlanUsage(),
      );
      return {
        usage: breakdown.total,
        trashUsage: breakdown.trash,
        inUseUsage: breakdown.inUse,
      };
    });
  },

  decrementUsage: (resource, by = 1) => {
    set((s) => {
      if (!s.usage) { return {}; }
      const key = USAGE_KEY[resource];
      const total = { ...s.usage, [key]: Math.max(0, s.usage[key] - by) };
      const currentTrash = s.trashUsage ?? createZeroPlanUsage();
      const trash = {
        ...currentTrash,
        [key]: Math.max(0, currentTrash[key] - by),
      };
      const breakdown = createQuotaBreakdown(
        total,
        trash,
      );
      return {
        usage: breakdown.total,
        trashUsage: breakdown.trash,
        inUseUsage: breakdown.inUse,
      };
    });
  },

  moveUsageToTrash: (resource, by = 1) => {
    set((state) => {
      if (!state.usage) { return {}; }
      const key = USAGE_KEY[resource];
      const currentTrash = state.trashUsage ?? createZeroPlanUsage();
      const breakdown = createQuotaBreakdown(state.usage, {
        ...currentTrash,
        [key]: currentTrash[key] + by,
      });
      return {
        usage: breakdown.total,
        trashUsage: breakdown.trash,
        inUseUsage: breakdown.inUse,
      };
    });
  },

  restoreUsageFromTrash: (resource, by = 1) => {
    set((state) => {
      if (!state.usage) { return {}; }
      const key = USAGE_KEY[resource];
      const currentTrash = state.trashUsage ?? createZeroPlanUsage();
      const breakdown = createQuotaBreakdown(state.usage, {
        ...currentTrash,
        [key]: Math.max(0, currentTrash[key] - by),
      });
      return {
        usage: breakdown.total,
        trashUsage: breakdown.trash,
        inUseUsage: breakdown.inUse,
      };
    });
  },

  setGuestUsage: (breakdown) => {
    set({
      usage: breakdown.total,
      trashUsage: breakdown.trash,
      inUseUsage: breakdown.inUse,
    });
  },

  showQuotaAlert: (resource) => {
    if (alertTimer !== null) { clearTimeout(alertTimer); }
    const limit = get().limits[LIMIT_KEY[resource]];
    set({ quotaAlert: { resource, limit } });
    alertTimer = setTimeout(() => {
      set({ quotaAlert: null });
      alertTimer = null;
    }, 3000);
  },

}));

export function guardQuota<T>(
  resource: QuotaResource,
  currentCount: number | undefined,
  fallback: T,
  action: () => T,
): T {
  const store = usePlanStore.getState();
  if (!store.checkQuota(resource, currentCount)) {
    store.showQuotaAlert(resource);
    return fallback;
  }
  return action();
}
