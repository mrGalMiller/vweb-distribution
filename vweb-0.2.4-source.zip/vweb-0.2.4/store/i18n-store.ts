import { create } from "zustand";
import { persist } from "zustand/middleware";
import { browser } from "wxt/browser";

export type SupportedLanguage = "auto" | "en" | "he";
export type DirectionPreference = "auto" | "ltr" | "rtl";
export const I18N_STORAGE_KEY = "tabslate-i18n";

interface I18nState {
  language: SupportedLanguage;
  directionPreference: DirectionPreference;
  messages: Record<string, { message: string }> | null;
  isHydrated: boolean;
  setLanguage: (lang: SupportedLanguage) => Promise<void>;
  setDirectionPreference: (direction: DirectionPreference) => void;
  _hasHydrated: () => void;
}

export function resolveAcceptLanguage(lang: SupportedLanguage): string {
  if (lang === "en") return "en";
  if (lang === "he") return "he";
  return navigator.language;
}

export function resolveInterfaceLanguage(language: SupportedLanguage): string {
  if (language === "auto") {
    const browserLanguage = browser.i18n.getUILanguage();
    return /^zh(?:[-_]|$)/i.test(browserLanguage) ? "en" : browserLanguage;
  }

  return resolveAcceptLanguage(language);
}

export function resolveInterfaceDirection(
  preference: DirectionPreference,
  locale: string,
): "ltr" | "rtl" {
  if (preference !== "auto") {
    return preference;
  }

  return /^(he|iw)(?:[-_]|$)/i.test(locale) ? "rtl" : "ltr";
}

export const useI18nStore = create<I18nState>()(
  persist(
    (set) => ({
      language: "auto",
      directionPreference: "auto",
      messages: null,
      isHydrated: false,
      setDirectionPreference: (directionPreference) => set({ directionPreference }),
      setLanguage: async (lang) => {
        // Persisted settings from older builds can contain a removed locale.
        if (lang !== "en" && lang !== "he") {
          set({ language: "auto", messages: null });
          return;
        }
        
        try {
          const url = browser.runtime.getURL(`/_locales/${lang}/messages.json`);
          const response = await fetch(url);
          if (!response.ok) {
            throw new Error(`Locale request failed: ${response.status}`);
          }
          const data = await response.json();
          set({ language: lang, messages: data });
        } catch (err) {
          console.error(`Failed to load locales for ${lang}:`, err);
          // Fallback to auto if loading fails
          set({ language: "auto", messages: null });
        }
      },
      _hasHydrated: () => {
        set({ isHydrated: true });
      }
    }),
    {
      name: I18N_STORAGE_KEY,
      onRehydrateStorage: () => (state) => {
        if (state) {
          // Re-fetch the language file on load to ensure it's up to date
          // if a specific language is set.
          if (state.language !== "auto") {
            state.setLanguage(state.language).then(() => {
              state._hasHydrated();
            });
          } else {
            state._hasHydrated();
          }
        }
      },
    }
  )
);
