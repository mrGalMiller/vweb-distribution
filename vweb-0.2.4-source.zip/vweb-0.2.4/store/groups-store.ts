import { create } from "zustand";
import type { TabGroupColor } from "@/lib/chrome/tab-groups";
import { openAsTabGroup } from "@/lib/chrome/tab-groups";
import { generateId } from "@/lib/id";
import { idbGetAll, idbGet, idbPut, idbDelete, idbBulkWrite, type BulkWriteOp } from "@/lib/idb";
import { usePlanStore, guardQuota } from "@/store/plan-store";
import { normalizeFavicon } from "@/lib/bookmark-utils";
import type { WorkspaceAggregateIds } from "@/lib/workspace-aggregate";

export interface GroupTab {
  id: string;
  groupId: string;
  title: string;
  url: string;
  favicon: string;
  position: number;
}

export interface SavedGroup {
  id: string;
  name: string;
  color: TabGroupColor;
  isCompact: boolean;
  createdAt: string;
  seq: number;        // Kept for compatibility with older local records
  deletedAt?: number; // unix ms; undefined = alive
  workspaceId: string;
}

export interface GroupPurgeResult {
  status: "completed" | "blocked";
  reason?: "not_deleted" | "offline" | "pending" | "rejected" | "storage";
}

interface GroupsState {
  groups: SavedGroup[];
  groupTabs: GroupTab[];
  _hydrated: boolean;
  hydrate: () => Promise<void>;
  reset: () => void;

  // Group CRUD
  createGroup: (name: string, color: TabGroupColor, isCompact: boolean, workspaceId: string) => string;
  updateGroup: (id: string, patch: Partial<Pick<SavedGroup, "name" | "color" | "isCompact">>) => void;
  deleteGroup: (id: string) => void;
  restoreGroup: (id: string) => void;
  permanentlyDeleteGroup: (id: string) => Promise<GroupPurgeResult>;

  // Tab management
  addTabToGroup: (groupId: string, tab: { title: string; url: string; favicon: string }) => void;
  removeTabFromGroup: (tabId: string) => void;
  moveTab: (tabId: string, toGroupId: string) => void;
  deleteTabFromTrash: (tabId: string) => void;

  // Open
  openGroup: (groupId: string) => Promise<void>;

  // Sync
  removeWorkspaceAggregateFromState: (ids: WorkspaceAggregateIds) => void;
}

const pendingPermanentGroupIds = new Set<string>();

export const useGroupsStore = create<GroupsState>()((set, get) => ({
  groups: [],
  groupTabs: [],
  _hydrated: false,
  hydrate: async () => {
    const [allGroups, groupTabs] = await Promise.all([
      idbGetAll<SavedGroup>("groups"),
      idbGetAll<GroupTab>("group-tabs"),
    ]);
    const groups = allGroups.filter(g => {
      if (!g.workspaceId) {
        idbDelete("groups", g.id);
        return false;
      }
      return true;
    });
    const faviconMigrated = await idbGet<{ key: string; value: boolean }>("kv", "favicon-migrated-groups-v1");
    const migratedTabs = faviconMigrated?.value
      ? groupTabs
      : groupTabs.map((t): GroupTab => {
          if (!t.favicon.startsWith("data:")) {
            return t;
          }
          const favicon = normalizeFavicon(t.favicon);
          if (favicon === t.favicon) { return t; }
          const fixed = { ...t, favicon };
          void idbPut("group-tabs", fixed);
          return fixed;
        });
    if (!faviconMigrated?.value) {
      await idbPut("kv", { key: "favicon-migrated-groups-v1", value: true });
    }
    set({ groups, groupTabs: migratedTabs, _hydrated: true });
  },

  reset: () => {
    set({ groups: [], groupTabs: [], _hydrated: true });
  },

  createGroup: (name, color, isCompact, workspaceId) =>
    guardQuota("saved_group", get().groups.length, "", () => {
      const id = generateId();
      const group: SavedGroup = { id, name, color, isCompact, createdAt: new Date().toISOString(), seq: 0, workspaceId };
      set((state) => ({ groups: [...state.groups, group] }));
      idbPut("groups", group);
      usePlanStore.getState().incrementUsage("saved_group");
      return id;
    }),

  updateGroup: (id, patch) => {
    const oldGroup = get().groups.find(g => g.id === id);
    const oldName = oldGroup?.name;

    set((state) => ({
      groups: state.groups.map((g) =>
        g.id === id ? { ...g, ...patch } : g
      ),
    }));
    const updated = get().groups.find(g => g.id === id);
    if (updated) { idbPut("groups", updated); }

    // Sync to open Chrome tab groups
    if (oldName && (patch.name !== undefined || patch.color !== undefined || patch.isCompact !== undefined)) {
      import("./tabs-store").then(({ useTabsStore }) => {
        const { tabGroups, fullTitles, updateGroup: updateChromeGroup, toggleGroupCompact } = useTabsStore.getState();
        const chromeGroup = tabGroups.find(g => (fullTitles[g.id] || g.title) === oldName);
        if (chromeGroup) {
          const chromePatch: { title?: string; color?: TabGroupColor } = {};
          if (patch.name !== undefined && (fullTitles[chromeGroup.id] || chromeGroup.title) !== patch.name) {
            chromePatch.title = patch.name;
          }
          if (patch.color !== undefined && chromeGroup.color !== patch.color) {
            chromePatch.color = patch.color;
          }
          if (Object.keys(chromePatch).length > 0) {
            updateChromeGroup(chromeGroup.id, chromePatch);
          }
          
          if (patch.isCompact !== undefined) {
             const actualFullTitle = fullTitles[chromeGroup.id] || chromeGroup.title;
             const isCurrentlyCompact = chromeGroup.title.length === 1 && actualFullTitle.length > 1;
             // If Chrome tab group compact state doesn't match the new desired state
             if (patch.isCompact !== isCurrentlyCompact) {
                 toggleGroupCompact(chromeGroup.id);
             }
          }
        }
      });
    }
  },

  deleteGroup: (id) => {
    const group = get().groups.find(g => g.id === id);
    if (!group || group.deletedAt) { return; }
    const deletedGroup = { ...group, deletedAt: Date.now() };
    idbPut("groups", deletedGroup);
    // Tabs are kept in IDB and state so they can be restored later.
    set((state) => ({
      groups: state.groups.map(g => g.id === id ? deletedGroup : g),
    }));
    usePlanStore.getState().moveUsageToTrash("saved_group");
  },

  restoreGroup: (id) => {
    const group = get().groups.find(g => g.id === id);
    if (!group || !group.deletedAt) { return; }
    const restored: SavedGroup = { ...group, deletedAt: undefined, seq: 0 };
    idbPut("groups", restored);
    set((state) => ({ groups: state.groups.map(g => g.id === id ? restored : g) }));
    usePlanStore.getState().restoreUsageFromTrash("saved_group");
  },

  permanentlyDeleteGroup: async (id) => {
    if (pendingPermanentGroupIds.has(id)) {
      return { status: "blocked", reason: "pending" };
    }
    const group = get().groups.find(candidate => candidate.id === id);
    if (!group) {
      return { status: "completed" };
    }
    if (!group.deletedAt) {
      return { status: "blocked", reason: "not_deleted" };
    }
    const tabs = get().groupTabs.filter(tab => tab.groupId === id);
    pendingPermanentGroupIds.add(id);
    try {
      const operations: BulkWriteOp[] = [
        ...tabs.map((tab): BulkWriteOp => ({
          type: "delete",
          store: "group-tabs",
          key: tab.id,
        })),
        { type: "delete", store: "groups", key: id },
      ];
      try {
        await idbBulkWrite(operations);
      } catch {
        return { status: "blocked", reason: "storage" };
      }
      set((state) => ({
        groups: state.groups.filter(candidate => candidate.id !== id),
        groupTabs: state.groupTabs.filter(tab => tab.groupId !== id),
      }));
      usePlanStore.getState().decrementUsage("saved_group");
      return { status: "completed" };
    } finally {
      pendingPermanentGroupIds.delete(id);
    }
  },

  deleteTabFromTrash: (tabId) => {
    idbDelete("group-tabs", tabId);
    set((state) => ({ groupTabs: state.groupTabs.filter(t => t.id !== tabId) }));
  },

  addTabToGroup: (groupId, tab) => {
    if (!groupId) { return; }
    const { groupTabs } = get();
    const existing = groupTabs.find(t => t.groupId === groupId && t.url === tab.url);
    if (existing) { return; }
    const position = groupTabs.filter(t => t.groupId === groupId).length;
    const newTab: GroupTab = { id: generateId(), groupId, ...tab, position };
    const newGroupTabs = [...groupTabs, newTab];
    set(() => ({ groupTabs: newGroupTabs }));
    idbPut("group-tabs", newTab);
  },

  removeTabFromGroup: (tabId) => {
    idbDelete("group-tabs", tabId);
    set((state) => ({ groupTabs: state.groupTabs.filter(t => t.id !== tabId) }));
  },

  moveTab: (tabId, toGroupId) => {
    const { groupTabs } = get();
    const existingTab = groupTabs.find(t => t.id === tabId);
    if (!existingTab || existingTab.groupId === toGroupId) { return; }

    const position = groupTabs.filter(t => t.groupId === toGroupId).length;
    const movedTab = { ...existingTab, groupId: toGroupId, position };
    const updatedTabs = groupTabs.map(t => t.id === tabId ? movedTab : t);

    set(() => ({ groupTabs: updatedTabs }));
    idbPut("group-tabs", movedTab);
  },

  openGroup: async (groupId) => {
    const { groups, groupTabs } = get();
    const group = groups.find((g) => g.id === groupId);
    if (!group) { return; }
    const urls = groupTabs
      .filter((t) => t.groupId === groupId)
      .sort((a, b) => a.position - b.position)
      .map((t) => t.url);
    if (!urls.length) { return; }
    const chromeGroupId = await openAsTabGroup(urls, group.name, group.color, group.isCompact);
    
    // Register the full title in tabs-store so it can sync properly later
    const { useTabsStore } = await import("./tabs-store");
    const { registerGroupFullTitle } = useTabsStore.getState();
    if (registerGroupFullTitle) {
      await registerGroupFullTitle(chromeGroupId, group.name);
    }
  },

  removeWorkspaceAggregateFromState: (ids) => {
    const groupIds = new Set(ids.groupIds);
    const groupTabIds = new Set(ids.groupTabIds);
    set((state) => ({
      groups: state.groups.filter((group) => !groupIds.has(group.id)),
      groupTabs: state.groupTabs.filter(
        (tab) => !groupIds.has(tab.groupId) && !groupTabIds.has(tab.id),
      ),
    }));
  },

}));
