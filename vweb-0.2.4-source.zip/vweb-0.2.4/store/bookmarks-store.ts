import { create } from "zustand";
import type { Bookmark } from "@/lib/types";
import { generateId } from "@/lib/id";
import { idbGet, idbGetAll, idbGetByIndex, idbGetMany, idbPut, idbDelete, idbBulkWrite, type BulkWriteOp } from "@/lib/idb";
import { usePlanStore, guardQuota } from "@/store/plan-store";
import {
  compareBookmarksNewestFirst,
  compareBookmarksTrashedFirst,
  normalizeFavicon,
} from "@/lib/bookmark-utils";
import type { WorkspaceAggregateIds } from "@/lib/workspace-aggregate";

export type { Bookmark };

type ViewMode = "grid" | "list";
type SortBy = "date-newest" | "date-oldest" | "alpha-az" | "alpha-za";
type FilterType = "all" | "favorites" | "with-tags" | "without-tags";
type BookmarkStoreName = "bookmarks" | "archived-bookmarks" | "trashed-bookmarks";

interface TrashedBookmarkRecord extends Bookmark {
  isTrashed?: number;
}

let _bookmarkHighlightTimer: ReturnType<typeof setTimeout> | null = null;
let _bookmarksArrayCache: Bookmark[] | null = null;
let _bookmarksArrayCacheSource: Map<string, Bookmark> | null = null;

export function bookmarksAsArray(map: Map<string, Bookmark>): Bookmark[] {
  if (_bookmarksArrayCacheSource === map && _bookmarksArrayCache !== null) {
    return _bookmarksArrayCache;
  }
  _bookmarksArrayCache = Array.from(map.values());
  _bookmarksArrayCacheSource = map;
  return _bookmarksArrayCache;
}

function recomputeCounts(map: Map<string, Bookmark>): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const bookmark of map.values()) {
    counts[bookmark.collectionId] = (counts[bookmark.collectionId] ?? 0) + 1;
  }
  return counts;
}

function incrementCollectionCount(counts: Record<string, number>, collectionId: string, delta = 1): void {
  if (delta <= 0) {
    return;
  }
  counts[collectionId] = (counts[collectionId] ?? 0) + delta;
}

function decrementCollectionCount(counts: Record<string, number>, collectionId: string, delta = 1): void {
  if (delta <= 0) {
    return;
  }
  const nextValue = (counts[collectionId] ?? 0) - delta;
  if (nextValue <= 0) {
    delete counts[collectionId];
    return;
  }
  counts[collectionId] = nextValue;
}

function setCollectionCount(counts: Record<string, number>, collectionId: string, value: number): void {
  if (value <= 0) {
    delete counts[collectionId];
    return;
  }
  counts[collectionId] = value;
}

function buildEffectiveIncomingBookmarks(bookmarks: Bookmark[]): Map<string, Bookmark> {
  const effectiveBookmarks = new Map<string, Bookmark>();
  for (const bookmark of bookmarks) {
    effectiveBookmarks.set(bookmark.id, bookmark);
  }
  return effectiveBookmarks;
}

function assertCountsInvariant(
  state: { bookmarks: Map<string, Bookmark>; countsByCollection: Record<string, number> },
): void {
  if (!import.meta.env.DEV) {
    return;
  }
  const expected = recomputeCounts(state.bookmarks);
  const actualEntries = Object.entries(state.countsByCollection).sort(([a], [b]) => a.localeCompare(b));
  const expectedEntries = Object.entries(expected).sort(([a], [b]) => a.localeCompare(b));
  if (actualEntries.length !== expectedEntries.length) {
    throw new Error(
      `countsByCollection drift: expected ${JSON.stringify(expected)}, got ${JSON.stringify(state.countsByCollection)}`,
    );
  }
  for (let index = 0; index < expectedEntries.length; index += 1) {
    const [expectedKey, expectedValue] = expectedEntries[index];
    const [actualKey, actualValue] = actualEntries[index];
    if (expectedKey !== actualKey || expectedValue !== actualValue) {
      throw new Error(
        `countsByCollection drift: expected ${JSON.stringify(expected)}, got ${JSON.stringify(state.countsByCollection)}`,
      );
    }
  }
}

// ---------------------------------------------------------------------------
// Sync helpers
// ---------------------------------------------------------------------------
function applySearch(bookmarks: Bookmark[], query: string): Bookmark[] {
  if (!query) return bookmarks;
  const lower = query.toLowerCase();
  return bookmarks.filter(
    (b) =>
      b.title.toLowerCase().includes(lower) ||
      b.description.toLowerCase().includes(lower) ||
      b.url.toLowerCase().includes(lower)
  );
}

/**
 * Bookmarks saved in one batch share a timestamp, so every comparison needs a
 * tiebreaker to stay deterministic across reloads.
 */
function applySort(bookmarks: Bookmark[], sortBy: SortBy): Bookmark[] {
  const arr = [...bookmarks];
  const byId = (a: Bookmark, b: Bookmark) => a.id.localeCompare(b.id);
  switch (sortBy) {
    case "date-newest":
      return arr.sort(compareBookmarksNewestFirst);
    case "date-oldest":
      return arr.sort((a, b) => -compareBookmarksNewestFirst(a, b));
    case "alpha-az":
      return arr.sort((a, b) => a.title.localeCompare(b.title) || byId(a, b));
    case "alpha-za":
      return arr.sort((a, b) => b.title.localeCompare(a.title) || byId(a, b));
    default:
      return arr;
  }
}

function migrateBookmarkForStore(store: BookmarkStoreName, bookmark: Bookmark): Bookmark {
  if (!bookmark.favicon.startsWith("data:")) {
    return bookmark;
  }
  const favicon = normalizeFavicon(bookmark.favicon);
  if (favicon === bookmark.favicon) { return bookmark; }
  const fixed = { ...bookmark, favicon };
  void idbPut(store, fixed);
  return fixed;
}

async function readBookmarkStore(store: BookmarkStoreName): Promise<Bookmark[]> {
  const bookmarks = await idbGetAll<Bookmark>(store);
  return bookmarks.map((bookmark) => migrateBookmarkForStore(store, bookmark));
}

async function readArchivedBookmarksForCollection(collectionId: string): Promise<Bookmark[]> {
  const bookmarks = await idbGetByIndex<Bookmark>("archived-bookmarks", "collectionId", collectionId);
  return bookmarks.map((bookmark) => migrateBookmarkForStore("archived-bookmarks", bookmark));
}

async function readBookmarkById(store: BookmarkStoreName, id: string): Promise<Bookmark | undefined> {
  const bookmark = await idbGet<Bookmark>(store, id);
  if (!bookmark || (store === "trashed-bookmarks" && "isTrashed" in bookmark && bookmark.isTrashed === 2)) {
    return undefined;
  }
  return migrateBookmarkForStore(store, bookmark);
}

async function readTrashedBookmarksForCollection(collectionId: string): Promise<Bookmark[]> {
  const bookmarks = await idbGetByIndex<TrashedBookmarkRecord>("trashed-bookmarks", "collectionId", collectionId);
  return bookmarks.filter((bookmark) => bookmark.isTrashed !== 2).map((bookmark) => migrateBookmarkForStore("trashed-bookmarks", bookmark));
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
interface BookmarksState {
  // Data — persisted to IndexedDB
  bookmarks: Map<string, Bookmark>;
  countsByCollection: Record<string, number>;
  archivedBookmarks: Bookmark[];
  trashedBookmarks: Bookmark[];

  // UI state — ephemeral (reset on each session)
  selectedCollection: string;
  /** Bookmark the content list should scroll to and flash, e.g. a detected duplicate. */
  highlightedBookmarkId: string | null;
  selectedTags: string[];
  searchQuery: string;
  viewMode: ViewMode;
  sortBy: SortBy;
  filterType: FilterType;

  // Hydration flag
  _hydrated: boolean;
  _archivedLoaded: boolean;
  _trashedLoaded: boolean;
  hydrate: () => Promise<void>;
  reloadActive: () => Promise<void>;
  loadArchivedBookmarks: () => Promise<void>;
  loadTrashedBookmarks: () => Promise<void>;
  reset: () => void;

  // Actions
  setSelectedCollection: (collectionId: string) => void;
  setHighlightedBookmarkId: (id: string | null, durationMs?: number) => void;
  toggleTag: (tagId: string) => void;
  clearTags: () => void;
  setSearchQuery: (query: string) => void;
  setViewMode: (mode: ViewMode) => void;
  setSortBy: (sort: SortBy) => void;
  setFilterType: (filter: FilterType) => void;

  addBookmark: (input: Omit<Bookmark, "id" | "createdAt" | "isFavorite">) => Bookmark;
  addBookmarks: (bookmarks: Bookmark[]) => void;
  _bulkAddBookmarks: (bookmarks: Bookmark[]) => void;
  updateBookmark: (id: string, patch: Partial<Omit<Bookmark, "id" | "createdAt">>) => void;
  toggleFavorite: (bookmarkId: string) => void;
  archiveBookmark: (bookmarkId: string) => void;
  restoreFromArchive: (bookmarkId: string) => void;
  trashBookmark: (bookmarkId: string) => void;
  restoreFromTrash: (bookmarkId: string, collectionIdOverride?: string) => void;
  permanentlyDelete: (bookmarkId: string) => void;
  permanentlyDeleteBatch: (bookmarkIds: string[]) => void;
  removeWorkspaceAggregateFromState: (ids: WorkspaceAggregateIds) => void;
  archiveCollectionBookmarks: (collectionId: string) => void;
  trashCollectionBookmarks: (collectionId: string) => Promise<void>;
  restoreCollectionBookmarks: (collectionId: string) => void;
  permanentlyDeleteCollectionBookmarks: (collectionId: string) => void;
  reassignCollection: (fromId: string, toId: string) => void;

  // Computed
  getFilteredBookmarks: (workspaceCollectionIds: Set<string>) => Bookmark[];
  getFavoriteBookmarks: () => Bookmark[];
  getArchivedBookmarks: () => Bookmark[];
  getTrashedBookmarks: () => Bookmark[];
}

// ---------------------------------------------------------------------------
// Store
// ---------------------------------------------------------------------------
export const useBookmarksStore = create<BookmarksState>()(
  (set, get) => ({
      bookmarks: new Map(),
      countsByCollection: {},
      archivedBookmarks: [],
      trashedBookmarks: [],

      selectedCollection: "all",
      highlightedBookmarkId: null,
      selectedTags: [],
      searchQuery: "",
      viewMode: "grid",
      sortBy: "date-newest",
      filterType: "all",

      _hydrated: false,
      _archivedLoaded: false,
      _trashedLoaded: false,
      hydrate: async () => {
        const faviconMigrated = await idbGet<{ key: string; value: boolean }>("kv", "favicon-migrated-bookmarks-v1");
        const bookmarks = faviconMigrated?.value ? await idbGetAll<Bookmark>("bookmarks") : await readBookmarkStore("bookmarks");
        if (!faviconMigrated?.value) {
          await idbPut("kv", { key: "favicon-migrated-bookmarks-v1", value: true });
        }
        const map = new Map(bookmarks.map((bookmark) => [bookmark.id, bookmark]));
        set({
          bookmarks: map,
          countsByCollection: recomputeCounts(map),
          _hydrated: true,
        });
      },

      reloadActive: async () => {
        const bookmarks = await readBookmarkStore("bookmarks");
        const map = new Map(bookmarks.map((bookmark) => [bookmark.id, bookmark]));
        set({
          bookmarks: map,
          countsByCollection: recomputeCounts(map),
        });
      },

      loadArchivedBookmarks: async () => {
        if (get()._archivedLoaded) { return; }
        const archived = await readBookmarkStore("archived-bookmarks");
        set({ archivedBookmarks: archived, _archivedLoaded: true });
      },

      loadTrashedBookmarks: async () => {
        if (get()._trashedLoaded) { return; }
        const all = await readBookmarkStore("trashed-bookmarks");
        set({
          trashedBookmarks: all.filter((bookmark) => !("isTrashed" in bookmark && bookmark.isTrashed === 2)),
          _trashedLoaded: true,
        });
      },

      reset: () => {
        set({
          bookmarks: new Map(),
          countsByCollection: {},
          archivedBookmarks: [],
          trashedBookmarks: [],
          selectedCollection: "all",
          selectedTags: [],
          searchQuery: "",
          _hydrated: true,
          _archivedLoaded: false,
          _trashedLoaded: false,
        });
      },

      setSelectedCollection: (collectionId) =>
        set({ selectedCollection: collectionId }),

      setHighlightedBookmarkId: (id, durationMs = 3000) => {
        if (_bookmarkHighlightTimer) { clearTimeout(_bookmarkHighlightTimer); }
        set({ highlightedBookmarkId: id });
        if (id) {
          _bookmarkHighlightTimer = setTimeout(() => {
            set({ highlightedBookmarkId: null });
            _bookmarkHighlightTimer = null;
          }, durationMs);
        }
      },

      toggleTag: (tagId) =>
        set((state) => ({
          selectedTags: state.selectedTags.includes(tagId)
            ? state.selectedTags.filter((t) => t !== tagId)
            : [...state.selectedTags, tagId],
        })),

      clearTags: () => set({ selectedTags: [] }),
      setSearchQuery: (query) => set({ searchQuery: query }),
      setViewMode: (mode) => set({ viewMode: mode }),
      setSortBy: (sort) => set({ sortBy: sort }),
      setFilterType: (filter) => set({ filterType: filter }),

      addBookmark: (input) => {
        const fallback: Bookmark = { id: "", createdAt: "", isFavorite: false, ...input };
        return guardQuota("bookmark", undefined, fallback, () => {
          const bookmark: Bookmark = {
            id: generateId(),
            createdAt: new Date().toISOString(),
            isFavorite: false,
            ...input,
            favicon: normalizeFavicon(input.favicon),
          };
          set((state) => {
            const nextBookmarks = new Map(state.bookmarks);
            nextBookmarks.set(bookmark.id, bookmark);
            const nextCounts = { ...state.countsByCollection };
            incrementCollectionCount(nextCounts, bookmark.collectionId);
            return {
              bookmarks: nextBookmarks,
              countsByCollection: nextCounts,
            };
          });
          assertCountsInvariant(get());
          idbPut("bookmarks", bookmark);
          usePlanStore.getState().incrementUsage("bookmark");
          return bookmark;
        });
      },

      addBookmarks: (newBookmarks) => {
        const normalized = newBookmarks.map((b) => ({ ...b, favicon: normalizeFavicon(b.favicon) }));
        const effectiveIncoming = buildEffectiveIncomingBookmarks(normalized);
        const effectiveIncomingValues = Array.from(effectiveIncoming.values());
        const activeBookmarks = get().bookmarks;
        const effectiveGrowth = effectiveIncomingValues.reduce((count, bookmark) => {
          return activeBookmarks.has(bookmark.id) ? count : count + 1;
        }, 0);

        const planStore = usePlanStore.getState();
        const { limits, usage } = planStore;
        const maxBookmarks = limits?.max_bookmarks;
        if (
          effectiveGrowth > 0 &&
          maxBookmarks !== undefined &&
          maxBookmarks !== -1 &&
          usage !== null &&
          usage.bookmarks + effectiveGrowth > maxBookmarks
        ) {
          planStore.showQuotaAlert("bookmark");
          return;
        }

        let usageDelta = 0;
        set((state) => {
          const nextBookmarks = new Map<string, Bookmark>();
          for (const bookmark of effectiveIncomingValues) {
            nextBookmarks.set(bookmark.id, bookmark);
          }
          for (const [existingId, existingBookmark] of state.bookmarks) {
            if (!nextBookmarks.has(existingId)) {
              nextBookmarks.set(existingId, existingBookmark);
            }
          }
          const nextCounts = { ...state.countsByCollection };
          for (const bookmark of effectiveIncomingValues) {
            const bookmarkId = bookmark.id;
            const existingBookmark = state.bookmarks.get(bookmarkId);
            if (!existingBookmark) {
              incrementCollectionCount(nextCounts, bookmark.collectionId);
              usageDelta += 1;
              continue;
            }
            if (existingBookmark.collectionId !== bookmark.collectionId) {
              decrementCollectionCount(nextCounts, existingBookmark.collectionId);
              incrementCollectionCount(nextCounts, bookmark.collectionId);
            }
          }
          return {
            bookmarks: nextBookmarks,
            countsByCollection: nextCounts,
          };
        });
        assertCountsInvariant(get());
        void idbBulkWrite(
          effectiveIncomingValues.map((bookmark) => ({
            type: "put" as const,
            store: "bookmarks" as const,
            value: bookmark,
          })),
        );
        if (effectiveIncomingValues.length > 0) {
        }
        if (usageDelta > 0) {
          usePlanStore.getState().incrementUsage("bookmark", usageDelta);
        }
      },

      _bulkAddBookmarks: (newBookmarks) => {
        if (newBookmarks.length === 0) { return; }
        const normalized = newBookmarks.map((b) => ({ ...b, favicon: normalizeFavicon(b.favicon) }));
        const effectiveIncoming = buildEffectiveIncomingBookmarks(normalized);
        const effectiveIncomingValues = Array.from(effectiveIncoming.values());
        set((state) => {
          const nextBookmarks = new Map(state.bookmarks);
          const nextCounts = { ...state.countsByCollection };
          for (const bookmark of effectiveIncomingValues) {
            const existingBookmark = state.bookmarks.get(bookmark.id);
            nextBookmarks.set(bookmark.id, bookmark);
            if (!existingBookmark) {
              incrementCollectionCount(nextCounts, bookmark.collectionId);
            } else if (existingBookmark.collectionId !== bookmark.collectionId) {
              decrementCollectionCount(nextCounts, existingBookmark.collectionId);
              incrementCollectionCount(nextCounts, bookmark.collectionId);
            }
          }
          return {
            bookmarks: nextBookmarks,
            countsByCollection: nextCounts,
          };
        });
        assertCountsInvariant(get());
        void idbBulkWrite(
          effectiveIncomingValues.map((bookmark) => ({
            type: "put" as const,
            store: "bookmarks" as const,
            value: bookmark,
          })),
        );
      },

      updateBookmark: (id, patch) => {
        const state = get();
        const activeBookmark = state.bookmarks.get(id);
        if (activeBookmark) {
          const updated = { ...activeBookmark, ...patch };
          set((current) => {
            const nextCounts = { ...current.countsByCollection };
            if (patch.collectionId !== undefined && patch.collectionId !== activeBookmark.collectionId) {
              decrementCollectionCount(nextCounts, activeBookmark.collectionId);
              incrementCollectionCount(nextCounts, patch.collectionId);
            }
            return {
              bookmarks: new Map(current.bookmarks).set(id, updated),
              countsByCollection: nextCounts,
            };
          });
          assertCountsInvariant(get());
          idbPut("bookmarks", updated);
          return;
        }

        const archivedBookmark = state._archivedLoaded
          ? state.archivedBookmarks.find((bookmark) => bookmark.id === id)
          : undefined;
        if (archivedBookmark) {
          const updated = { ...archivedBookmark, ...patch };
          set((current) => ({
            archivedBookmarks: current.archivedBookmarks.map((bookmark) => (bookmark.id === id ? updated : bookmark)),
          }));
          idbPut("archived-bookmarks", updated);
          return;
        }

        const trashedBookmark = state._trashedLoaded
          ? state.trashedBookmarks.find((bookmark) => bookmark.id === id)
          : undefined;
        if (trashedBookmark) {
          const updated = { ...trashedBookmark, ...patch };
          set((current) => ({
            trashedBookmarks: current.trashedBookmarks.map((bookmark) => (bookmark.id === id ? updated : bookmark)),
          }));
          idbPut("trashed-bookmarks", updated);
          return;
        }

        void (async () => {
          const archived = state._archivedLoaded ? undefined : await readBookmarkById("archived-bookmarks", id);
          if (archived) {
            const updated = { ...archived, ...patch };
            await idbPut("archived-bookmarks", updated);
            set((current) => ({
              archivedBookmarks: current._archivedLoaded
                ? current.archivedBookmarks.map((bookmark) => (bookmark.id === id ? updated : bookmark))
                : current.archivedBookmarks,
            }));
            return;
          }

          const trashed = state._trashedLoaded ? undefined : await readBookmarkById("trashed-bookmarks", id);
          if (!trashed) {
            return;
          }
          const updated = { ...trashed, ...patch };
          await idbPut("trashed-bookmarks", updated);
          set((current) => ({
            trashedBookmarks: current._trashedLoaded
              ? current.trashedBookmarks.map((bookmark) => (bookmark.id === id ? updated : bookmark))
              : current.trashedBookmarks,
          }));
        })();
      },

      toggleFavorite: (bookmarkId) => {
        const bookmark = get().bookmarks.get(bookmarkId);
        if (!bookmark) { return; }
        const updated = { ...bookmark, isFavorite: !bookmark.isFavorite };
        set((state) => ({
          bookmarks: new Map(state.bookmarks).set(bookmarkId, updated),
        }));
        idbPut("bookmarks", updated);
      },

      archiveBookmark: (bookmarkId) => {
        const bookmark = get().bookmarks.get(bookmarkId);
        if (!bookmark) { return; }
        idbDelete("bookmarks", bookmarkId);
        idbPut("archived-bookmarks", bookmark);
        set((state) => {
          const nextBookmarks = new Map(state.bookmarks);
          nextBookmarks.delete(bookmarkId);
          const nextCounts = { ...state.countsByCollection };
          decrementCollectionCount(nextCounts, bookmark.collectionId);
          return {
            bookmarks: nextBookmarks,
            countsByCollection: nextCounts,
            archivedBookmarks: state._archivedLoaded ? [...state.archivedBookmarks, bookmark] : state.archivedBookmarks,
          };
        });
        assertCountsInvariant(get());
      },

      restoreFromArchive: (bookmarkId) => {
        const state = get();
        const bookmark = state._archivedLoaded
          ? state.archivedBookmarks.find((candidate) => candidate.id === bookmarkId)
          : undefined;
        if (bookmark) {
          idbDelete("archived-bookmarks", bookmarkId);
          idbPut("bookmarks", bookmark);
          set((current) => {
            const nextBookmarks = new Map(current.bookmarks);
            nextBookmarks.set(bookmark.id, bookmark);
            const nextCounts = { ...current.countsByCollection };
            incrementCollectionCount(nextCounts, bookmark.collectionId);
            return {
              archivedBookmarks: current.archivedBookmarks.filter((candidate) => candidate.id !== bookmarkId),
              bookmarks: nextBookmarks,
              countsByCollection: nextCounts,
            };
          });
          assertCountsInvariant(get());
          return;
        }

        void (async () => {
          const archived = state._archivedLoaded ? undefined : await readBookmarkById("archived-bookmarks", bookmarkId);
          if (!archived) {
            return;
          }
          await idbDelete("archived-bookmarks", bookmarkId);
          await idbPut("bookmarks", archived);
          set((current) => {
            const nextBookmarks = new Map(current.bookmarks);
            nextBookmarks.set(archived.id, archived);
            const nextCounts = { ...current.countsByCollection };
            incrementCollectionCount(nextCounts, archived.collectionId);
            return {
              archivedBookmarks: current._archivedLoaded
                ? current.archivedBookmarks.filter((candidate) => candidate.id !== bookmarkId)
                : current.archivedBookmarks,
              bookmarks: nextBookmarks,
              countsByCollection: nextCounts,
            };
          });
          assertCountsInvariant(get());
        })();
      },

      trashBookmark: (bookmarkId) => {
        const bookmark = get().bookmarks.get(bookmarkId);
        if (!bookmark) { return; }
        const trashed = { ...bookmark, deletedAt: Date.now() };
        idbDelete("bookmarks", bookmarkId);
        idbPut("trashed-bookmarks", trashed);
        set((state) => {
          const nextBookmarks = new Map(state.bookmarks);
          nextBookmarks.delete(bookmarkId);
          const nextCounts = { ...state.countsByCollection };
          decrementCollectionCount(nextCounts, bookmark.collectionId);
          return {
            bookmarks: nextBookmarks,
            countsByCollection: nextCounts,
            trashedBookmarks: state._trashedLoaded ? [...state.trashedBookmarks, trashed] : state.trashedBookmarks,
          };
        });
        usePlanStore.getState().moveUsageToTrash("bookmark");
        assertCountsInvariant(get());
      },

      restoreFromTrash: (bookmarkId, collectionIdOverride) => {
        const state = get();
        const bookmark = state._trashedLoaded
          ? state.trashedBookmarks.find((candidate) => candidate.id === bookmarkId)
          : undefined;
        if (bookmark) {
          const restored = collectionIdOverride !== undefined
            ? { ...bookmark, collectionId: collectionIdOverride, deletedAt: undefined }
            : { ...bookmark, deletedAt: undefined };
          idbDelete("trashed-bookmarks", bookmarkId);
          idbPut("bookmarks", restored);
          set((current) => {
            const nextBookmarks = new Map(current.bookmarks);
            nextBookmarks.set(restored.id, restored);
            const nextCounts = { ...current.countsByCollection };
            incrementCollectionCount(nextCounts, restored.collectionId);
            return {
              trashedBookmarks: current.trashedBookmarks.filter((candidate) => candidate.id !== bookmarkId),
              bookmarks: nextBookmarks,
              countsByCollection: nextCounts,
            };
          });
          usePlanStore.getState().restoreUsageFromTrash("bookmark");
          assertCountsInvariant(get());
          return;
        }

        void (async () => {
          const trashed = state._trashedLoaded ? undefined : await readBookmarkById("trashed-bookmarks", bookmarkId);
          if (!trashed) {
            return;
          }
          const restored = collectionIdOverride !== undefined
            ? { ...trashed, collectionId: collectionIdOverride, deletedAt: undefined }
            : { ...trashed, deletedAt: undefined };
          await idbDelete("trashed-bookmarks", bookmarkId);
          await idbPut("bookmarks", restored);
          set((current) => {
            const nextBookmarks = new Map(current.bookmarks);
            nextBookmarks.set(restored.id, restored);
            const nextCounts = { ...current.countsByCollection };
            incrementCollectionCount(nextCounts, restored.collectionId);
            return {
              trashedBookmarks: current._trashedLoaded
                ? current.trashedBookmarks.filter((candidate) => candidate.id !== bookmarkId)
                : current.trashedBookmarks,
              bookmarks: nextBookmarks,
              countsByCollection: nextCounts,
            };
          });
          usePlanStore.getState().restoreUsageFromTrash("bookmark");
          assertCountsInvariant(get());
        })();
      },

      permanentlyDelete: (bookmarkId) => {
        get().permanentlyDeleteBatch([bookmarkId]);
      },

      permanentlyDeleteBatch: (bookmarkIds) => {
        if (bookmarkIds.length === 0) { return; }
        void (async () => {
          const ids = new Set(bookmarkIds);
          const records = await idbGetMany<TrashedBookmarkRecord>("trashed-bookmarks", [...ids]);
          const bookmarks = records.filter((bookmark): bookmark is TrashedBookmarkRecord =>
            bookmark !== undefined && bookmark.isTrashed !== 2,
          );
          await idbBulkWrite(bookmarks.map((bookmark): BulkWriteOp => ({
            type: "delete", store: "trashed-bookmarks", key: bookmark.id,
          })));
          set((state) => ({
            trashedBookmarks: state.trashedBookmarks.filter((bookmark) => !ids.has(bookmark.id)),
          }));
          usePlanStore.getState().decrementUsage("bookmark", bookmarks.length);
        })();
      },

      removeWorkspaceAggregateFromState: (ids) => {
        const bookmarkIds = new Set(ids.bookmarkIds);
        set((state) => {
          const bookmarks = new Map(state.bookmarks);
          for (const id of bookmarkIds) {
            bookmarks.delete(id);
          }
          return {
            bookmarks,
            countsByCollection: recomputeCounts(bookmarks),
            archivedBookmarks: state._archivedLoaded
              ? state.archivedBookmarks.filter((bookmark) => !bookmarkIds.has(bookmark.id))
              : state.archivedBookmarks,
            trashedBookmarks: state._trashedLoaded
              ? state.trashedBookmarks.filter((bookmark) => !bookmarkIds.has(bookmark.id))
              : state.trashedBookmarks,
          };
        });
        assertCountsInvariant(get());
      },

      archiveCollectionBookmarks: (collectionId) => {
        const affected = Array.from(get().bookmarks.values()).filter((b) => b.collectionId === collectionId);
        if (affected.length === 0) { return; }
        const ops: BulkWriteOp[] = [
          ...affected.map((b) => ({ type: "delete" as const, store: "bookmarks" as const, key: b.id })),
          ...affected.map((b) => ({ type: "put" as const, store: "archived-bookmarks" as const, value: b })),
        ];
        void idbBulkWrite(ops);
        set((state) => {
          const nextBookmarks = new Map(state.bookmarks);
          for (const bookmark of affected) {
            nextBookmarks.delete(bookmark.id);
          }
          const nextCounts = { ...state.countsByCollection };
          setCollectionCount(nextCounts, collectionId, 0);
          return {
            bookmarks: nextBookmarks,
            countsByCollection: nextCounts,
            archivedBookmarks: state._archivedLoaded ? [...state.archivedBookmarks, ...affected] : state.archivedBookmarks,
          };
        });
        assertCountsInvariant(get());
      },

      trashCollectionBookmarks: (collectionId) => {
        return (async () => {
          const state = get();
          const active = Array.from(state.bookmarks.values()).filter((bookmark) => bookmark.collectionId === collectionId);
          const archived = state._archivedLoaded
            ? state.archivedBookmarks.filter((bookmark) => bookmark.collectionId === collectionId)
            : await readArchivedBookmarksForCollection(collectionId);
          const all = [...active, ...archived];
          if (all.length === 0) { return; }
          const now = Date.now();
          const trashed = all.map((bookmark) => ({ ...bookmark, deletedAt: now }));
          const ops: BulkWriteOp[] = [
            ...active.map((bookmark) => ({ type: "delete" as const, store: "bookmarks" as const, key: bookmark.id })),
            ...archived.map((bookmark) => ({ type: "delete" as const, store: "archived-bookmarks" as const, key: bookmark.id })),
            ...trashed.map((bookmark) => ({ type: "put" as const, store: "trashed-bookmarks" as const, value: bookmark })),
          ];
          await idbBulkWrite(ops);
          set((current) => {
            const nextBookmarks = new Map(current.bookmarks);
            for (const bookmark of active) {
              nextBookmarks.delete(bookmark.id);
            }
            const nextCounts = { ...current.countsByCollection };
            setCollectionCount(nextCounts, collectionId, 0);
            return {
              bookmarks: nextBookmarks,
              countsByCollection: nextCounts,
              archivedBookmarks: current._archivedLoaded
                ? current.archivedBookmarks.filter((bookmark) => bookmark.collectionId !== collectionId)
                : current.archivedBookmarks,
              trashedBookmarks: current._trashedLoaded
                ? [...current.trashedBookmarks.filter((bookmark) => bookmark.collectionId !== collectionId), ...trashed]
                : current.trashedBookmarks,
            };
          });
          // Both active and archived bookmarks move to trash here (archived
          // already counted as in-use, so it moves too).
          usePlanStore.getState().moveUsageToTrash("bookmark", all.length);
          assertCountsInvariant(get());
        })();
      },

      restoreCollectionBookmarks: (collectionId) => {
        void (async () => {
          const state = get();
          const fromArchive = state._archivedLoaded
            ? state.archivedBookmarks.filter((b) => b.collectionId === collectionId)
            : await readArchivedBookmarksForCollection(collectionId);
          const fromTrash = state._trashedLoaded
            ? state.trashedBookmarks.filter((b) => b.collectionId === collectionId)
            : await readTrashedBookmarksForCollection(collectionId);
          const restoredFromTrash = fromTrash.map((b) => ({ ...b, deletedAt: undefined }));
          const all = [...fromArchive, ...restoredFromTrash];
          if (all.length === 0) { return; }
          const ops: BulkWriteOp[] = [
            ...fromArchive.map((b) => ({ type: "delete" as const, store: "archived-bookmarks" as const, key: b.id })),
            ...fromTrash.map((b) => ({ type: "delete" as const, store: "trashed-bookmarks" as const, key: b.id })),
            ...all.map((b) => ({ type: "put" as const, store: "bookmarks" as const, value: b })),
          ];
          await idbBulkWrite(ops);
          set((current) => {
            const nextBookmarks = new Map(current.bookmarks);
            for (const bookmark of all) {
              nextBookmarks.set(bookmark.id, bookmark);
            }
            const nextCounts = { ...current.countsByCollection };
            incrementCollectionCount(nextCounts, collectionId, all.length);
            return {
              archivedBookmarks: current._archivedLoaded
                ? current.archivedBookmarks.filter((b) => b.collectionId !== collectionId)
                : current.archivedBookmarks,
              trashedBookmarks: current._trashedLoaded
                ? current.trashedBookmarks.filter((b) => b.collectionId !== collectionId)
                : current.trashedBookmarks,
              bookmarks: nextBookmarks,
              countsByCollection: nextCounts,
            };
          });
          // Only the trashed subset was ever moved into the trash bucket;
          // archived bookmarks stayed in-use.
          if (fromTrash.length > 0) {
            usePlanStore.getState().restoreUsageFromTrash("bookmark", fromTrash.length);
          }
          assertCountsInvariant(get());
        })();
      },

      permanentlyDeleteCollectionBookmarks: (collectionId) => {
        void (async () => {
          const state = get();
          const trashed = state._trashedLoaded
            ? state.trashedBookmarks.filter((bookmark) => bookmark.collectionId === collectionId)
            : await readTrashedBookmarksForCollection(collectionId);
          const archived = state._archivedLoaded
            ? state.archivedBookmarks.filter((bookmark) => bookmark.collectionId === collectionId)
            : await readArchivedBookmarksForCollection(collectionId);
          const all = [...trashed, ...archived];
          if (all.length === 0) { return; }
          // No forcePush here — the server already cascades is_trashed=2 to all
          // bookmarks in the collection when it processes is_deleted=2 on the
          // parent collection (see server sync.go cascade logic). We only need
          // to clean up the local IDB.
          const ops: BulkWriteOp[] = [
            ...trashed.map((bookmark) => ({ type: "delete" as const, store: "trashed-bookmarks" as const, key: bookmark.id })),
            ...archived.map((bookmark) => ({ type: "delete" as const, store: "archived-bookmarks" as const, key: bookmark.id })),
          ];
          await idbBulkWrite(ops);
          set((current) => ({
            trashedBookmarks: current._trashedLoaded
              ? current.trashedBookmarks.filter((bookmark) => bookmark.collectionId !== collectionId)
              : current.trashedBookmarks,
            archivedBookmarks: current._archivedLoaded
              ? current.archivedBookmarks.filter((bookmark) => bookmark.collectionId !== collectionId)
              : current.archivedBookmarks,
          }));
          usePlanStore.getState().decrementUsage("bookmark", all.length);
        })();
      },

      reassignCollection: (fromId, toId) => {
        const affected = Array.from(get().bookmarks.values()).filter(b => b.collectionId === fromId);
        if (affected.length === 0) { return; }
        const updated = affected.map(b => ({ ...b, collectionId: toId }));
        void idbBulkWrite(updated.map(b => ({ type: "put" as const, store: "bookmarks" as const, value: b })));
        set((state) => {
          const nextBookmarks = new Map(state.bookmarks);
          for (const bookmark of updated) {
            nextBookmarks.set(bookmark.id, bookmark);
          }
          const nextCounts = { ...state.countsByCollection };
          decrementCollectionCount(nextCounts, fromId, updated.length);
          incrementCollectionCount(nextCounts, toId, updated.length);
          return {
            bookmarks: nextBookmarks,
            countsByCollection: nextCounts,
          };
        });
        assertCountsInvariant(get());
      },

      // workspaceCollectionIds: Set of collection IDs in the active workspace
      // (pass from caller to avoid circular import with workspace-store)
      getFilteredBookmarks: (workspaceCollectionIds) => {
        const state = get();
        let filtered = Array.from(state.bookmarks.values()).filter(
          (b) =>
            b.collectionId === "" ||
            workspaceCollectionIds.has(b.collectionId)
        );

        if (state.selectedCollection !== "all") {
          filtered = filtered.filter(
            (b) => b.collectionId === state.selectedCollection
          );
        }

        if (state.selectedTags.length > 0) {
          filtered = filtered.filter((b) =>
            state.selectedTags.some((tag) => b.tags.includes(tag))
          );
        }

        switch (state.filterType) {
          case "favorites":
            filtered = filtered.filter((b) => b.isFavorite);
            break;
          case "with-tags":
            filtered = filtered.filter((b) => b.tags.length > 0);
            break;
          case "without-tags":
            filtered = filtered.filter((b) => b.tags.length === 0);
            break;
        }

        return applySort(applySearch(filtered, state.searchQuery), state.sortBy);
      },

      getFavoriteBookmarks: () => {
        const state = get();
        const filtered = Array.from(state.bookmarks.values()).filter((b) => b.isFavorite);
        return applySort(applySearch(filtered, state.searchQuery), state.sortBy);
      },

      getArchivedBookmarks: () => {
        const state = get();
        return applySearch([...state.archivedBookmarks], state.searchQuery)
          .sort(compareBookmarksNewestFirst);
      },

      getTrashedBookmarks: () => {
        const state = get();
        return applySearch([...state.trashedBookmarks], state.searchQuery)
          .sort(compareBookmarksTrashedFirst);
      },
    })
);
