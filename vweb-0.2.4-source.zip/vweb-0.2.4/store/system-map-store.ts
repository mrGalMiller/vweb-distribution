import { create } from "zustand";
import { DASHBOARD_PAGES, type DashboardPageId, type ToolbarActionId } from "@/lib/system-map";

const STORAGE_PREFIX = "vweb-system-map:";
const navigationKey = (page: DashboardPageId) => `${STORAGE_PREFIX}nav:${page}`;
const toolbarKey = (page: DashboardPageId, action: ToolbarActionId) => `${STORAGE_PREFIX}toolbar:${page}:${action}`;
const visibilityKeys = DASHBOARD_PAGES.flatMap((page) => [
  navigationKey(page.id),
  ...page.toolbar.map((action) => toolbarKey(page.id, action)),
]);

interface VisibilityState {
  hidden: ReadonlySet<string>;
  setNavigationVisible: (page: DashboardPageId, visible: boolean) => void;
  setToolbarVisible: (page: DashboardPageId, action: ToolbarActionId, visible: boolean) => void;
  resetVisibility: () => void;
}

function readVisibility(): ReadonlySet<string> {
  if (typeof localStorage === "undefined") {
    return new Set();
  }
  return new Set(visibilityKeys.filter((key) => localStorage.getItem(key) === "hidden"));
}

function saveVisibility(key: string, visible: boolean) {
  if (visible) {
    localStorage.removeItem(key);
  } else {
    localStorage.setItem(key, "hidden");
  }
  useSystemMapStore.setState({ hidden: readVisibility() });
}

export const useSystemMapStore = create<VisibilityState>(() => ({
  hidden: readVisibility(),
  setNavigationVisible: (page, visible) => saveVisibility(navigationKey(page), visible),
  setToolbarVisible: (page, action, visible) => saveVisibility(toolbarKey(page, action), visible),
  resetVisibility: () => {
    visibilityKeys.forEach((key) => localStorage.removeItem(key));
    useSystemMapStore.setState({ hidden: readVisibility() });
  },
}));

export function subscribeToSystemMapStorage() {
  const handleStorage = (event: StorageEvent) => {
    if (event.storageArea === localStorage && (event.key === null || event.key.startsWith(STORAGE_PREFIX))) {
      useSystemMapStore.setState({ hidden: readVisibility() });
    }
  };
  window.addEventListener("storage", handleStorage);
  return () => window.removeEventListener("storage", handleStorage);
}

export function isNavigationVisible(hidden: ReadonlySet<string>, page: DashboardPageId) {
  return !hidden.has(navigationKey(page));
}

export function isToolbarActionVisible(hidden: ReadonlySet<string>, page: DashboardPageId, action: ToolbarActionId) {
  return !hidden.has(toolbarKey(page, action));
}
