import { create } from "zustand";
import type { Workspace, Collection, Tag } from "@/lib/types";
import type { ImportPlan } from "@/lib/import-types";
import { generateId } from "@/lib/id";
import { idbGetAll, idbGet, idbPut, idbDelete, idbBulkWrite, type BulkWriteOp } from "@/lib/idb";
import * as idb from "@/lib/idb";
import { compareActiveCollections } from "@/lib/collection-utils";
import { useBookmarksStore } from "@/store/bookmarks-store";
import { useGroupsStore } from "@/store/groups-store";
import { usePlanStore, guardQuota } from "@/store/plan-store";
import { createGuestWorkspaceSeed } from "@/lib/guest-workspace";
import { withWorkspaceLifecycleLock } from "@/lib/workspace-lifecycle-state";
import {
  clearWorkspaceAggregate,
  type WorkspaceAggregateIds,
} from "@/lib/workspace-aggregate";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

export const WORKSPACE_COLORS = [
  "blue",
  "emerald",
  "orange",
  "violet",
  "rose",
  "amber",
] as const;
export type WorkspaceColor = (typeof WORKSPACE_COLORS)[number];

export const WORKSPACE_GRADIENTS: Record<WorkspaceColor, string> = {
  blue: "from-blue-400 to-indigo-500",
  emerald: "from-emerald-400 to-cyan-500",
  orange: "from-orange-400 to-rose-500",
  violet: "from-violet-400 to-purple-500",
  rose: "from-rose-400 to-pink-500",
  amber: "from-amber-400 to-orange-500",
};

export const COLLECTION_ICONS = [
  "folder",
  "bookmark",
  "code",
  "palette",
  "wrench",
  "book-open",
  "sparkles",
  "star",
  "heart",
  "globe",
] as const;
export type CollectionIcon = (typeof COLLECTION_ICONS)[number];

export const TAG_COLORS = [
  "bg-blue-500/10 text-blue-500",
  "bg-emerald-500/10 text-emerald-500",
  "bg-violet-500/10 text-violet-500",
  "bg-amber-500/10 text-amber-500",
  "bg-rose-500/10 text-rose-500",
  "bg-cyan-500/10 text-cyan-500",
  "bg-orange-500/10 text-orange-500",
  "bg-pink-500/10 text-pink-500",
] as const;

// Exported just to guarantee Tailwind v4 scanner picks up these solid colors
export const SOLID_TAG_COLORS = [
  "bg-blue-500", "bg-emerald-500", "bg-violet-500", "bg-amber-500",
  "bg-rose-500", "bg-cyan-500", "bg-orange-500", "bg-pink-500"
];



// ---------------------------------------------------------------------------
// Sync helpers
// ---------------------------------------------------------------------------
function isActiveWorkspace(workspace: Workspace): boolean {
  return workspace.deletedAt === undefined;
}

function compareWorkspacePosition(a: Workspace, b: Workspace): number {
  return a.position - b.position || a.id.localeCompare(b.id);
}

function chooseActiveWorkspace(workspaces: readonly Workspace[]): Workspace | undefined {
  return workspaces.filter(isActiveWorkspace).sort(compareWorkspacePosition)[0];
}

export interface WorkspaceActionResult {
  status: "queued" | "completed" | "blocked" | "unsupported";
  reason?: "last_active_workspace" | "server_capability" | "offline";
}

interface WorkspaceState {
  workspaces: Workspace[];
  collections: Collection[];
  tags: Tag[];
  activeWorkspaceId: string;
  compactGroupTitles: boolean;

  _hydrated: boolean;
  hydrate: () => Promise<void>;
  reset: () => void;
  initializeGuestWorkspace: (options?: { isSessionCurrent?: () => boolean }) => Promise<void>;

  highlightedCollectionIds: string[];
  setHighlightedCollectionIds: (ids: string[], durationMs?: number) => void;

  setActiveWorkspaceId: (id: string) => void;
  setCompactGroupTitles: (val: boolean) => void;

  // Sync actions
  removeWorkspaceAggregateFromState: (ids: WorkspaceAggregateIds) => void;

  // Workspace CRUD
  createWorkspace: (name: string, color: string) => Workspace;
  updateWorkspace: (id: string, patch: Partial<Pick<Workspace, "name" | "color">>) => void;
  deleteWorkspace: (id: string) => Promise<WorkspaceActionResult>;
  restoreWorkspace: (id: string) => Promise<WorkspaceActionResult>;
  permanentlyDeleteWorkspace: (id: string) => Promise<WorkspaceActionResult>;

  // Collection CRUD
  createCollection: (workspaceId: string, name: string, icon: string) => Collection;
  updateCollection: (id: string, patch: Partial<Pick<Collection, "name" | "icon">>) => void;
  deleteCollection: (id: string) => void;
  archiveCollection: (id: string) => void;
  restoreCollection: (id: string) => void;
  permanentlyDeleteCollection: (id: string) => void;

  // Tag CRUD
  createTag: (name: string, color: string) => Tag;
  updateTag: (id: string, patch: Partial<Pick<Tag, "name" | "color">>) => void;
  deleteTag: (id: string) => void;
  importFromPlan: (plan: ImportPlan) => boolean;

  // Computed
  getActiveWorkspaces: () => Workspace[];
  getDeletedWorkspaces: () => Workspace[];
  getWorkspaceCollections: (workspaceId?: string) => Collection[];
  getArchivedCollections: () => Collection[];
  getTrashedCollections: () => Collection[];
}

// Module-level timer to avoid referential equality issues with array comparison
let _collectionHighlightTimer: ReturnType<typeof setTimeout> | null = null;
let _guestWorkspaceInitialization: Promise<void> | null = null;

// ---------------------------------------------------------------------------
// Store
// ---------------------------------------------------------------------------
export const useWorkspaceStore = create<WorkspaceState>()((set, get) => ({
  workspaces: [],
  collections: [],
  tags: [],
  activeWorkspaceId: "",
  compactGroupTitles: true,

  _hydrated: false,
  hydrate: async () => {
    const [workspaces, collections, tags] = await Promise.all([
      idbGetAll<Workspace>("workspaces"),
      idbGetAll<Collection>("collections"),
      idbGetAll<Tag>("tags"),
    ]);
    const [activeWsKv, compactKv] = await Promise.all([
      idbGet<{ key: string; value: string }>("kv", "activeWorkspaceId"),
      idbGet<{ key: string; value: boolean }>("kv", "compactGroupTitles"),
    ]);

    // Fall back to the first active collection for older local data.
    for (const ws of workspaces.filter(isActiveWorkspace)) {
      const wsCols = collections.filter(
        c => c.workspaceId === ws.id && !c.deletedAt && !c.archivedAt,
      );
      if (!wsCols.some(c => c.isDefault) && wsCols.length > 0) {
        const first = [...wsCols].sort((a, b) => a.position - b.position)[0];
        const idx = collections.findIndex(c => c.id === first.id);
        if (idx !== -1) { collections[idx] = { ...collections[idx], isDefault: true }; }
      }
    }

    const persistedActiveId = activeWsKv?.value ?? "";
    const persistedActive = workspaces.find(
      (workspace) => workspace.id === persistedActiveId && isActiveWorkspace(workspace),
    );
    const activeWorkspaceId = persistedActive?.id ?? chooseActiveWorkspace(workspaces)?.id ?? "";
    if (activeWorkspaceId !== persistedActiveId) {
      await idbPut("kv", { key: "activeWorkspaceId", value: activeWorkspaceId });
    }

    set({
      workspaces,
      collections,
      tags,
      activeWorkspaceId,
      compactGroupTitles: compactKv?.value ?? true,
      _hydrated: true,
    });
  },

  reset: () => {
    set({
      workspaces: [],
      collections: [],
      tags: [],
      activeWorkspaceId: "",
      compactGroupTitles: true,
      _hydrated: true,
    });
  },

  initializeGuestWorkspace: (options = {}) => {
    if (_guestWorkspaceInitialization) {
      return _guestWorkspaceInitialization;
    }

    let initialization: Promise<void>;
    initialization = Promise.resolve().then(async () => {
      try {
        if (options.isSessionCurrent && !options.isSessionCurrent()) {
          return;
        }
        const state = get();
        if (state.workspaces.length > 0) {
          return;
        }

        const seed = createGuestWorkspaceSeed(
          generateId(),
          generateId(),
          state.workspaces.length,
        );
        const created = await idb.idbCreateGuestWorkspaceIfEmpty(
          seed.workspace,
          seed.collection,
          { key: "activeWorkspaceId", value: seed.workspace.id },
          seed.provenance,
        );
        if (options.isSessionCurrent && !options.isSessionCurrent()) {
          if (created) {
            await idb.idbRollbackGuestWorkspaceIfUnchanged(
              seed.workspace,
              seed.collection,
              seed.provenance,
            );
          }
          return;
        }
        const current = get();
        if (current.workspaces.length > 0) {
          return;
        }
        if (!created) {
          const [workspaces, collections, activeWorkspace] = await Promise.all([
            idbGetAll<Workspace>("workspaces"),
            idbGetAll<Collection>("collections"),
            idbGet<{ key: string; value: string }>("kv", "activeWorkspaceId"),
          ]);
          if (options.isSessionCurrent && !options.isSessionCurrent()) {
            return;
          }
          if (get().workspaces.length === 0 && workspaces.length > 0) {
            const persistedActive = workspaces.find(
              (workspace) => workspace.id === activeWorkspace?.value && isActiveWorkspace(workspace),
            );
            set({
              workspaces,
              collections,
              activeWorkspaceId: persistedActive?.id ?? chooseActiveWorkspace(workspaces)?.id ?? "",
            });
          }
          return;
        }
        set({
          workspaces: [seed.workspace],
          collections: [seed.collection],
          activeWorkspaceId: seed.workspace.id,
        });
        if (options.isSessionCurrent && !options.isSessionCurrent()) {
          return;
        }
      } finally {
        if (_guestWorkspaceInitialization === initialization) {
          _guestWorkspaceInitialization = null;
        }
      }
    });
    _guestWorkspaceInitialization = initialization;
    return initialization;
  },

  highlightedCollectionIds: [],
  setHighlightedCollectionIds: (ids, durationMs = 3000) => {
    if (_collectionHighlightTimer) { clearTimeout(_collectionHighlightTimer); }
    set({ highlightedCollectionIds: ids });
    if (ids.length > 0) {
      _collectionHighlightTimer = setTimeout(() => {
        set({ highlightedCollectionIds: [] });
        _collectionHighlightTimer = null;
      }, durationMs);
    }
  },

  setActiveWorkspaceId: (id) => {
    if (!get().workspaces.some((workspace) => workspace.id === id && isActiveWorkspace(workspace))) {
      return;
    }
    set({ activeWorkspaceId: id });
    idbPut("kv", { key: "activeWorkspaceId", value: id });
  },
  setCompactGroupTitles: (val) => {
    set({ compactGroupTitles: val });
    idbPut("kv", { key: "compactGroupTitles", value: val });
  },

  // ── Sync ──────────────────────────────────────────────────────────────
  createWorkspace: (name, color) =>
    // Quota-blocked creation returns an empty-id sentinel rather than using
    // an unsafe assertion. Current callers ignore the return value.
    guardQuota("workspace", get().workspaces.length, { id: "", name, color, position: get().workspaces.length, seq: 0 }, () => {
      const state = get();
      const nextPosition = state.workspaces.reduce(
        (maximum, workspace) => Math.max(maximum, workspace.position),
        -1,
      ) + 1;
      const ws: Workspace = {
        id: generateId(),
        name,
        color,
        position: nextPosition,
        seq: 0,
      };
      const defaultCol: Collection = {
        id: generateId(),
        workspaceId: ws.id,
        name: "Default",
        icon: "inbox",
        position: 0,
        isDefault: true,
        seq: 0,
      };
      const hasActiveWorkspace = state.workspaces.some(isActiveWorkspace);
      const nextActiveId = hasActiveWorkspace ? state.activeWorkspaceId : ws.id;
      set({
        workspaces: [...state.workspaces, ws],
        collections: [...state.collections, defaultCol],
        activeWorkspaceId: nextActiveId,
      });
      idbPut("workspaces", ws);
      idbPut("collections", defaultCol);
      if (!hasActiveWorkspace) {
        idbPut("kv", { key: "activeWorkspaceId", value: ws.id });
      }
      usePlanStore.getState().incrementUsage("workspace");
      usePlanStore.getState().incrementUsage("collection");
      return ws;
    }),

  updateWorkspace: (id, patch) => {
    set((s) => ({
      workspaces: s.workspaces.map((w) =>
        w.id === id ? { ...w, ...patch } : w
      ),
    }));
    const updated = get().workspaces.find(w => w.id === id);
    if (updated) {
      idbPut("workspaces", updated);
    }
  },

  deleteWorkspace: async (id) => withWorkspaceLifecycleLock(async () => {
    const committed = await idb.idbCommitWorkspaceDeleteLifecycleIntent({
      workspaceId: id,
      createdAt: Date.now(),
      recordIntent: false,
    });
    if (committed.status === "committed" || committed.status === "last_active_workspace") {
      const durableWorkspaces = new Map(committed.workspaces.map((workspace) => [workspace.id, workspace]));
      set((state) => ({
        workspaces: state.workspaces.map((workspace) => durableWorkspaces.get(workspace.id) ?? workspace),
        activeWorkspaceId: committed.activeWorkspaceId,
      }));
    }
    if (committed.status === "last_active_workspace") {
      return { status: "blocked", reason: "last_active_workspace" };
    }
    if (committed.status === "committed") {
      await usePlanStore.getState().refreshUsage();
    }
    return { status: "completed" };
  }),

  restoreWorkspace: async (id) => withWorkspaceLifecycleLock(async () => {
    const workspace = await idbGet<Workspace>("workspaces", id);
    if (!workspace || isActiveWorkspace(workspace)) {
      return { status: "completed" };
    }
    const restored: Workspace = { ...workspace, deletedAt: undefined, seq: 0 };
    await idbPut("workspaces", restored);
    set((state) => ({
      workspaces: state.workspaces.map((candidate) => candidate.id === id ? restored : candidate),
    }));
    await usePlanStore.getState().refreshUsage();
    return { status: "completed" };
  }),

  permanentlyDeleteWorkspace: async (id) => withWorkspaceLifecycleLock(async () => {
    const workspace = await idbGet<Workspace>("workspaces", id);
    if (!workspace) { return { status: "completed" }; }
    if (isActiveWorkspace(workspace)) { return { status: "blocked" }; }
    const committedIds = await clearWorkspaceAggregate(id, (ids) => {
      get().removeWorkspaceAggregateFromState(ids);
      useBookmarksStore.getState().removeWorkspaceAggregateFromState(ids);
      useGroupsStore.getState().removeWorkspaceAggregateFromState(ids);
    });
    if (!committedIds) { return { status: "blocked" }; }
    await usePlanStore.getState().refreshUsage();
    return { status: "completed" };
  }),

  // ── Collections ───────────────────────────────────────────────────────
  createCollection: (workspaceId, name, icon) =>
    guardQuota(
      "collection",
      // Backend counts all collections where is_deleted < 2, so active, archived,
      // and trashed entries all count toward quota. Permanently deleted entries
      // are removed from the local array entirely, so collections.length always
      // matches the backend's count.
      get().collections.length,
      { id: "", workspaceId, name: name ?? "", icon: icon ?? "", position: 0, seq: 0 } as Collection,
      () => {
        const existingInWs = get().collections.filter((c) => c.workspaceId === workspaceId);
        const col: Collection = {
          id: generateId(),
          workspaceId,
          name,
          icon,
          position: existingInWs.length,
          seq: 0,
        };
        set((s) => ({ collections: [...s.collections, col] }));
        idbPut("collections", col);
        usePlanStore.getState().incrementUsage("collection");
        return col;
      },
    ),

  updateCollection: (id, patch) => {
    set((s) => ({
      collections: s.collections.map((c) =>
        c.id === id ? { ...c, ...patch } : c
      ),
    }));
    const updated = get().collections.find(c => c.id === id);
    if (updated) {
      idbPut("collections", updated);
    }
  },

  deleteCollection: (id) => {
    const col = get().collections.find(c => c.id === id && !c.isDefault);
    if (!col) { return; }
    const trashed = { ...col, deletedAt: Date.now() };
    idbPut("collections", trashed);
    set((s) => ({ collections: s.collections.map(c => c.id === id ? trashed : c) }));
    useBookmarksStore.getState().trashCollectionBookmarks(id);
    usePlanStore.getState().moveUsageToTrash("collection");
  },

  archiveCollection: (id) => {
    const col = get().collections.find(c => c.id === id && !c.isDefault);
    if (!col) { return; }
    const archived = { ...col, archivedAt: Date.now() };
    idbPut("collections", archived);
    set((s) => ({ collections: s.collections.map(c => c.id === id ? archived : c) }));
    useBookmarksStore.getState().archiveCollectionBookmarks(id);
  },

  restoreCollection: (id) => {
    const col = get().collections.find(c => c.id === id);
    if (!col) { return; }
    const { workspaces, activeWorkspaceId } = get();
    const workspaceExists = workspaces.some(
      (workspace) => workspace.id === col.workspaceId && isActiveWorkspace(workspace),
    );
    const restoredWorkspaceId = workspaceExists
      ? col.workspaceId
      : (activeWorkspaceId || chooseActiveWorkspace(workspaces)?.id || col.workspaceId);
    const restored = {
      ...col,
      workspaceId: restoredWorkspaceId,
      deletedAt: undefined,
      archivedAt: undefined,
    };
    idbPut("collections", restored);
    set((s) => ({ collections: s.collections.map(c => c.id === id ? restored : c) }));
    // Archived collections were never moved to trash (archived counts as
    // in-use), so only a trashed -> restored transition adjusts the split.
    if (col.deletedAt) {
      usePlanStore.getState().restoreUsageFromTrash("collection");
    }
  },

  permanentlyDeleteCollection: (id) => {
    void (async () => {
      const col = get().collections.find(c => c.id === id && !!c.deletedAt);
      if (!col) { return; }
      await idbDelete("collections", id);
      set((state) => ({ collections: state.collections.filter((item) => item.id !== id) }));
      usePlanStore.getState().decrementUsage("collection");
      useBookmarksStore.getState().permanentlyDeleteCollectionBookmarks(id);
    })();
  },

  // ── Tags ──────────────────────────────────────────────────────────────
  createTag: (name, color) =>
    guardQuota("tag", get().tags.length, { id: "", name, color, seq: 0 } as Tag, () => {
      const tag: Tag = { id: generateId(), name, color, seq: 0 };
      set((s) => ({ tags: [...s.tags, tag] }));
      idbPut("tags", tag);
      usePlanStore.getState().incrementUsage("tag");
      return tag;
    }),

  updateTag: (id, patch) => {
    set((s) => ({
      tags: s.tags.map((t) => (t.id === id ? { ...t, ...patch } : t)),
    }));
    const updated = get().tags.find(t => t.id === id);
    if (updated) {
      idbPut("tags", updated);
    }
  },

  deleteTag: (id) => {
    idbDelete("tags", id);
    set((s) => ({ tags: s.tags.filter((t) => t.id !== id) }));
    usePlanStore.getState().decrementUsage("tag");
  },

  importFromPlan: (plan) => {
    const planStore = usePlanStore.getState();

    const bookmarkCount = useBookmarksStore.getState().bookmarks.size;
    // Backend counts collections where is_deleted < 2, so active, archived,
    // and trashed entries all count. Only permanentlyDeleteCollection sends
    // is_deleted:2 and removes the entry from the local array, so
    // Include retained collections in the quota count.
    const activeCollectionCount = get().collections.length;

    if (
      plan.bookmarks.length > 0 &&
      !planStore.checkQuota("bookmark", bookmarkCount + plan.bookmarks.length - 1)
    ) {
      planStore.showQuotaAlert("bookmark");
      return false;
    }

    if (
      plan.collections.length > 0 &&
      !planStore.checkQuota("collection", activeCollectionCount + plan.collections.length - 1)
    ) {
      planStore.showQuotaAlert("collection");
      return false;
    }

    const newTags: Tag[] = plan.tags.map((t) => ({ ...t, seq: 0 as const }));
    if (newTags.length > 0) {
      set((s) => ({ tags: [...s.tags, ...newTags] }));
      for (const tag of newTags) { idbPut("tags", tag); }
      planStore.incrementUsage("tag", newTags.length);
    }

    const newCollections: Collection[] = plan.collections.map((c) => ({ ...c, seq: 0 as const }));
    if (newCollections.length > 0) {
      set((s) => ({ collections: [...s.collections, ...newCollections] }));
      for (const collection of newCollections) { idbPut("collections", collection); }
      planStore.incrementUsage("collection", newCollections.length);
    }

    const newBookmarks = plan.bookmarks.map((b) => ({ ...b, seq: 0 as const }));
    if (newBookmarks.length > 0) {
      useBookmarksStore.getState()._bulkAddBookmarks(newBookmarks);
      planStore.incrementUsage("bookmark", newBookmarks.length);
    }

    return true;
  },

  removeWorkspaceAggregateFromState: (ids) => {
    const collectionIds = new Set(ids.collectionIds);
    set((state) => {
      const workspaces = state.workspaces.filter((workspace) => workspace.id !== ids.workspaceId);
      const activeWorkspace = workspaces.find(
        (workspace) => workspace.id === state.activeWorkspaceId && isActiveWorkspace(workspace),
      );
      return {
        workspaces,
        collections: state.collections.filter((collection) => !collectionIds.has(collection.id)),
        activeWorkspaceId: activeWorkspace?.id ?? chooseActiveWorkspace(workspaces)?.id ?? "",
      };
    });
  },

  // ── Computed ──────────────────────────────────────────────────────────
  getActiveWorkspaces: () =>
    get().workspaces.filter(isActiveWorkspace).sort(compareWorkspacePosition),

  getDeletedWorkspaces: () =>
    get().workspaces.filter((workspace) => !isActiveWorkspace(workspace)).sort(compareWorkspacePosition),

  getWorkspaceCollections: (workspaceId) => {
    const state = get();
    const wsId = workspaceId ?? state.activeWorkspaceId;
    return state.collections
      .filter((c) => c.workspaceId === wsId && !c.deletedAt && !c.archivedAt)
      .sort(compareActiveCollections);
  },

  getArchivedCollections: () =>
    get().collections.filter(c => !!c.archivedAt && !c.deletedAt),

  getTrashedCollections: () =>
    get().collections.filter(c => !!c.deletedAt),
}));
