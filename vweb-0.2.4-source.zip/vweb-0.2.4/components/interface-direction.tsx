import { useLayoutEffect, type ReactNode } from "react";
import { Direction } from "radix-ui";
import { resolveInterfaceLanguage, resolveInterfaceDirection, useI18nStore } from "@/store/i18n-store";

export function InterfaceDirection({ children }: { children: ReactNode }) {
  const language = useI18nStore((state) => state.language);
  const preference = useI18nStore((state) => state.directionPreference);
  const locale = resolveInterfaceLanguage(language);
  const direction = resolveInterfaceDirection(preference, locale);

  useLayoutEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = direction;
  }, [direction, locale]);

  return <Direction.Provider dir={direction}>{children}</Direction.Provider>;
}
