import * as React from "react";
import * as SwitchPrimitives from "@radix-ui/react-switch";
import { cn } from "@/lib/utils";

interface SwitchProps extends React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root> {
  variant?: "default" | "blue";
}

function Switch({
  className,
  variant = "default",
  ...props
}: SwitchProps) {
  const isBlue = variant === "blue";

  return (
    <SwitchPrimitives.Root
      data-slot="switch"
      dir={isBlue ? "ltr" : undefined}
      className={cn(
        "peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50",
        isBlue
          ? "data-[state=checked]:bg-[#2563eb] data-[state=unchecked]:border-slate-500 data-[state=unchecked]:bg-white"
          : "data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
        className
      )}
      {...props}
    >
      <SwitchPrimitives.Thumb
        data-slot="switch-thumb"
        className={cn(
          "pointer-events-none block h-4 w-4 rounded-full shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0",
          isBlue
            ? "data-[state=checked]:bg-white data-[state=unchecked]:bg-slate-500"
            : "bg-background",
        )}
      />
    </SwitchPrimitives.Root>
  );
}

export { Switch };
