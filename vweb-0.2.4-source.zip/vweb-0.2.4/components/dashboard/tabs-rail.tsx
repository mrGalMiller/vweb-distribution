import * as React from "react";
import { useDraggable } from "@dnd-kit/core";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, Loader2, ExternalLink, Globe, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ExtensionMessage } from "@/lib/messages";
import { cn } from "@/lib/utils";
import { FaviconImage } from "@/components/ui/favicon-image";
import { useTranslation } from "@/hooks/use-translation";
import type { TabDragData } from "./tabs-dnd-provider";

interface WindowTab {
  id: number;
  title: string;
  url: string;
  favIconUrl: string;
  active: boolean;
  windowId: number;
}

interface BrowserWindow {
  id: number;
  focused: boolean;
  tabs: WindowTab[];
}

interface DraggableRailTabProps {
  tab: WindowTab;
  onFocus: () => void;
}

function DraggableRailTab({ tab, onFocus }: DraggableRailTabProps) {
  const dragData: TabDragData = {
    type: "tab",
    tabId: tab.id,
    fromGroupId: -1,
    title: tab.title,
    url: tab.url,
    favIconUrl: tab.favIconUrl,
  };
  const { setNodeRef, listeners, attributes, isDragging } = useDraggable({
    id: `rail-tab-${tab.id}`,
    data: dragData,
  });

  return (
    <button
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      data-drag-handle
      onClick={onFocus}
      className={cn(
        "w-full flex items-start gap-2 px-2.5 py-2 rounded-md border bg-card text-start transition-colors group hover:bg-accent hover:border-accent cursor-grab active:cursor-grabbing touch-none",
        tab.active && "border-primary/30 bg-primary/5",
        isDragging && "opacity-40"
      )}
    >
      <div className="relative shrink-0 mt-0.5">
        <FaviconImage src={tab.favIconUrl} className="size-4 rounded-sm" />
        {tab.active && (
          <span className="absolute -bottom-0.5 -end-0.5 size-2 rounded-full bg-green-500 ring-1 ring-background" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-medium truncate leading-tight">
          <bdi>{tab.title}</bdi>
        </p>
        <p className="text-[10px] text-muted-foreground truncate mt-0.5">
          <bdi dir="ltr">{new URL(tab.url).hostname}</bdi>
        </p>
      </div>
      <ExternalLink className="size-3 shrink-0 opacity-0 group-hover:opacity-60 mt-0.5 text-muted-foreground" />
    </button>
  );
}

function isUserUrl(url: string) {
  return (
    !!url &&
    !url.startsWith("chrome://") &&
    !url.startsWith("chrome-extension://") &&
    !url.startsWith("about:") &&
    !url.startsWith("edge://")
  );
}

async function loadWindows(): Promise<BrowserWindow[]> {
  return new Promise((resolve) => {
    chrome.windows.getAll({ populate: true }, (wins) => {
      resolve(
        (wins ?? []).map((w) => ({
          id: w.id!,
          focused: w.focused ?? false,
          tabs: (w.tabs ?? [])
            .filter((t) => t.url && isUserUrl(t.url))
            .map((t) => ({
              id: t.id!,
              title: t.title ?? t.url ?? "Untitled",
              url: t.url ?? "",
              favIconUrl: t.favIconUrl ?? "",
              active: t.active,
              windowId: t.windowId,
            })),
        }))
      );
    });
  });
}

async function focusTab(tabId: number, windowId: number) {
  await new Promise<void>((r) =>
    chrome.windows.update(windowId, { focused: true }, () =>
      chrome.tabs.update(tabId, { active: true }, () => r())
    )
  );
}

export function TabsRail({ onClose }: { onClose: () => void }) {
  const { t } = useTranslation();
  const [windows, setWindows] = React.useState<BrowserWindow[]>([]);
  const [selectedWindowId, setSelectedWindowId] = React.useState<number | null>(null);
  const [loading, setLoading] = React.useState(true);

  async function refresh() {
    const wins = await loadWindows();
    setWindows(wins);
    // auto-select focused window if not already selected
    setSelectedWindowId((prev) => {
      if (prev && wins.some((w) => w.id === prev)) { return prev; }
      return wins.find((w) => w.focused)?.id ?? wins[0]?.id ?? null;
    });
    setLoading(false);
  }

  React.useEffect(() => {
    void refresh();
    const handler = (message: ExtensionMessage) => {
      if (message.type === "TABS_CHANGED") { void refresh(); }
    };
    chrome.runtime.onMessage.addListener(handler);
    return () => chrome.runtime.onMessage.removeListener(handler);
  }, []);

  const selectedWindow = windows.find((w) => w.id === selectedWindowId);
  const tabs = selectedWindow?.tabs ?? [];

  const windowLabel = (w: BrowserWindow, idx: number) => {
    return t(w.focused ? "tabsRail_currentWindow" : "tabsRail_windowNumber", [String(idx + 1)]);
  };

  return (
    <div className="flex w-full min-w-0 flex-col overflow-hidden bg-background">
      {/* Open Tabs Header */}
      <div className="flex shrink-0 items-center justify-between gap-2 border-b px-3 py-2.5">
        <span className="text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">
          {t("tabsPanel_openTabs")}
        </span>
        <div className="flex shrink-0 items-center gap-1.5">
          {windows.length > 1 && (
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground outline-none">
                {windows.findIndex((w) => w.id === selectedWindowId) >= 0
                  ? windowLabel(
                      selectedWindow!,
                      windows.findIndex((w) => w.id === selectedWindowId)
                    )
                  : t("tabsRail_window")}
                <ChevronDown className="size-3" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-44">
                {windows.map((w, idx) => (
                  <DropdownMenuItem
                    key={w.id}
                    onClick={() => setSelectedWindowId(w.id)}
                    className={cn(
                      selectedWindowId === w.id && "bg-muted font-medium"
                    )}
                  >
                    <Globe className="size-3.5 me-2 text-muted-foreground" />
                    {windowLabel(w, idx)}
                    <span className="ms-auto text-muted-foreground text-xs">
                      {w.tabs.length}
                    </span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
          <Button
            variant="ghost"
            size="icon-xs"
            aria-label={t("tabsDrawer_close")}
            onClick={onClose}
          >
            <X className="size-4" />
          </Button>
        </div>
      </div>

      {/* Tab list */}
      <div className="flex-1 overflow-y-auto p-2 flex flex-col gap-1.5">
        {loading && (
          <div className="flex justify-center py-8">
            <Loader2 className="size-4 animate-spin text-muted-foreground" />
          </div>
        )}
        {!loading && tabs.length === 0 && (
          <p className="text-xs text-muted-foreground text-center py-8 px-3">
            {t("tabsPanel_noTabs")}
          </p>
        )}
        {!loading &&
          tabs.map((tab) => (
            <DraggableRailTab
              key={tab.id}
              tab={tab}
              onFocus={() => focusTab(tab.id, tab.windowId)}
            />
          ))}
      </div>

      {/* Footer */}
      {!loading && (
        <div className="px-3 py-2 border-t shrink-0">
          <p className="text-[10px] text-muted-foreground">
            {t("groupsPanel_openTabs", [String(tabs.length)])}
            {windows.length > 1 && ` · ${t("tabsRail_windowCount", [String(windows.length)])}`}
          </p>
        </div>
      )}
    </div>
  );
}
