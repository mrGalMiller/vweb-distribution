import * as React from "react";
import { cn } from "@/lib/utils";
import { openInNewTab } from "@/lib/chrome/tabs";
import { useBookmarksStore } from "@/store/bookmarks-store";
import { useWorkspaceStore } from "@/store/workspace-store";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { FaviconImage } from "@/components/ui/favicon-image";
import { TagList } from "@/components/ui/tag-list";
import { EmptyState } from "@/components/ui/empty-state";
import {
  Archive,
  Bookmark,
  BookOpen,
  Check,
  ChevronDown,
  ChevronRight,
  Code,
  Folder,
  Globe,
  Heart,
  Inbox,
  MoreHorizontal,
  Palette,
  RotateCcw,
  Sparkles,
  Star,
  Trash2,
  Wrench,
  ExternalLink,
  AlertCircle,
} from "lucide-react";
import type { Bookmark as BookmarkType, Collection } from "@/lib/types";
import { useTranslation } from "@/hooks/use-translation";
import {
  getActiveWorkspaceCollections,
  getActiveWorkspaceCollectionIds,
  getCollectionsUnderActiveWorkspace,
} from "@/lib/workspace-visibility";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { compareBookmarksNewestFirst } from "@/lib/bookmark-utils";

// ---------------------------------------------------------------------------
// Icon map (mirrors sidebar)
// ---------------------------------------------------------------------------
const ICON_MAP: Record<string, React.ElementType> = {
  folder: Folder,
  bookmark: Bookmark,
  code: Code,
  palette: Palette,
  wrench: Wrench,
  "book-open": BookOpen,
  sparkles: Sparkles,
  star: Star,
  heart: Heart,
  globe: Globe,
  inbox: Inbox,
};

function CollectionIcon({ icon, className }: { icon: string; className?: string }) {
  const Icon = ICON_MAP[icon] ?? Folder;
  return <Icon className={className ?? "size-4"} />;
}

function ArchivedCollectionCard({
  collection,
  bookmarks,
  selected,
  onSelect,
  selectedBmIds,
  onToggleBm,
}: {
  collection: Collection;
  bookmarks: BookmarkType[];
  selected?: boolean;
  onSelect?: (checked: boolean) => void;
  selectedBmIds?: Set<string>;
  onToggleBm?: (id: string) => void;
}) {
  const { t } = useTranslation();
  const restoreCollection = useWorkspaceStore(s => s.restoreCollection);
  const deleteCollection = useWorkspaceStore(s => s.deleteCollection);
  const [expanded, setExpanded] = React.useState(false);
  const [targetUnavailable, setTargetUnavailable] = React.useState(false);

  return (
    <div className="flex flex-col rounded-lg border bg-card overflow-hidden">
      {targetUnavailable && (
        <Alert variant="destructive" className="m-3 mb-0">
          <AlertCircle />
          <AlertDescription>{t("workspaceVisibility_targetUnavailable")}</AlertDescription>
        </Alert>
      )}
      <div
        className="flex items-center gap-4 p-4 hover:bg-accent/50 transition-colors cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        {onSelect && (
          <div
            className={cn(
              "flex size-4 shrink-0 items-center justify-center rounded-sm border border-primary transition-all cursor-pointer",
              selected ? "bg-primary text-primary-foreground" : "bg-transparent text-transparent"
            )}
            onClick={(e) => {
              e.stopPropagation();
              onSelect(!selected);
            }}
          >
            <Check className={cn("size-3", selected ? "opacity-100" : "opacity-0")} strokeWidth={3} />
          </div>
        )}
        <div className="size-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
          <CollectionIcon icon={collection.icon} className="size-5 text-muted-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <h3 className="font-medium truncate">{collection.name}</h3>
            {expanded ? <ChevronDown className="size-3.5 text-muted-foreground" /> : <ChevronRight className="size-3.5 text-muted-foreground" />}
          </div>
          <p className="text-sm text-muted-foreground">
            {t(bookmarks.length === 1 ? "archiveContent_bookmarkCount_one" : "archiveContent_bookmarkCount_other", [bookmarks.length.toString()])}
          </p>
        </div>
        <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => {
              const state = useWorkspaceStore.getState();
              const visibleCollection = getCollectionsUnderActiveWorkspace(
                state.activeWorkspaceId,
                state.workspaces,
                state.collections,
              ).find((candidate) => candidate.id === collection.id && !!candidate.archivedAt);
              if (!visibleCollection) {
                setTargetUnavailable(true);
                return;
              }
              restoreCollection(collection.id);
              // Restore ALL bookmarks currently in this collection, ignoring selection
              bookmarks.forEach(b => {
                useBookmarksStore.getState().restoreFromArchive(b.id);
              });
            }}
          >
            <RotateCcw className="size-4 mr-1" />
            {t("archiveContent_restore")}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon-xs">
                <MoreHorizontal className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                className="text-destructive focus:text-destructive"
                onClick={() => deleteCollection(collection.id)}
              >
                <Trash2 className="size-4 mr-2" />
                {t("archiveContent_moveToTrash")}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      {expanded && bookmarks.length > 0 && (
        <div className="flex flex-col border-t bg-card/30 divide-y divide-border/50">
          {bookmarks.map((b) => (
            <ArchivedBookmarkCard
              key={b.id}
              bookmark={b}
              isNested
              selected={selectedBmIds?.has(b.id)}
              onSelect={onToggleBm ? () => onToggleBm(b.id) : undefined}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function ArchivedBookmarkCard({
  bookmark,
  isNested,
  selected,
  onSelect,
}: {
  bookmark: BookmarkType;
  isNested?: boolean;
  selected?: boolean;
  onSelect?: () => void;
}) {
  const { t } = useTranslation();
  const restoreFromArchive = useBookmarksStore(s => s.restoreFromArchive);
  const trashBookmark = useBookmarksStore(s => s.trashBookmark);
  const tags = useWorkspaceStore(s => s.tags);
  const bookmarkTags = React.useMemo(
    () => tags.filter((tag) => bookmark.tags.includes(tag.id)),
    [tags, bookmark.tags]
  );

  const [targetUnavailable, setTargetUnavailable] = React.useState(false);

  function handleRestore() {
    const state = useWorkspaceStore.getState();
    const active = getActiveWorkspaceCollections(
      state.activeWorkspaceId,
      state.workspaces,
      state.collections,
    );
    const scopedCollectionIds = new Set(
      getCollectionsUnderActiveWorkspace(
        state.activeWorkspaceId,
        state.workspaces,
        state.collections,
      ).map((collection) => collection.id),
    );
    if (bookmark.collectionId !== "" && !scopedCollectionIds.has(bookmark.collectionId)) {
      setTargetUnavailable(true);
      return;
    }

    // 1. collectionId still points to an active collection
    const byId = active.find(c => c.id === bookmark.collectionId);
    if (byId) {
      restoreFromArchive(bookmark.id);
      return;
    }

    // 2. Original collection name exists under a different id (e.g. re-created)
    const srcCol = state.collections.find(c => c.id === bookmark.collectionId);
    const byName = srcCol ? active.find(c => c.name === srcCol.name) : undefined;
    if (byName) {
      useBookmarksStore.getState().updateBookmark(bookmark.id, { collectionId: byName.id });
      restoreFromArchive(bookmark.id);
      return;
    }

    // 3. Fall back to default collection
    const defaultCol = active.find(c => c.isDefault);
    const targetColId = defaultCol?.id ?? "";
    useBookmarksStore.getState().updateBookmark(bookmark.id, { collectionId: targetColId });
    restoreFromArchive(bookmark.id);
    setTargetUnavailable(false);
  }

  function handleMoveToTrash() {
    const state = useWorkspaceStore.getState();
    const scopedIds = new Set(
      getCollectionsUnderActiveWorkspace(
        state.activeWorkspaceId,
        state.workspaces,
        state.collections,
      ).map((collection) => collection.id),
    );
    if (bookmark.collectionId !== "" && !scopedIds.has(bookmark.collectionId)) {
      setTargetUnavailable(true);
      return;
    }
    restoreFromArchive(bookmark.id);
    setTimeout(() => trashBookmark(bookmark.id), 0);
  }

  return (
    <div
      className={cn(
        "group relative flex items-center gap-4 p-4 hover:bg-accent/50 transition-colors",
        !isNested && "rounded-lg border bg-card",
        onSelect && "cursor-pointer"
      )}
      onClick={() => onSelect?.()}
    >
      {targetUnavailable && (
        <Alert variant="destructive" className="absolute z-10">
          <AlertCircle />
          <AlertDescription>{t("workspaceVisibility_targetUnavailable")}</AlertDescription>
        </Alert>
      )}
      {onSelect && (
        <div
          className={cn(
            "flex size-4 shrink-0 items-center justify-center rounded-sm border border-primary transition-all cursor-pointer",
            selected ? "bg-primary text-primary-foreground" : "bg-transparent text-transparent"
          )}
          onClick={(e) => {
            e.stopPropagation();
            onSelect();
          }}
        >
          <Check className={cn("size-3", selected ? "opacity-100" : "opacity-0")} strokeWidth={3} />
        </div>
      )}
      <div className="size-10 rounded-lg bg-muted flex items-center justify-center overflow-hidden shrink-0">
        <FaviconImage
          src={bookmark.favicon}
          alt={bookmark.title}
          className="size-6"
          hasDarkIcon={bookmark.hasDarkIcon}
        />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h3 className="font-medium truncate">{bookmark.title}</h3>
          <TagList tags={bookmarkTags} max={2} className="hidden sm:flex" />
        </div>
        <p className="text-sm text-muted-foreground truncate">{bookmark.url}</p>
      </div>

      <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
        <Button variant="outline" size="sm" onClick={handleRestore}>
          <RotateCcw className="size-4 mr-1" />
          {t("archiveContent_restore")}
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon-xs">
              <MoreHorizontal className="size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => openInNewTab(bookmark.url)}>
              <ExternalLink className="size-4 mr-2" />
              {t("archiveContent_openUrl")}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="text-destructive"
              onClick={handleMoveToTrash}
            >
              <Trash2 className="size-4 mr-2" />
              {t("archiveContent_moveToTrash")}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

export function ArchiveContent() {
  const { t } = useTranslation();
  React.useEffect(() => {
    void useBookmarksStore.getState().loadArchivedBookmarks();
  }, []);

  const archivedBookmarks = useBookmarksStore(s => s.archivedBookmarks);
  const restoreFromArchive = useBookmarksStore(s => s.restoreFromArchive);
  const trashBookmark = useBookmarksStore(s => s.trashBookmark);
  
  const collections = useWorkspaceStore(s => s.collections);
  const workspaces = useWorkspaceStore(s => s.workspaces);
  const activeWorkspaceId = useWorkspaceStore(s => s.activeWorkspaceId);
  const restoreCollection = useWorkspaceStore(s => s.restoreCollection);
  const deleteCollection = useWorkspaceStore(s => s.deleteCollection);

  const activeCollectionIds = React.useMemo(
    () => getActiveWorkspaceCollectionIds(activeWorkspaceId, workspaces, collections),
    [activeWorkspaceId, workspaces, collections],
  );

  const archivedCollections = React.useMemo(
    () => getCollectionsUnderActiveWorkspace(activeWorkspaceId, workspaces, collections)
      .filter(c => !!c.archivedAt && !c.deletedAt),
    [activeWorkspaceId, workspaces, collections]
  );

  const archivedCollectionIds = React.useMemo(
    () => new Set(archivedCollections.map(c => c.id)),
    [archivedCollections]
  );

  const collectionBookmarks = React.useMemo(() => {
    const map: Record<string, BookmarkType[]> = {};
    for (const b of archivedBookmarks) {
      if (archivedCollectionIds.has(b.collectionId)) {
        if (!map[b.collectionId]) map[b.collectionId] = [];
        map[b.collectionId].push(b);
      }
    }
    // Storage order is IDB key order, or server order after a pull — sort so the
    // list does not reshuffle between reloads.
    for (const bookmarks of Object.values(map)) {
      bookmarks.sort(compareBookmarksNewestFirst);
    }
    return map;
  }, [archivedBookmarks, archivedCollectionIds]);

  const individualArchivedBookmarks = React.useMemo(
    () => archivedBookmarks.filter(
      b => !archivedCollectionIds.has(b.collectionId) && (b.collectionId === "" || activeCollectionIds.has(b.collectionId))
    ).sort(compareBookmarksNewestFirst),
    [archivedBookmarks, archivedCollectionIds, activeCollectionIds]
  );

  const totalCount = archivedCollections.length + individualArchivedBookmarks.length;

  const [selectedColIds, setSelectedColIds] = React.useState<Set<string>>(new Set());
  const [selectedBmIds, setSelectedBmIds] = React.useState<Set<string>>(new Set());
  const [targetUnavailable, setTargetUnavailable] = React.useState(false);

  React.useEffect(() => {
    setSelectedColIds(new Set());
    setSelectedBmIds(new Set());
  }, [activeWorkspaceId]);
  const selectedCount = selectedColIds.size + selectedBmIds.size;

  const toggleCol = (id: string) => {
    setSelectedColIds(prev => {
      const next = new Set(prev);
      const isSelecting = !next.has(id);
      if (isSelecting) next.add(id); else next.delete(id);

      // Cascade to bookmarks in this collection
      const bmsInCol = collectionBookmarks[id] || [];
      setSelectedBmIds(prevBm => {
        const nextBm = new Set(prevBm);
        for (const bm of bmsInCol) {
          if (isSelecting) nextBm.add(bm.id);
          else nextBm.delete(bm.id);
        }
        return nextBm;
      });

      return next;
    });
  };

  const toggleBm = (id: string) => {
    setSelectedBmIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleSelectAll = () => {
    if (selectedCount === totalCount) {
      setSelectedColIds(new Set());
      setSelectedBmIds(new Set());
    } else {
      setSelectedColIds(new Set(archivedCollections.map(c => c.id)));
      setSelectedBmIds(new Set(individualArchivedBookmarks.map(b => b.id)));
    }
  };

  const handleBatchRestore = () => {
    const state = useWorkspaceStore.getState();
    const active = getActiveWorkspaceCollections(
      state.activeWorkspaceId,
      state.workspaces,
      state.collections,
    );
    const scopedIds = new Set(
      getCollectionsUnderActiveWorkspace(
        state.activeWorkspaceId,
        state.workspaces,
        state.collections,
      ).map((collection) => collection.id),
    );
    if (
      Array.from(selectedColIds).some((id) => !scopedIds.has(id)) ||
      Array.from(selectedBmIds).some((id) => {
        const bookmark = archivedBookmarks.find((candidate) => candidate.id === id);
        return !bookmark || (bookmark.collectionId !== "" && !scopedIds.has(bookmark.collectionId));
      })
    ) {
      setSelectedColIds(new Set());
      setSelectedBmIds(new Set());
      setTargetUnavailable(true);
      return;
    }
    const defaultCol = active.find(c => c.isDefault);

    // 1. Restore collections
    for (const colId of selectedColIds) {
      restoreCollection(colId);

      // For each restored collection, detach its bookmarks that were NOT selected
      const allBmsInCol = collectionBookmarks[colId] || [];
      for (const bm of allBmsInCol) {
        if (!selectedBmIds.has(bm.id)) {
          useBookmarksStore.getState().updateBookmark(bm.id, { collectionId: defaultCol?.id ?? bm.collectionId });
        }
      }
    }

    // 2. Restore bookmarks
    for (const bmId of selectedBmIds) {
      const bm = archivedBookmarks.find(b => b.id === bmId);
      if (!bm) continue;

      let targetColId = bm.collectionId;

      const isRestoringCol = selectedColIds.has(bm.collectionId);
      const isColAlreadyActive = active.some(c => c.id === bm.collectionId);

      if (!isRestoringCol && !isColAlreadyActive) {
        targetColId = defaultCol?.id ?? "";
      }

      if (targetColId !== bm.collectionId) {
        useBookmarksStore.getState().updateBookmark(bm.id, { collectionId: targetColId });
      }
      
      restoreFromArchive(bmId);
    }

    setSelectedColIds(new Set());
    setSelectedBmIds(new Set());
    setTargetUnavailable(false);
  };

  const handleBatchDelete = () => {
    // Mirror handleBatchRestore: never write a tombstone into a workspace that
    // a remote pull has since retired.
    const state = useWorkspaceStore.getState();
    const scopedIds = new Set(
      getCollectionsUnderActiveWorkspace(
        state.activeWorkspaceId,
        state.workspaces,
        state.collections,
      ).map((collection) => collection.id),
    );
    if (
      Array.from(selectedColIds).some((id) => !scopedIds.has(id)) ||
      Array.from(selectedBmIds).some((id) => {
        const bookmark = archivedBookmarks.find((candidate) => candidate.id === id);
        return !bookmark || (bookmark.collectionId !== "" && !scopedIds.has(bookmark.collectionId));
      })
    ) {
      setSelectedColIds(new Set());
      setSelectedBmIds(new Set());
      setTargetUnavailable(true);
      return;
    }
    for (const colId of selectedColIds) {
      deleteCollection(colId);
    }
    const toTrash = Array.from(selectedBmIds);
    for (const bmId of toTrash) {
      restoreFromArchive(bmId);
    }
    for (const bmId of toTrash) {
      trashBookmark(bmId);
    }
    setSelectedColIds(new Set());
    setSelectedBmIds(new Set());
  };

  return (
    <div className="flex-1 w-full overflow-auto">
      <div className="p-4 md:p-6 space-y-6">
        {targetUnavailable && (
          <Alert variant="destructive">
            <AlertCircle />
            <AlertDescription>{t("workspaceVisibility_targetUnavailable")}</AlertDescription>
          </Alert>
        )}
        <div className="flex items-center justify-between gap-4 p-4 rounded-xl border bg-card">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-lg bg-violet-500/10 text-violet-500 flex items-center justify-center">
              <Archive className="size-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold">{t("archiveContent_title")}</h2>
              <p className="text-sm text-muted-foreground">
                {archivedCollections.length > 0 && `${t(archivedCollections.length === 1 ? "archiveContent_collectionCount_one" : "archiveContent_collectionCount_other", [archivedCollections.length.toString()])}, `}
                {t(individualArchivedBookmarks.length === 1 ? "archiveContent_bookmarkCount_one" : "archiveContent_bookmarkCount_other", [individualArchivedBookmarks.length.toString()])}
              </p>
            </div>
          </div>

          {totalCount > 0 && selectedCount === 0 && (
            <Button variant="outline" size="sm" onClick={handleSelectAll}>
              {t("archiveContent_selectAll")}
            </Button>
          )}

          {selectedCount > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium mr-2 hidden sm:inline-block">{t("archiveContent_selectedCount", [selectedCount.toString()])}</span>
              <Button variant="outline" size="sm" onClick={() => { setSelectedColIds(new Set()); setSelectedBmIds(new Set()); }}>
                {t("archiveContent_cancel")}
              </Button>
              <Button variant="outline" size="sm" onClick={handleSelectAll}>
                {selectedCount === totalCount ? t("archiveContent_deselectAll") : t("archiveContent_selectAll")}
              </Button>
              <Button size="sm" onClick={handleBatchRestore}>
                <RotateCcw className="size-4 mr-1" /> {t("archiveContent_restore")}
              </Button>
              <Button size="sm" variant="destructive" onClick={handleBatchDelete}>
                <Trash2 className="size-4 mr-1" /> {t("archiveContent_moveToTrash")}
              </Button>
            </div>
          )}
        </div>

        {archivedCollections.length > 0 && (
          <div className="flex flex-col gap-2">
            {archivedCollections.map(col => (
              <ArchivedCollectionCard
                key={col.id}
                collection={col}
                bookmarks={collectionBookmarks[col.id] ?? []}
                selected={selectedColIds.has(col.id)}
                onSelect={() => toggleCol(col.id)}
                selectedBmIds={selectedBmIds}
                onToggleBm={toggleBm}
              />
            ))}
          </div>
        )}

        <div className="flex flex-col gap-2">
          {individualArchivedBookmarks.map((bookmark) => (
            <ArchivedBookmarkCard
              key={bookmark.id}
              bookmark={bookmark}
              selected={selectedBmIds.has(bookmark.id)}
              onSelect={() => toggleBm(bookmark.id)}
            />
          ))}
        </div>

        {totalCount === 0 && (
          <EmptyState
            icon={Archive}
            title={t("archiveContent_emptyTitle")}
            description={t("archiveContent_emptyDesc")}
          />
        )}
      </div>
    </div>
  );
}
