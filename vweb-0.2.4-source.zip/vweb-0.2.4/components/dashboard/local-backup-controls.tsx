import { useRef, useState, type ChangeEvent } from "react";
import { Button } from "@/components/ui/button";
import { useTranslation } from "@/hooks/use-translation";
import { parseLocalBackup, readLocalBackup, restoreLocalBackup } from "@/lib/local-backup";

export function LocalBackupControls() {
  const { t } = useTranslation();
  const fileInput = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  const handleBackup = async () => {
    setBusy(true);
    setMessage("");
    try {
      const backup = await readLocalBackup();
      const url = URL.createObjectURL(new Blob([JSON.stringify(backup) + "\n"], { type: "application/json" }));
      const link = document.createElement("a");
      link.href = url;
      link.download = `vweb-local-backup-${backup.createdAt.replace(/[:.]/g, "-")}.json`;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setMessage(t("localBackup_downloadReady"));
    } catch {
      setMessage(t("localBackup_exportFailed"));
    } finally {
      setBusy(false);
    }
  };

  const handleRestore = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = "";
    if (!file) {
      return;
    }

    setBusy(true);
    setMessage("");
    try {
      const backup = parseLocalBackup(await file.text());
      await restoreLocalBackup(backup);
      await chrome.runtime.sendMessage({ type: "LOCAL_BACKUP_RESTORED" }).catch(() => {});
      location.reload();
    } catch {
      setMessage(t("localBackup_restoreFailed"));
      setBusy(false);
    }
  };

  return (
    <section className="space-y-2.5" aria-label={t("localBackup_title")}>
      <h3 className="text-sm font-semibold">{t("localBackup_title")}</h3>
      <p className="text-xs text-muted-foreground">{t("localBackup_description")}</p>
      <div className="flex flex-wrap gap-2">
        <Button variant="outline" size="sm" disabled={busy} onClick={handleBackup}>
          {t("localBackup_export")}
        </Button>
        <Button variant="outline" size="sm" disabled={busy} onClick={() => fileInput.current?.click()}>
          {t("localBackup_restore")}
        </Button>
        <input ref={fileInput} type="file" accept=".json,application/json" hidden onChange={handleRestore} />
      </div>
      {message && <p className="text-xs text-muted-foreground" role="status">{message}</p>}
    </section>
  );
}
