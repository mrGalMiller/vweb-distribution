import * as React from "react";
import { Tabs } from "radix-ui";
import { SystemMapPanel } from "@/components/dashboard/system-map-panel";
import type { SettingsTab } from "@/lib/system-map";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { LocalBackupControls } from "@/components/dashboard/local-backup-controls";
import { ImportDialog } from "@/components/dashboard/import-dialog";
import { usePlanStore } from "@/store/plan-store";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Bookmark, Layers, Tag, Folder, ShieldCheck, Loader2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTranslation } from "@/hooks/use-translation";

interface QuotaRowProps {
  label: string;
  usage: number;
  limit: number;
  icon: React.ElementType;
}

function QuotaRow({ label, usage, limit, icon: Icon }: QuotaRowProps) {
  const isUnlimited = limit === -1;
  const percentage = isUnlimited ? 0 : Math.min(100, (usage / Math.max(1, limit)) * 100);

  let barColor = "bg-emerald-500 dark:bg-emerald-600";
  if (percentage >= 90) {
    barColor = "bg-rose-500 dark:bg-rose-600";
  } else if (percentage >= 70) {
    barColor = "bg-amber-500 dark:bg-amber-600";
  }

  return (
    <div className="flex flex-col gap-2 p-3.5 rounded-xl border border-muted/60 bg-muted/10 backdrop-blur-xs select-none">
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <Icon className="size-3.5 text-muted-foreground" />
          <span className="font-semibold text-muted-foreground">{label}</span>
        </div>
        <span className="font-mono font-bold text-foreground">
          {usage} <span className="text-muted-foreground/40 font-sans">/</span> {isUnlimited ? "∞" : limit}
        </span>
      </div>
      <div className="relative w-full h-2 rounded-full bg-muted/60 overflow-hidden">
        {isUnlimited ? (
          <div className="absolute inset-0 bg-gradient-to-r from-violet-500/20 via-pink-500/20 to-violet-500/20 animate-pulse rounded-full" />
        ) : (
          <div
            className={cn("h-full rounded-full transition-all duration-500 ease-out", barColor)}
            style={{ width: `${percentage}%` }}
          />
        )}
      </div>
    </div>
  );
}

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialTab?: SettingsTab;
  returnFocusRef: React.RefObject<HTMLButtonElement | null>;
  onOpenWorkspaceManager: () => void;
  onOpenTabsDrawer: () => void;
}

const settingsTabs = [
  { id: "general", label: "settings_tabGeneral" },
  { id: "quotas", label: "settings_tabQuotas" },
  { id: "system-map", label: "systemMap_title" },
] as const;

export function SettingsDialog({
  open, onOpenChange, initialTab = "general", returnFocusRef,
  onOpenWorkspaceManager, onOpenTabsDrawer,
}: SettingsDialogProps) {
  const { t, tNode } = useTranslation();
  const [activeTab, setActiveTab] = React.useState<SettingsTab>(initialTab);
  const nextAction = React.useRef<(() => void) | null>(null);
  const overlayId = React.useId();

  const handleLeaveSettings = (callback: () => void) => {
    nextAction.current = callback;
    onOpenChange(false);
  };

  React.useEffect(() => {
    if (open) {
      setActiveTab(initialTab);
    }
  }, [open, initialTab]);

  const limits = usePlanStore(s => s.limits);
  const usage = usePlanStore(s => s.usage);
  const areQuotasLoading = usePlanStore(s => s.isFetching);
  const refreshUsage = usePlanStore(s => s.refreshUsage);

  React.useEffect(() => {
    if (open && activeTab === "quotas") {
      refreshUsage();
    }
  }, [open, activeTab, refreshUsage]);

  const [importDialogOpen, setImportDialogOpen] = React.useState(false);

  const [searchOverlayEnabled, setSearchOverlayEnabled] = React.useState(false);

  React.useEffect(() => {
    if (open && typeof chrome !== "undefined" && chrome.permissions) {
      chrome.permissions.contains({ origins: ["<all_urls>"] }).then(setSearchOverlayEnabled);
    }
  }, [open]);

  const handleToggleSearchOverlay = async (checked: boolean) => {
    if (typeof chrome === "undefined" || !chrome.permissions) { return; }

    if (checked) {
      const granted = await chrome.permissions.request({ origins: ["<all_urls>"] });
      setSearchOverlayEnabled(granted);
    } else {
      const removed = await chrome.permissions.remove({ origins: ["<all_urls>"] });
      if (removed) {
        setSearchOverlayEnabled(false);
      }
    }
  };

  const overlaySetting = (
    <div className="rounded-lg border p-3 shadow-sm bg-card/20">
      <div className="flex flex-row items-center justify-between">
        <div className="space-y-0.5">
          <label htmlFor={overlayId} className="text-sm font-semibold">{t("settings_generalOverlayTitle")}</label>
          <p className="text-xs text-muted-foreground me-4 mt-0.5">
            {tNode("settings_generalOverlayDesc", (
              <kbd className="px-1 py-0.5 rounded-md bg-muted border font-sans text-[10px]">Ctrl+Shift+K</kbd>
            ))}
          </p>
        </div>
        <Switch
          id={overlayId}
          variant="blue"
          checked={searchOverlayEnabled}
          onCheckedChange={handleToggleSearchOverlay}
        />
      </div>
    </div>
  );

  return (
    <>
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        aria-modal="true"
        className={cn(
          "max-h-[90dvh] flex flex-col p-4 sm:p-6",
          activeTab === "system-map" ? "h-[85dvh] sm:max-w-4xl" : "sm:max-w-xl",
        )}
        onCloseAutoFocus={(event) => {
          event.preventDefault();
          const action = nextAction.current;
          nextAction.current = null;
          if (action) {
            action();
          } else {
            returnFocusRef.current?.focus();
          }
        }}
      >
        <DialogHeader>
          <DialogTitle>{t("settings_title")}</DialogTitle>
          <DialogDescription className="sr-only">{t("settings_desc")}</DialogDescription>
        </DialogHeader>

        <Tabs.Root
          value={activeTab}
          onValueChange={(value) => {
            const tab = settingsTabs.find(({ id }) => id === value);
            if (tab) {
              setActiveTab(tab.id);
            }
          }}
          className="flex min-h-0 flex-1 flex-col gap-4"
        >
          <Tabs.List aria-label={t("settings_title")} className="grid shrink-0 grid-cols-2 gap-0.5 rounded-xl border border-muted/80 bg-muted/20 p-1 sm:grid-cols-3">
            {settingsTabs.map(({ id, label }) => (
              <Tabs.Trigger
                key={id}
                value={id}
                className="rounded-lg px-2 py-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-xs"
              >
                {t(label)}
              </Tabs.Trigger>
            ))}
          </Tabs.List>

          <Tabs.Content value="general" className="min-h-0 flex-1 overflow-y-auto pe-2 space-y-6">
              {overlaySetting}
              <LocalBackupControls />

              <div className="space-y-2.5">
                <h3 className="text-sm font-semibold">{t("settings_generalImportTitle")}</h3>
                <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                  {t("settings_generalImportDesc")}
                </p>
                <Button variant="outline" size="sm" onClick={() => setImportDialogOpen(true)} className="cursor-pointer">
                  {t("settings_generalImportBtn")}
                </Button>
              </div>
          </Tabs.Content>

          <Tabs.Content value="quotas" className="min-h-0 flex-1 overflow-y-auto pe-2 space-y-5">
              <div className="space-y-3">
                <div className="flex items-center justify-between select-none">
                  <h4 className="text-xs font-bold text-muted-foreground tracking-wider uppercase">{t("settings_tabQuotas")}</h4>
                  {areQuotasLoading && <Loader2 className="size-3.5 animate-spin text-muted-foreground" />}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <QuotaRow
                    label={t("quota_workspaces")}
                    usage={usage?.workspaces ?? 0}
                    limit={limits?.max_workspaces ?? -1}
                    icon={Layers}
                  />
                  <QuotaRow
                    label={t("quota_bookmarks")}
                    usage={usage?.bookmarks ?? 0}
                    limit={limits?.max_bookmarks ?? -1}
                    icon={Bookmark}
                  />
                  <QuotaRow
                    label={t("quota_collections")}
                    usage={usage?.collections ?? 0}
                    limit={limits?.max_collections ?? -1}
                    icon={Folder}
                  />
                  <QuotaRow
                    label={t("quota_tags")}
                    usage={usage?.tags ?? 0}
                    limit={limits?.max_tags ?? -1}
                    icon={Tag}
                  />
                  <QuotaRow
                    label={t("quota_savedGroups")}
                    usage={usage?.saved_groups ?? 0}
                    limit={limits?.max_saved_groups ?? -1}
                    icon={Sparkles}
                  />
                </div>

                {limits && limits.trash_grace_days !== -1 && (
                  <div className="flex items-center gap-2 p-3 text-xs rounded-xl border border-muted bg-muted/5 text-muted-foreground mt-1 select-none">
                    <ShieldCheck className="size-4 text-emerald-500 shrink-0" />
                    <span>
                      {tNode("settings_quotaTrashDesc", limits.trash_grace_days.toString())}
                    </span>
                  </div>
                )}
              </div>
          </Tabs.Content>

          <Tabs.Content value="system-map" className={activeTab === "system-map" ? "flex min-h-0 flex-1 flex-col" : undefined}>
            {activeTab === "system-map" && (
              <SystemMapPanel
                overlaySetting={overlaySetting}
                onNavigate={() => onOpenChange(false)}
                onSelectSettingsTab={setActiveTab}
                onOpenWorkspaceManager={() => handleLeaveSettings(onOpenWorkspaceManager)}
                onOpenImport={() => setImportDialogOpen(true)}
                onOpenTabsDrawer={() => handleLeaveSettings(onOpenTabsDrawer)}
              />
            )}
          </Tabs.Content>
        </Tabs.Root>

        <div className="pt-4 border-t mt-auto flex justify-end shrink-0">
          <Button onClick={() => onOpenChange(false)} className="cursor-pointer">{t("settings_done")}</Button>
        </div>
      </DialogContent>
    </Dialog>
    <ImportDialog open={importDialogOpen} onOpenChange={setImportDialogOpen} />
    </>
  );
}
