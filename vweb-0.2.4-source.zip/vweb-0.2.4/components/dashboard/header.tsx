import type { RefObject } from "react";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";
import { DashboardAction } from "@/components/dashboard/dashboard-action";
import { DASHBOARD_PAGES, type DashboardPageId } from "@/lib/system-map";
import { isToolbarActionVisible, useSystemMapStore } from "@/store/system-map-store";
import { useTranslation } from "@/hooks/use-translation";

interface BookmarksHeaderProps {
  pageId: DashboardPageId;
  tabsDrawerOpen: boolean;
  tabsDrawerTrigger: RefObject<HTMLButtonElement | null>;
  onToggleTabsDrawer: () => void;
}

export function BookmarksHeader({
  pageId,
  tabsDrawerOpen,
  tabsDrawerTrigger,
  onToggleTabsDrawer,
}: BookmarksHeaderProps) {
  const { t } = useTranslation();
  const hidden = useSystemMapStore(s => s.hidden);
  const page = DASHBOARD_PAGES.find((entry) => entry.id === pageId) ?? DASHBOARD_PAGES[0];

  return (
    <header className="w-full border-b">
      <div className="flex items-center justify-between h-14 px-4">
        <div className="flex items-center gap-3">
          <SidebarTrigger />
          <Separator orientation="vertical" className="h-5" />
          <h1 className="text-base font-semibold hidden sm:block">{t(page.headerLabel ?? page.label)}</h1>
        </div>

        <div className="flex items-center gap-2">
          {page.toolbar.map((action) => (
            isToolbarActionVisible(hidden, pageId, action) && (
              <DashboardAction
                key={action}
                action={action}
                tabsDrawerOpen={tabsDrawerOpen}
                tabsDrawerTrigger={tabsDrawerTrigger}
                onToggleTabsDrawer={onToggleTabsDrawer}
              />
            )
          ))}
        </div>
      </div>
    </header>
  );
}
