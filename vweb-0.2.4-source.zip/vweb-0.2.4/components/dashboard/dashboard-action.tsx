import { useState, type RefObject } from "react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { LanguageSelector } from "@/components/language-selector";
import { useTranslation } from "@/hooks/use-translation";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import {
  LayoutGrid,
  List,
  Plus,
  SlidersHorizontal,
  ArrowUpDown,
  GitBranch,
  Check,
  PanelRight,
} from "lucide-react";
import { useBookmarksStore } from "@/store/bookmarks-store";
import { cn } from "@/lib/utils";
import { AddBookmarkDialog } from "@/components/dashboard/add-bookmark-dialog";
import type { ToolbarActionId } from "@/lib/system-map";

interface DashboardActionProps {
  action: ToolbarActionId;
  inSettings?: boolean;
  tabsDrawerOpen?: boolean;
  tabsDrawerTrigger?: RefObject<HTMLButtonElement | null>;
  onToggleTabsDrawer?: () => void;
}

const sortOptions = [
  { value: "date-newest", labelKey: "header_sortDateNewest" },
  { value: "date-oldest", labelKey: "header_sortDateOldest" },
  { value: "alpha-az", labelKey: "header_sortAlphaAZ" },
  { value: "alpha-za", labelKey: "header_sortAlphaZA" },
] as const;

const filterOptions = [
  { value: "all", labelKey: "header_filterAll" },
  { value: "favorites", labelKey: "header_filterFavorites" },
  { value: "with-tags", labelKey: "header_filterWithTags" },
  { value: "without-tags", labelKey: "header_filterWithoutTags" },
] as const;


export function DashboardAction(props: DashboardActionProps) {
  const { action, onToggleTabsDrawer, inSettings = false } = props;
  const { t } = useTranslation();

  switch (action) {
    case "bookmark-view":
      return <BookmarkView />;
    case "bookmark-sort":
      return <BookmarkSort inSettings={inSettings} />;
    case "bookmark-filter":
      return <BookmarkFilter inSettings={inSettings} />;
    case "add-bookmark":
      return <AddBookmarkAction inSettings={inSettings} />;
    case "tabs-drawer":
      return (
        <Button
          ref={props.tabsDrawerTrigger}
          variant={props.tabsDrawerOpen ? "secondary" : "outline"}
          size="sm"
          aria-label={t("tabsPanel_openTabs")}
          aria-controls="open-tabs-drawer"
          aria-expanded={props.tabsDrawerOpen ?? false}
          onClick={onToggleTabsDrawer}
        >
          <PanelRight className="size-4 rtl:-scale-x-100" />
          <span className={inSettings ? undefined : "hidden md:inline"}>{t("tabsPanel_openTabs")}</span>
        </Button>
      );
    case "theme":
      return <ThemeToggle />;
    case "language":
      return <LanguageSelector />;
    case "upstream-source":
      return (
        <Button variant="ghost" size="icon" asChild>
          <a
            aria-label={t("systemMap_sourceLink")}
            href="https://github.com/TabSlate-dev/TabSlate"
            target="_blank"
            rel="noopener noreferrer"
          >
            <GitBranch className="size-5" />
          </a>
        </Button>
      );
  }
}

function BookmarkView() {
  const { t } = useTranslation();
  const viewMode = useBookmarksStore(s => s.viewMode);
  const setViewMode = useBookmarksStore(s => s.setViewMode);

  return (
    <div className="flex items-center border rounded-md p-0.5">
      <Button
        variant="ghost"
        size="icon-xs"
        className={cn("rounded-sm", viewMode === "grid" && "bg-muted")}
        aria-label={t("systemMap_grid")}
        aria-pressed={viewMode === "grid"}
        onClick={() => setViewMode("grid")}
      >
        <LayoutGrid className="size-4" />
      </Button>
      <Button
        variant="ghost"
        size="icon-xs"
        className={cn("rounded-sm", viewMode === "list" && "bg-muted")}
        aria-label={t("systemMap_list")}
        aria-pressed={viewMode === "list"}
        onClick={() => setViewMode("list")}
      >
        <List className="size-4" />
      </Button>
    </div>
  );
}

function BookmarkSort({ inSettings }: { inSettings: boolean }) {
  const { t } = useTranslation();
  const sortBy = useBookmarksStore(s => s.sortBy);
  const setSortBy = useBookmarksStore(s => s.setSortBy);
  const currentSort = sortOptions.find((opt) => opt.value === sortBy);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" aria-label={t("header_sortBy")} className={inSettings ? undefined : "hidden sm:flex"}>
          <ArrowUpDown className="size-4" />
          <span className={inSettings ? undefined : "hidden lg:inline"}>{inSettings ? t(currentSort?.labelKey ?? "header_sortDateNewest") : t(currentSort?.labelKey ?? "header_sortDateNewest").split(" ")[0]}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel className="text-xs text-muted-foreground">
          {t("header_sortBy")}
        </DropdownMenuLabel>
        {sortOptions.map((option) => (
          <DropdownMenuItem
            key={option.value}
            onClick={() => setSortBy(option.value)}
            className="flex items-center justify-between"
          >
            {t(option.labelKey)}
            {sortBy === option.value && <Check className="size-4" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function BookmarkFilter({ inSettings }: { inSettings: boolean }) {
  const { t } = useTranslation();
  const filterType = useBookmarksStore(s => s.filterType);
  const setFilterType = useBookmarksStore(s => s.setFilterType);
  const currentFilter = filterOptions.find((opt) => opt.value === filterType);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          aria-label={t("header_filter")}
          className={cn(
            !inSettings && "hidden sm:flex",
            filterType !== "all" && "border-primary text-primary"
          )}
        >
          <SlidersHorizontal className="size-4" />
          <span className={inSettings ? undefined : "hidden lg:inline"}>
            {filterType !== "all" && currentFilter ? t(currentFilter.labelKey) : t("header_filter")}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel className="text-xs text-muted-foreground">
          {t("header_filterBy")}
        </DropdownMenuLabel>
        {filterOptions.map((option) => (
          <DropdownMenuItem
            key={option.value}
            onClick={() => setFilterType(option.value)}
            className="flex items-center justify-between"
          >
            {t(option.labelKey)}
            {filterType === option.value && <Check className="size-4" />}
          </DropdownMenuItem>
        ))}
        {filterType !== "all" && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => setFilterType("all")}
              className="text-muted-foreground"
            >
              {t("header_clearFilter")}
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function AddBookmarkAction({ inSettings }: { inSettings: boolean }) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button size="sm" className={inSettings ? undefined : "hidden sm:flex"} onClick={() => setOpen(true)}>
        <Plus className="size-4" />
        {t("header_addBookmark")}
      </Button>
      <AddBookmarkDialog open={open} onOpenChange={setOpen} />
    </>
  );
}
