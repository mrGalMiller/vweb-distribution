import * as React from "react";
import { useDraggable, useDroppable } from "@dnd-kit/core";
import { useTabsDndContext } from "./tabs-dnd-provider";
import { contentCollectionDropId } from "@/lib/drop-ids";
import { bookmarksAsArray, useBookmarksStore } from "@/store/bookmarks-store";
import { useWorkspaceStore } from "@/store/workspace-store";
import { BookmarkCard } from "./bookmark-card";
import { useVirtualizer } from "@tanstack/react-virtual";

import { EmptyState } from "@/components/ui/empty-state";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  X,
  Bookmark,
  ChevronDown,
  ChevronRight,
  Folder,
  Code,
  Palette,
  Wrench,
  BookOpen,
  Sparkles,
  Star,
  Heart,
  Globe,
  Inbox,
} from "lucide-react";
import type { BookmarkDragData } from "./tabs-dnd-provider";
import type { Bookmark as BookmarkType } from "@/lib/types";

import { HeroSection } from "./hero-section";
import { useTabsStore } from "@/store/tabs-store";
import { EditBookmarkDialog } from "@/components/dashboard/shared/edit-bookmark-dialog";
import { BookmarkTagsDialog } from "@/components/dashboard/shared/bookmark-tags-dialog";
import { SearchBox } from "./search-box";
import { useTranslation } from "@/hooks/use-translation";
import {
  getActiveWorkspaceCollectionIds,
  getActiveWorkspaceCollections,
} from "@/lib/workspace-visibility";

const ICON_MAP: Record<string, React.ElementType> = {
  folder: Folder,
  bookmark: Bookmark,
  code: Code,
  palette: Palette,
  wrench: Wrench,
  "book-open": BookOpen,
  sparkles: Sparkles,
  star: Star,
  heart: Heart,
  globe: Globe,
  inbox: Inbox,
};

function CollectionIcon({ icon }: { icon: string }) {
  const Icon = ICON_MAP[icon] ?? Folder;
  return <Icon className="size-4" />;
}

interface DroppableCollectionHeaderProps {
  rowData: {
    collectionId: string;
    collectionName: string;
    count: number;
    icon: string;
    isDefault: boolean;
  };
  isExpanded: boolean;
  onToggle: () => void;
}

function DroppableCollectionHeader({ rowData, isExpanded, onToggle }: DroppableCollectionHeaderProps) {
  const { setNodeRef } = useDroppable({ id: bandDropId(rowData.collectionId) });
  const { activeData, overCollectionId } = useTabsDndContext();

  const isBandOver = React.useMemo(() => {
    if (!activeData || !ACCEPTED_DRAG_TYPES.includes(activeData.type)) return false;
    return overCollectionId === bandCollectionKey(rowData.collectionId);
  }, [activeData, overCollectionId, rowData.collectionId]);

  return (
    <div
      ref={setNodeRef}
      onClick={onToggle}
      className={cn(
        "group flex items-center justify-between p-3 rounded-xl border transition-all duration-300 cursor-pointer select-none",
        isExpanded
          ? "bg-primary/[0.03] border-primary/20 dark:bg-primary/[0.02] shadow-sm"
          : "bg-card/25 border-muted/20 hover:bg-accent/40 hover:border-primary/20 hover:shadow-md",
        isBandOver && "border-primary bg-primary/10 ring-1 ring-primary/30 shadow-lg dark:bg-primary/5 scale-[1.01]"
      )}
    >
      <div className="flex items-center gap-3">
        <ChevronDown
          className={cn(
            "size-4 text-muted-foreground group-hover:text-primary transition-all duration-300",
            !isExpanded && "-rotate-90 text-muted-foreground/60"
          )}
        />
        <div className="size-8 rounded-lg bg-primary/5 text-primary flex items-center justify-center border border-primary/10 group-hover:scale-105 transition-transform duration-300">
          <CollectionIcon icon={rowData.icon} />
        </div>
        <span className="font-semibold text-sm tracking-tight text-foreground/90 group-hover:text-primary transition-colors duration-300">
          {rowData.collectionName}
        </span>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/10">
          {rowData.count}
        </span>
      </div>
    </div>
  );
}

const ACCEPTED_DRAG_TYPES = ["tab", "tab-group", "bookmark"];

/**
 * The dnd-kit drop id for a Collection band.
 *
 * "uncategorized" and "" have no Collection behind them, so they borrow the
 * "all" sentinel the drop handler already resolves to the default Collection.
 */
function bandCollectionKey(collectionId: string) {
  return collectionId === "uncategorized" || collectionId === "" ? "all" : collectionId;
}

function bandDropId(collectionId: string, suffix?: string) {
  return contentCollectionDropId(bandCollectionKey(collectionId), suffix);
}

interface DroppableCollectionBandProps {
  collectionId: string;
  /** Discriminator so each row of a Collection gets a unique dnd-kit id. */
  suffix: string;
  measureElement: (node: Element | null) => void;
  index: number;
  start: number;
  style?: React.CSSProperties;
  className?: string;
  children: React.ReactNode;
}

/**
 * One row of a Collection band, registered as a dnd-kit drop target.
 *
 * The positioning transform and the droppable MUST live on different elements.
 * dnd-kit measures droppables with `getTransformAgnosticClientRect`, which
 * strips the element's own CSS transform — registering the virtualizer's
 * `translateY` row would report every band at the top of the list, so the
 * pointer never lands inside one. The outer element positions, the inner one
 * is the drop target.
 */
function DroppableCollectionBand({
  collectionId,
  suffix,
  measureElement,
  index,
  start,
  style,
  className,
  children,
}: DroppableCollectionBandProps) {
  const { setNodeRef } = useDroppable({ id: bandDropId(collectionId, suffix) });
  const { activeData, overCollectionId } = useTabsDndContext();

  const isBandOver = React.useMemo(() => {
    if (!activeData || !ACCEPTED_DRAG_TYPES.includes(activeData.type)) return false;
    return overCollectionId === bandCollectionKey(collectionId);
  }, [activeData, overCollectionId, collectionId]);

  return (
    <div
      ref={measureElement}
      data-index={index}
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        transform: `translateY(${start}px)`,
      }}
    >
      <div
        ref={setNodeRef}
        style={style}
        className={cn(className, isBandOver && "bg-primary/5")}
      >
        {children}
      </div>
    </div>
  );
}

function colsFromWidth(width: number) {
  if (width >= 1280) return 4;
  if (width >= 1024) return 3;
  if (width >= 640) return 2;
  return 1;
}

function useContainerColumns(ref: React.RefObject<HTMLElement | null>) {
  const [cols, setCols] = React.useState(1);
  React.useEffect(() => {
    if (!ref.current) return;
    setCols(colsFromWidth(ref.current.getBoundingClientRect().width));
    const observer = new ResizeObserver((entries) => {
      setCols(colsFromWidth(entries[0].contentRect.width));
    });
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, [ref]);
  return cols;
}

interface DraggableBookmarkCardProps {
  bookmark: BookmarkType;
  variant?: "grid" | "list";
  isHighlighted?: boolean;
  onEdit?: (bookmark: BookmarkType) => void;
  onAddTags?: (bookmark: BookmarkType) => void;
}

const DraggableBookmarkCard = React.memo(function DraggableBookmarkCard({ bookmark, variant = "grid", isHighlighted, onEdit, onAddTags }: DraggableBookmarkCardProps) {
  const dragData: BookmarkDragData = {
    type: "bookmark",
    bookmarkId: bookmark.id,
    title: bookmark.title,
    url: bookmark.url,
    favicon: bookmark.favicon,
    variant,
  };
  const { setNodeRef, listeners, attributes, isDragging } = useDraggable({
    id: `bookmark-${bookmark.id}`,
    data: dragData,
  });

  return (
    <div ref={setNodeRef} {...listeners} {...attributes} className="relative h-full">
      <div className={cn(isDragging && "opacity-0 pointer-events-none", "h-full")}>
        <BookmarkCard
          bookmark={bookmark}
          variant={variant}
          isHighlighted={isHighlighted}
          dragHandleProps={{ "data-drag-handle": true }}
          onEdit={onEdit}
          onAddTags={onAddTags}
        />
      </div>
      {isDragging && (
        <div className="absolute inset-0 rounded-xl border-2 border-dashed border-muted-foreground/25 bg-muted/10" />
      )}
    </div>
  );
});

type VirtualItem =
  | { type: "hero_and_title" }
  | { type: "collection_header"; collectionId: string; collectionName: string; count: number; icon: string; isDefault: boolean }
  | { type: "bookmarks_row"; collectionId: string; bookmarks: BookmarkType[]; rowIndex: number }
  | { type: "collection_dropzone"; collectionId: string }
  | { type: "empty_state"; title: string; description: string };

export function BookmarksContent() {
  const { t } = useTranslation();
  const openTabs = useTabsStore(s => s.openTabs);
  const loadTabs = useTabsStore(s => s.loadTabs);

  React.useEffect(() => {
    if (openTabs.length === 0) { loadTabs(true); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selectedCollection = useBookmarksStore(s => s.selectedCollection);
  const setSelectedCollection = useBookmarksStore(s => s.setSelectedCollection);
  const viewMode = useBookmarksStore(s => s.viewMode);
  const selectedTags = useBookmarksStore(s => s.selectedTags);
  const toggleTag = useBookmarksStore(s => s.toggleTag);
  const filterType = useBookmarksStore(s => s.filterType);
  const setFilterType = useBookmarksStore(s => s.setFilterType);
  const sortBy = useBookmarksStore(s => s.sortBy);
  const bookmarks = useBookmarksStore(s => bookmarksAsArray(s.bookmarks));
  const searchQuery = useBookmarksStore(s => s.searchQuery);
  const getFilteredBookmarks = useBookmarksStore(s => s.getFilteredBookmarks);

  const collections = useWorkspaceStore(s => s.collections);
  const workspaces = useWorkspaceStore(s => s.workspaces);
  const tags = useWorkspaceStore(s => s.tags);
  const activeWorkspaceId = useWorkspaceStore(s => s.activeWorkspaceId);

  const [editingBookmark, setEditingBookmark] = React.useState<BookmarkType | null>(null);
  const [taggingBookmark, setTaggingBookmark] = React.useState<BookmarkType | null>(null);
  const [expandedCollectionIds, setExpandedCollectionIds] = React.useState<Record<string, boolean>>({});

  const prevWorkspaceIdRef = React.useRef<string | null>(null);
  React.useEffect(() => {
    if (prevWorkspaceIdRef.current !== null && prevWorkspaceIdRef.current !== activeWorkspaceId) {
      setSelectedCollection("all");
    }
    prevWorkspaceIdRef.current = activeWorkspaceId;
  }, [activeWorkspaceId, setSelectedCollection]);

  const highlightedBookmarkId = useBookmarksStore((state) => state.highlightedBookmarkId);

  const parentRef = React.useRef<HTMLDivElement>(null);
  const gridCols = useContainerColumns(parentRef);

  const workspaceCollectionIds = React.useMemo(
    () => getActiveWorkspaceCollectionIds(activeWorkspaceId, workspaces, collections),
    [activeWorkspaceId, workspaces, collections]
  );

  const activeCollections = React.useMemo(
    () => getActiveWorkspaceCollections(activeWorkspaceId, workspaces, collections),
    [activeWorkspaceId, workspaces, collections],
  );

  const filteredBookmarks = React.useMemo(
    () => getFilteredBookmarks(workspaceCollectionIds),
    [bookmarks, selectedCollection, selectedTags, filterType, searchQuery, sortBy, workspaceCollectionIds]
  );

  const currentCollection =
    selectedCollection === "all"
      ? { name: t("bookmarksContent_allBookmarks") }
      : activeCollections.find((c) => c.id === selectedCollection);

  React.useEffect(() => {
    if (selectedCollection !== "all" && !workspaceCollectionIds.has(selectedCollection)) {
      setSelectedCollection("all");
    }
  }, [selectedCollection, setSelectedCollection, workspaceCollectionIds]);

  const activeTagsData = React.useMemo(
    () => tags.filter((t) => selectedTags.includes(t.id)),
    [tags, selectedTags]
  );
  const hasActiveFilters =
    selectedTags.length > 0 || filterType !== "all" || sortBy !== "date-newest";

  const actualCols = viewMode === "grid" ? gridCols : 1;

  const virtualRows = React.useMemo<VirtualItem[]>(() => {
    const rows: VirtualItem[] = [];

    // 1. Header (contains hero section + category title + filters info)
    rows.push({ type: "hero_and_title" });

    if (filteredBookmarks.length === 0) {
      rows.push({
        type: "empty_state",
        title: t("bookmarksContent_emptyTitle"),
        description: t("bookmarksContent_emptyDesc"),
      });
      return rows;
    }

    if (selectedCollection !== "all") {
      // Flat view for specific collection
      const colCols = viewMode === "grid" ? gridCols : 1;
      const totalRows = Math.ceil(filteredBookmarks.length / colCols);
      for (let r = 0; r < totalRows; r++) {
        const startIndex = r * colCols;
        const rowItems = filteredBookmarks.slice(startIndex, startIndex + colCols);
        rows.push({
          type: "bookmarks_row",
          collectionId: selectedCollection,
          bookmarks: rowItems,
          rowIndex: r,
        });
      }
    } else {
      // Group by Collection view under "All Bookmarks"
      const groups: Record<string, BookmarkType[]> = {};

      const activeCols = activeCollections;

      activeCols.forEach((c) => {
        groups[c.id] = [];
      });
      groups["uncategorized"] = [];

      filteredBookmarks.forEach((b) => {
        const colId = b.collectionId || "uncategorized";
        if (groups[colId]) {
          groups[colId].push(b);
        } else {
          groups["uncategorized"].push(b);
        }
      });

      // Render active collections
      activeCols.forEach((col) => {
        const colBookmarks = groups[col.id] || [];

        rows.push({
          type: "collection_header",
          collectionId: col.id,
          collectionName: col.name,
          count: colBookmarks.length,
          icon: col.icon,
          isDefault: col.isDefault ?? false,
        });

        const isExpanded = expandedCollectionIds[col.id] ?? col.isDefault;
        if (isExpanded && colBookmarks.length > 0) {
          const colCols = viewMode === "grid" ? gridCols : 1;
          const totalColRows = Math.ceil(colBookmarks.length / colCols);
          for (let r = 0; r < totalColRows; r++) {
            const startIndex = r * colCols;
            const rowItems = colBookmarks.slice(startIndex, startIndex + colCols);
            rows.push({
              type: "bookmarks_row",
              collectionId: col.id,
              bookmarks: rowItems,
              rowIndex: r,
            });
          }
        } else if (isExpanded) {
          rows.push({ type: "collection_dropzone", collectionId: col.id });
        }
      });

      // Render Uncategorized bookmarks if any
      const uncategorizedBookmarks = groups["uncategorized"] || [];
      if (uncategorizedBookmarks.length > 0) {
        rows.push({
          type: "collection_header",
          collectionId: "uncategorized",
          collectionName: t("bookmarksContent_uncategorized"),
          count: uncategorizedBookmarks.length,
          icon: "bookmark",
          isDefault: false,
        });

        const isExpanded = expandedCollectionIds["uncategorized"] ?? false;
        if (isExpanded) {
          const colCols = viewMode === "grid" ? gridCols : 1;
          const totalColRows = Math.ceil(uncategorizedBookmarks.length / colCols);
          for (let r = 0; r < totalColRows; r++) {
            const startIndex = r * colCols;
            const rowItems = uncategorizedBookmarks.slice(startIndex, startIndex + colCols);
            rows.push({
              type: "bookmarks_row",
              collectionId: "uncategorized",
              bookmarks: rowItems,
              rowIndex: r,
            });
          }
        }
      }
    }

    return rows;
  }, [
    selectedCollection,
    filteredBookmarks,
    activeCollections,
    expandedCollectionIds,
    viewMode,
    gridCols,
    t
  ]);

  const virtualizer = useVirtualizer({
    count: virtualRows.length,
    getScrollElement: () => parentRef.current,
    estimateSize: (index) => {
      const row = virtualRows[index];
      if (!row) return 50;
      if (row.type === "hero_and_title") {
        return (selectedCollection === "all" && !hasActiveFilters) ? 500 : 130;
      }
      if (row.type === "collection_header") {
        return 58;
      }
      if (row.type === "empty_state") {
        return 200;
      }
      if (row.type === "collection_dropzone") {
        return 76;
      }
      return viewMode === "grid" ? 156 : 80;
    },
    getItemKey: React.useCallback(
      (index: number) => {
        const row = virtualRows[index];
        if (!row) return index;
        if (row.type === "hero_and_title") {
          return `hero-and-title-${selectedCollection === "all" && !hasActiveFilters ? "full" : "compact"}`;
        }
        if (row.type === "empty_state") return "empty-state";
        if (row.type === "collection_header") {
          return `col-header-${row.collectionId}`;
        }
        if (row.type === "collection_dropzone") {
          return `col-dropzone-${row.collectionId}`;
        }
        return `bookmarks-row-${viewMode}-${row.collectionId}-${row.rowIndex}`;
      },
      [virtualRows, selectedCollection, hasActiveFilters, viewMode]
    ),
    overscan: 5,
  });

  React.useEffect(() => {
    if (!highlightedBookmarkId) { return; }
    const rowIndex = virtualRows.findIndex(
      (row) =>
        row.type === "bookmarks_row" &&
        row.bookmarks.some((b) => b.id === highlightedBookmarkId)
    );
    if (rowIndex === -1) {
      const targetBookmark = filteredBookmarks.find((b) => b.id === highlightedBookmarkId);
      if (targetBookmark && targetBookmark.collectionId) {
        setExpandedCollectionIds((prev) => ({
          ...prev,
          [targetBookmark.collectionId]: true,
        }));
      }
      return;
    }
    virtualizer.scrollToIndex(rowIndex, { align: "center" });
  }, [highlightedBookmarkId, virtualRows, virtualizer, filteredBookmarks]);

  return (
    <div ref={parentRef} className="flex-1 w-full overflow-auto relative">
      <div
        style={{
          height: `${virtualizer.getTotalSize()}px`,
          width: '100%',
          position: 'relative',
        }}
      >
        {virtualizer.getVirtualItems().map((virtualRow) => {
          const rowData = virtualRows[virtualRow.index];
          if (!rowData) return null;

          if (rowData.type === "hero_and_title") {
            return (
              <div
                key={virtualRow.key}
                ref={virtualizer.measureElement}
                data-index={virtualRow.index}
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  transform: `translateY(${virtualRow.start}px)`,
                  zIndex: 10,
                }}
              >
                <div className="p-4 md:p-6 space-y-6 pb-4">
                  {selectedCollection === "all" && !hasActiveFilters && <HeroSection />}

                  <div className="space-y-4">
                    <div className="flex flex-col gap-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                          <h2 className="text-lg font-semibold">
                            {currentCollection?.name || t("bookmarksContent_allBookmarks")}
                          </h2>
                          <p className="text-sm text-muted-foreground">
                            {t(filteredBookmarks.length === 1 ? "bookmarksContent_bookmarkCount_one" : "bookmarksContent_bookmarkCount_other", [filteredBookmarks.length.toString()])}
                            {hasActiveFilters && t("bookmarksContent_filtered")}
                          </p>
                        </div>
                        {selectedCollection !== "all" && (
                          <SearchBox size="sm" collectionId={selectedCollection} className="w-full sm:w-72 md:w-80" />
                        )}
                      </div>

                      {(activeTagsData.length > 0 || filterType !== "all") && (
                        <div className="flex flex-wrap items-center gap-2">
                          {filterType !== "all" && (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium bg-primary/10 text-primary">
                              {filterType === "favorites" && t("bookmarksContent_favoritesOnly")}
                              {filterType === "with-tags" && t("bookmarksContent_withTags")}
                              {filterType === "without-tags" && t("bookmarksContent_withoutTags")}
                              <button
                                onClick={() => setFilterType("all")}
                                className="hover:bg-primary/20 rounded-full p-0.5"
                              >
                                <X className="size-3" />
                              </button>
                            </span>
                          )}
                          {activeTagsData.map((tag) => (
                            <span
                              key={tag.id}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium bg-primary text-primary-foreground"
                            >
                              {tag.name}
                              <button
                                onClick={() => toggleTag(tag.id)}
                                className="hover:bg-primary-foreground/20 rounded-full p-0.5"
                              >
                                <X className="size-3" />
                              </button>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          }

          if (rowData.type === "empty_state") {
            return (
              <DroppableCollectionBand
                key={virtualRow.key}
                collectionId={selectedCollection}
                suffix="empty-state"
                measureElement={virtualizer.measureElement}
                index={virtualRow.index}
                start={virtualRow.start}
                className="px-4 md:px-6 py-8"
              >
                <EmptyState
                  icon={Bookmark}
                  title={rowData.title}
                  description={rowData.description}
                  action={
                    hasActiveFilters ? (
                      <Button variant="outline" size="sm" onClick={() => setFilterType("all")}>
                        {t("bookmarksContent_clearFilters")}
                      </Button>
                    ) : undefined
                  }
                />
              </DroppableCollectionBand>
            );
          }

          if (rowData.type === "collection_header") {
            const isExpanded = expandedCollectionIds[rowData.collectionId] ?? rowData.isDefault;
            return (
              <div
                key={virtualRow.key}
                ref={virtualizer.measureElement}
                data-index={virtualRow.index}
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  transform: `translateY(${virtualRow.start}px)`,
                }}
                className="px-4 md:px-6 py-1.5"
              >
                <DroppableCollectionHeader
                  rowData={rowData}
                  isExpanded={isExpanded}
                  onToggle={() => {
                    setExpandedCollectionIds((prev) => ({
                      ...prev,
                      [rowData.collectionId]: !isExpanded,
                    }));
                  }}
                />
              </div>
            );
          }

          if (rowData.type === "collection_dropzone") {
            return (
              <DroppableCollectionBand
                key={virtualRow.key}
                collectionId={rowData.collectionId}
                suffix="dropzone"
                measureElement={virtualizer.measureElement}
                index={virtualRow.index}
                start={virtualRow.start}
                className="px-4 md:px-6 py-2"
              >
                <div className="flex items-center justify-center h-14 rounded-xl border-2 border-dashed border-muted-foreground/20 bg-muted/10 text-xs text-muted-foreground">
                  {t("bookmarksContent_emptyCollectionDropHint")}
                </div>
              </DroppableCollectionBand>
            );
          }

          if (rowData.type === "bookmarks_row") {
            return (
              <DroppableCollectionBand
                key={virtualRow.key}
                collectionId={rowData.collectionId}
                suffix={`row-${rowData.rowIndex}`}
                measureElement={virtualizer.measureElement}
                index={virtualRow.index}
                start={virtualRow.start}
                style={viewMode === "grid" ? { gridTemplateColumns: `repeat(${actualCols}, minmax(0, 1fr))` } : undefined}
                className={
                  viewMode === "grid"
                    ? "grid gap-4 px-4 md:px-6 py-2"
                    : "flex flex-col gap-2 px-4 md:px-6 py-2"
                }
              >
                {rowData.bookmarks.map((bookmark) => (
                  <DraggableBookmarkCard
                    key={bookmark.id}
                    bookmark={bookmark}
                    variant={viewMode}
                    isHighlighted={bookmark.id === highlightedBookmarkId}
                    onEdit={setEditingBookmark}
                    onAddTags={setTaggingBookmark}
                  />
                ))}
              </DroppableCollectionBand>
            );
          }

          return null;
        })}
      </div>

      {editingBookmark && (
        <EditBookmarkDialog
          bookmark={editingBookmark}
          open={!!editingBookmark}
          onOpenChange={(open) => !open && setEditingBookmark(null)}
        />
      )}
      {taggingBookmark && (
        <BookmarkTagsDialog
          bookmark={taggingBookmark}
          open={!!taggingBookmark}
          onOpenChange={(open) => !open && setTaggingBookmark(null)}
        />
      )}
    </div>
  );
}
