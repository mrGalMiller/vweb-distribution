import { useId, useMemo, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { Download, RotateCcw } from "lucide-react";
import { DashboardAction } from "@/components/dashboard/dashboard-action";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useTranslation } from "@/hooks/use-translation";
import {
  createSystemMapExport, FAMILY_RELATIONSHIPS, savedGroupPath, SYSTEM_ACTIONS,
  SYSTEM_INTEGRATIONS, SYSTEM_MAP_FILENAME, SYSTEM_SETTINGS, SYSTEM_SURFACES,
  type SettingsTab, type SystemSurface,
} from "@/lib/system-map";
import { isActiveWorkspace } from "@/lib/workspace-visibility";
import { useGroupsStore } from "@/store/groups-store";
import { resolveInterfaceLanguage } from "@/store/i18n-store";
import { isNavigationVisible, isToolbarActionVisible, useSystemMapStore } from "@/store/system-map-store";
import { useWorkspaceStore } from "@/store/workspace-store";
import { cn } from "@/lib/utils";

interface SystemMapPanelProps {
  overlaySetting: ReactNode;
  onNavigate: () => void;
  onSelectSettingsTab: (tab: SettingsTab) => void;
  onOpenWorkspaceManager: () => void;
  onOpenImport: () => void;
  onOpenTabsDrawer: () => void;
}

type MapSelection = SystemSurface["id"] | "integrations";
const selectClass = "w-full min-w-0 rounded-md border bg-background px-3 py-2 text-sm";

function SettingSwitch({ label, checked, onChange }: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  const id = useId();
  return (
    <div className="flex items-center gap-2">
      <Switch id={id} variant="blue" checked={checked} onCheckedChange={onChange} />
      <label htmlFor={id} className="text-xs text-muted-foreground">{label}</label>
    </div>
  );
}

function IntegrationAudit({ onSelectSettingsTab }: {
  onSelectSettingsTab: (tab: SettingsTab) => void;
}) {
  const { t } = useTranslation();
  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">{t("systemMap_integrationsIntro")}</p>
      {SYSTEM_INTEGRATIONS.map(({ id, label, description, sources, endpoints }) => (
        <article key={id} className="space-y-2 rounded-lg border p-3">
          <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
            <h4 className="text-sm font-semibold">{t(label)}</h4>
            <span className="text-xs text-muted-foreground">{t(id === "quotas" ? "systemMap_status_localLimits" : "systemMap_status_onClick")}</span>
          </div>
          <p className="text-sm">{t(description)}</p>
          {endpoints.length > 0 && (
            <ul className="flex flex-wrap gap-x-3 gap-y-1 text-xs">
              {endpoints.map((endpoint) => <li key={endpoint}><code dir="ltr" className="break-all">{endpoint}</code></li>)}
            </ul>
          )}
          <SourceReferences sources={sources} />
          {id === "quotas" && (
            <Button size="sm" variant="outline" onClick={() => onSelectSettingsTab("quotas")}>
              {t("settings_tabQuotas")}
            </Button>
          )}
        </article>
      ))}
      <section className="space-y-2">
        <h4 className="text-sm font-semibold">{t("systemMap_family")}</h4>
        <dl className="space-y-2">
          {FAMILY_RELATIONSHIPS.map(({ id, label, description }) => (
            <div key={id} className="text-sm">
              <dt className="font-medium">{label} <span className="font-normal text-muted-foreground">· {t("systemMap_proposed")}</span></dt>
              <dd className="text-muted-foreground">{t(description)}</dd>
            </div>
          ))}
        </dl>
      </section>
    </div>
  );
}

function SourceReferences({ sources }: { sources: readonly string[] }) {
  const { t } = useTranslation();
  return (
    <details className="text-xs text-muted-foreground">
      <summary className="w-fit cursor-pointer font-medium">{t("systemMap_sources")}</summary>
      <ul className="mt-1 space-y-1">
        {sources.map((source) => <li key={source}><code dir="ltr" className="break-all">{source}</code></li>)}
      </ul>
    </details>
  );
}

function SavedGroupLauncher({ onNavigate }: Pick<SystemMapPanelProps, "onNavigate">) {
  const { t } = useTranslation();
  const groups = useGroupsStore(s => s.groups);
  const activeWorkspaceId = useWorkspaceStore(s => s.activeWorkspaceId);
  const workspaces = useWorkspaceStore(s => s.workspaces);
  const id = useId();
  const availableGroups = useMemo(() => {
    if (!isActiveWorkspace(workspaces.find((workspace) => workspace.id === activeWorkspaceId))) {
      return [];
    }
    return groups.filter((group) => !group.deletedAt && group.workspaceId === activeWorkspaceId);
  }, [activeWorkspaceId, groups, workspaces]);
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const selected = availableGroups.find((group) => group.id === selectedGroupId) ?? availableGroups[0];

  if (!selected) {
    return <p className="text-sm text-muted-foreground">{t("sidebar_noSavedGroups")}</p>;
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <label className="sr-only" htmlFor={id}>{t("sidebar_groups")}</label>
      <select id={id} className={cn(selectClass, "w-auto max-w-full")} value={selected.id} onChange={(event) => setSelectedGroupId(event.target.value)}>
        {availableGroups.map((group) => <option key={group.id} value={group.id}>{group.name}</option>)}
      </select>
      <Button variant="outline" size="sm" asChild>
        <Link to={savedGroupPath(selected.id)} onClick={onNavigate}>{t("systemMap_openPage")}</Link>
      </Button>
    </div>
  );
}

function DashboardVisibility({ page, onOpenTabsDrawer }: {
  page: Extract<SystemSurface, { route: string }>;
  onOpenTabsDrawer: () => void;
}) {
  const { t } = useTranslation();
  const hidden = useSystemMapStore(s => s.hidden);
  const setNavigationVisible = useSystemMapStore(s => s.setNavigationVisible);
  const setToolbarVisible = useSystemMapStore(s => s.setToolbarVisible);

  return (
    <div className="space-y-3">
      <SettingSwitch
        label={t("systemMap_showNav")}
        checked={isNavigationVisible(hidden, page.id)}
        onChange={(visible) => setNavigationVisible(page.id, visible)}
      />
      <div className="space-y-1">
        <h4 className="text-sm font-semibold">{t("systemMap_toolbar")}</h4>
        <p className="text-xs text-muted-foreground">{t("systemMap_toolbarHelp")}</p>
      </div>
      <ul className="divide-y rounded-lg border">
        {page.toolbar.map((action) => (
          <li key={action} className="flex flex-wrap items-center justify-between gap-2 px-3 py-2">
            <div className="space-y-1">
              <div className="text-sm font-medium">{t(SYSTEM_ACTIONS[action])}</div>
              <SettingSwitch
                label={t("systemMap_showToolbarFor", t(SYSTEM_ACTIONS[action]))}
                checked={isToolbarActionVisible(hidden, page.id, action)}
                onChange={(visible) => setToolbarVisible(page.id, action, visible)}
              />
            </div>
            <DashboardAction action={action} inSettings onToggleTabsDrawer={onOpenTabsDrawer} />
          </li>
        ))}
      </ul>
    </div>
  );
}

function SurfacePanel({ surface, ...props }: SystemMapPanelProps & { surface: SystemSurface }) {
  const { t } = useTranslation();
  const compact = useWorkspaceStore(s => s.compactGroupTitles);
  const setCompact = useWorkspaceStore(s => s.setCompactGroupTitles);

  return (
    <div className="space-y-4">
      <p className="text-sm">{t(surface.description)}</p>
      <dl className="space-y-2 text-sm">
        <div>
          <dt className="font-medium">{t("systemMap_location")}</dt>
          <dd className="text-muted-foreground">{surface.location.endsWith(".html") ? surface.location : t(surface.location)}</dd>
        </div>
        <div>
          <dt className="font-medium">{t("systemMap_storage")}</dt>
          <dd className="text-muted-foreground">{surface.storage.map((item) => <bdi key={item} className="me-3">{item}</bdi>)}</dd>
        </div>
        {surface.dependencies && (
          <div>
            <dt className="font-medium">{t("systemMap_dependencies")}</dt>
            <dd className="text-muted-foreground">{SYSTEM_INTEGRATIONS.filter(({ id }) =>
              surface.dependencies?.includes(id)).map(({ id, label }) => <span key={id} className="me-3">{t(label)}</span>)}</dd>
          </div>
        )}
      </dl>
      {surface.id === "saved-group" && <SavedGroupLauncher onNavigate={props.onNavigate} />}
      {"route" in surface && surface.id !== "saved-group" && (
        <Button variant="outline" size="sm" asChild>
          <Link to={surface.route} onClick={props.onNavigate}>{t("systemMap_openPage")}</Link>
        </Button>
      )}
      {surface.id === "workspaces" && (
        <Button variant="outline" size="sm" onClick={props.onOpenWorkspaceManager}>{t("workspaceManager_open")}</Button>
      )}
      {surface.id === "import" && (
        <Button variant="outline" size="sm" onClick={props.onOpenImport}>{t("settings_generalImportBtn")}</Button>
      )}
      {surface.id === "search" && (
        <Button variant="outline" size="sm" onClick={() => chrome.tabs.create({ url: chrome.runtime.getURL("search.html") })}>
          {t("systemMap_openPage")}
        </Button>
      )}
      {"settingsTab" in surface && surface.settingsTab && (
        <Button variant="outline" size="sm" onClick={() => props.onSelectSettingsTab(surface.settingsTab ?? "general")}>
          {t("settings_tabGeneral")}
        </Button>
      )}

      <div className="space-y-1">
        <h4 className="text-sm font-semibold">{t("systemMap_existingActions")}</h4>
        <ul className="list-inside list-disc space-y-0.5 text-sm text-muted-foreground">
          {surface.actions.map((id) => <li key={id}>{t(SYSTEM_ACTIONS[id])}</li>)}
        </ul>
      </div>
      {surface.settings.length > 0 && (
        <section className="space-y-2">
          <h4 className="text-sm font-semibold">{t("settings_title")}</h4>
          <p className="text-sm text-muted-foreground">{surface.settings.map((id) => t(SYSTEM_SETTINGS[id].label)).join(" · ")}</p>
          {surface.settings.includes("search-overlay") && props.overlaySetting}
          {!("route" in surface) && surface.settings.includes("theme") && (
            <div className="flex flex-wrap items-center gap-2">
              <DashboardAction action="theme" inSettings />
              {surface.settings.includes("language") && (
                <DashboardAction action="language" inSettings />
              )}
            </div>
          )}
          {surface.settings.includes("compact-group-titles") && (
            <SettingSwitch label={t("systemMap_compactGroups")} checked={compact} onChange={setCompact} />
          )}
        </section>
      )}
      {"route" in surface && <DashboardVisibility page={surface} onOpenTabsDrawer={props.onOpenTabsDrawer} />}
      <SourceReferences sources={surface.sources} />
    </div>
  );
}

export function SystemMapPanel(props: SystemMapPanelProps) {
  const { t, language } = useTranslation();
  const [selection, setSelection] = useState<MapSelection>("bookmarks");
  const resetVisibility = useSystemMapStore(s => s.resetVisibility);
  const hasCustomVisibility = useSystemMapStore(s => s.hidden.size > 0);
  const pickerId = useId();
  const detailId = useId();
  const surface = SYSTEM_SURFACES.find((entry) => entry.id === selection);
  const entries = [...SYSTEM_SURFACES, { id: "integrations", label: "systemMap_integrations" } as const];

  const handleExport = () => {
    const locale = resolveInterfaceLanguage(language);
    const catalog = createSystemMapExport(locale, t);
    const url = URL.createObjectURL(new Blob([JSON.stringify(catalog, null, 2) + "\n"], { type: "application/json" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = SYSTEM_MAP_FILENAME;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="outline" size="sm" onClick={handleExport}>
          <Download className="size-4" />
          {t("systemMap_export")}
        </Button>
        <Button variant="ghost" size="sm" onClick={resetVisibility} disabled={!hasCustomVisibility}>
          <RotateCcw className="size-4" />
          {t("systemMap_reset")}
        </Button>
      </div>

      <div className="sm:hidden">
        <label htmlFor={pickerId} className="sr-only">{t("systemMap_pages")}</label>
        <select id={pickerId} className={selectClass} aria-controls={detailId} value={selection} onChange={(event) => {
          const entry = entries.find(({ id }) => id === event.target.value);
          if (entry) {
            setSelection(entry.id);
          }
        }}>
          {entries.map(({ id, label }) => <option key={id} value={id}>{t(label)}</option>)}
        </select>
      </div>

      <div className="grid min-h-0 flex-1 gap-4 sm:grid-cols-[11rem_minmax(0,1fr)]">
        <nav aria-label={t("systemMap_pages")} className="hidden min-h-0 overflow-y-auto sm:block">
          <ul className="space-y-0.5">
            {entries.map(({ id, label }) => (
              <li key={id}>
                <button
                  type="button"
                  aria-current={selection === id ? "true" : undefined}
                  aria-controls={detailId}
                  onClick={() => setSelection(id)}
                  className={cn(
                    "w-full rounded-md px-3 py-1.5 text-start text-sm hover:bg-muted focus-visible:outline-2 focus-visible:outline-ring",
                    selection === id && "bg-muted font-semibold",
                  )}
                >
                  {t(label)}
                </button>
              </li>
            ))}
          </ul>
        </nav>
        <section className="min-h-0 overflow-y-auto pe-2" id={detailId} aria-labelledby={`${detailId}-title`} key={selection}>
          <h3 className="mb-2 text-base font-semibold" id={`${detailId}-title`}>
            {t(surface?.label ?? "systemMap_integrations")}
          </h3>
          {surface ? <SurfacePanel surface={surface} {...props} /> : <IntegrationAudit onSelectSettingsTab={props.onSelectSettingsTab} />}
        </section>
      </div>
    </div>
  );
}
