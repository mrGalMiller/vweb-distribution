import * as React from "react";
import { Languages } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useI18nStore, type DirectionPreference, type SupportedLanguage } from "@/store/i18n-store";
import { useTranslation } from "@/hooks/use-translation";

const hebrewLabel = (
  <span className="inline-flex items-center gap-1.5">
    <span aria-hidden="true">🇮🇱</span>
    <span>עברית</span>
  </span>
);

export function LanguageSelector() {
  const language = useI18nStore((s) => s.language);
  const setLanguage = useI18nStore((s) => s.setLanguage);
  const direction = useI18nStore((s) => s.directionPreference);
  const setDirection = useI18nStore((s) => s.setDirectionPreference);

  const { t } = useTranslation();

  const handleSelect = (lang: SupportedLanguage) => {
    setLanguage(lang);
  };

  const currentLabel = React.useMemo(() => {
    if (language === "en") {
      return "🇺🇸 English";
    }
    if (language === "he") {
      return hebrewLabel;
    }
    return (
      <span className="flex items-center gap-1.5">
        <Languages className="h-4 w-4" />
        {t("languageSelector_auto")}
      </span>
    );
  }, [language, t]);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="h-8 gap-2 px-2 text-muted-foreground font-normal">
          {currentLabel}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => handleSelect("auto")}>
          <span className={`flex items-center gap-1.5 ${language === "auto" ? "font-bold" : ""}`}>
            <Languages className="h-4 w-4" />
            {t("languageSelector_auto")}
          </span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("en")}>
          <span className={language === "en" ? "font-bold" : ""}>🇺🇸 English</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSelect("he")}>
          <span className={language === "he" ? "font-bold" : ""}>{hebrewLabel}</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuLabel>{t("languageSelector_direction")}</DropdownMenuLabel>
        {(["auto", "rtl", "ltr"] satisfies DirectionPreference[]).map((preference) => (
          <DropdownMenuItem
            key={preference}
            className={direction === preference ? "font-bold" : ""}
            onSelect={() => setDirection(preference)}
          >
            {t(`languageSelector_direction_${preference}`)}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
